#include "Element_aufbau.h"
#include "Element.h"
#include "Proportionen.h"
#include <QPainter>
#include <QPointF>
#include <QBrush>
#include <QPen>
#include <QLineF>

using namespace std;

Element_aufbau::Element_aufbau(QWidget *parent) : QWidget(parent), aktives_element(0)
{
}


Element_aufbau::~Element_aufbau()
{
}


void Element_aufbau::paintEvent(QPaintEvent*)
{
    // nur, wenn ein gueltiges element vorhanden ist
    if (aktives_element != 0)
    {
        QPainter painter(this);

        // mit antialiasing
        painter.setRenderHint(QPainter::Antialiasing);

        // die mitte bestimmen
        QPointF mitte(width() / 2, height() / 2);

        // den radius bestimmen
        int radius = 0;

        if (width() < height()) radius = (width() / 2) - ELEMENT_AUFBAU_RAND;
        else radius = (height() / 2) - ELEMENT_AUFBAU_RAND;

        // den abstand zwischen den ringen bestimmen
        int ringabstand = radius / ELEMENT_AUFBAU_RINGE;

        // die farbe fuer die ringe stzen
        painter.setPen(Qt::darkGray);

        // 7 ringe malen
        for (register int idx = 1; idx <= ELEMENT_AUFBAU_RINGE; idx++)
        {
            if (aktives_element->elektronen_an_ring(idx) > 0) painter.drawEllipse(mitte, ringabstand * idx, ringabstand * idx);
        }

        // einen roten punkt in der mitte malen, der den atomkern darstellen soll.
        painter.setBrush(Qt::darkRed);
        painter.setPen(Qt::darkRed);

        painter.drawEllipse(mitte, ringabstand / 3, ringabstand / 3);

        for (register int idx = 1; idx <= ELEMENT_AUFBAU_RINGE; idx++)
        {
            int elektronen_auf_ring = aktives_element->elektronen_an_ring(idx);

            if (elektronen_auf_ring > 0)
            {
                // die farbe fuer die elektronen setzen
                painter.setBrush(Qt::black);
                painter.setPen(Qt::black);

                double winkel = 0;

                if (elektronen_auf_ring > 1) winkel = (double) 360 / (double) elektronen_auf_ring;

                QLineF hilfslinie(mitte, QPointF(0, 0));
                hilfslinie.setLength(ringabstand * idx);

                for (register int idx2 = 0; idx2 < elektronen_auf_ring; idx2++)
                {
                    hilfslinie.setAngle(idx2 * winkel);

                    painter.drawEllipse(hilfslinie.p2(), ringabstand / 5, ringabstand / 5);
                }
            }
        }

        // die schrift fuer die weiteren texte anpassen
        QFont font(painter.font());
        font.setPointSizeF(radius / 15);
        painter.setFont(font);

        // die anzahl der elektronen oben rechts zeichnen
        painter.drawText(QRectF(2, 2, width(), height()), Qt::AlignLeft | Qt::AlignTop, QString::number(aktives_element->elektronen()) + tr(" Electrons"));

        painter.drawText(QRectF(0, 2, width() - 2, height()), Qt::AlignRight | Qt::AlignTop, aktives_element->element_name());
    }
}


void Element_aufbau::zeige(Element* element)
{
    aktives_element = element;

    update();
}

