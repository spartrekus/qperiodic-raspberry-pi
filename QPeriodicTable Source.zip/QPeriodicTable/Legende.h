/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef LEGENDE_H
#define LEGENDE_H

#include <QObject>
#include <QGraphicsItem>
#include <QList>
#include <QColor>

class Scene;

class Legende : public QObject, public QGraphicsItem
{
    Q_OBJECT

public:
    Legende(Scene *parent);
    virtual ~Legende();

    QRectF boundingRect() const;
    void registriere_gruppenfarben(const QList<QColor>&);
    void registriere_agrgatzustandsfarben(const QList<QColor>&);

public slots:
    void setze_seite(int);
    void setze_sichtbarkeit(bool);
    bool ist_sichtbar() const;

private:
    Scene *meinescene;
    int Aktuelle_seite;
    QList<QColor> gruppenfarben, agregatzustandsfarben;

    void paint(QPainter*, const QStyleOptionGraphicsItem*, QWidget*);
};

#endif

