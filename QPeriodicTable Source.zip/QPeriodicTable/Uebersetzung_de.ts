<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en_GB">
<context>
    <name>Detail_dialog</name>
    <message>
        <location filename="Detail_dialog.ui" line="23"/>
        <source>QPeriodicTable - Element Details</source>
        <oldsource>QPeriodicTable - Details</oldsource>
        <translation>QPeriodensystem - Elementdetails</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="106"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="111"/>
        <source>Symbol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="33"/>
        <source>Data</source>
        <translation>Daten</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="116"/>
        <source>Atomic number</source>
        <oldsource>Atom number</oldsource>
        <translation>Atomzahl</translation>
    </message>
    <message>
        <source>Mass</source>
        <translation type="obsolete">Masse</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="121"/>
        <source>Relative atomic mass</source>
        <translation>Relative Atommasse</translation>
    </message>
    <message>
        <source>Exact mass</source>
        <translation type="obsolete">Exakte Masse</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="126"/>
        <source>Absolute atomic mass</source>
        <translation>Absolute Atommasse</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="131"/>
        <source>Ionization</source>
        <translation>Ionisation</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="136"/>
        <source>Electron affinity</source>
        <oldsource>Electrons affinity</oldsource>
        <translation>Elektronenaffinität</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="141"/>
        <source>Electronegativity</source>
        <oldsource>Electonegativity</oldsource>
        <translation>Elektronennegativität</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="146"/>
        <source>Covalent radius</source>
        <translation>Kovalenter Radius</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="151"/>
        <source>Van der Waals radius</source>
        <translation>Van der Waals Radius</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="156"/>
        <source>Melting point</source>
        <translation>Schmelzpunkt</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="161"/>
        <source>Boiling point</source>
        <translation>Siedepunkt</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="166"/>
        <source>Family</source>
        <translation>Familie</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="171"/>
        <source>Discovery year</source>
        <oldsource>discovery year</oldsource>
        <translation>Entdeckungsjahr</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="176"/>
        <source>Values</source>
        <translation>Werte</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="187"/>
        <source>Electron shell(s)</source>
        <oldsource>Electron configuration</oldsource>
        <translation>Elektronen Schale(n)</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="207"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="218"/>
        <source>Should not see me</source>
        <translation>Solltest mich nicht sehen</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="230"/>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="240"/>
        <source>Google</source>
        <translation>Google</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="290"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:14pt;&quot;&gt;Disclaimer: The buttons in this area open websites with content for which the team of QPeriodicTable is not responsible!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Disclaimer: The buttons in this area open websites with content for which the team of QPeriodicTable is not responsible!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Disclaimer: Die Buttons in diesem Bereich öffnen Websites für deren Inhalt das QPeriodicTable Entwicklerteam keinerlei Verantwortung trägt!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="Detail_dialog.ui" line="307"/>
        <source>←</source>
        <translation>←</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="310"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message utf8="true">
        <location filename="Detail_dialog.ui" line="323"/>
        <source>→</source>
        <translation>→</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="326"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="Detail_dialog.ui" line="352"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="140"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="146"/>
        <source>http://en.wikipedia.org/wiki/</source>
        <translation>http://de.wikipedia.org/wiki/</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="152"/>
        <source>http://www.google.com/#hl=en&amp;q=</source>
        <translation>http://www.google.de/#hl=de&amp;q=</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="163"/>
        <location filename="Detail_dialog.cpp" line="166"/>
        <location filename="Detail_dialog.cpp" line="169"/>
        <location filename="Detail_dialog.cpp" line="172"/>
        <location filename="Detail_dialog.cpp" line="175"/>
        <location filename="Detail_dialog.cpp" line="178"/>
        <location filename="Detail_dialog.cpp" line="181"/>
        <location filename="Detail_dialog.cpp" line="184"/>
        <location filename="Detail_dialog.cpp" line="187"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="183"/>
        <location filename="Detail_dialog.cpp" line="186"/>
        <source> Kelvin</source>
        <oldsource> Â°Kelvin</oldsource>
        <translation> Kelvin</translation>
    </message>
    <message>
        <location filename="Detail_dialog.cpp" line="197"/>
        <source>Invalid tab index in &quot;void Detail_dialog::setze_index(int wert)&quot;.</source>
        <translation>Ungültiger Tab Index in &quot;void Detail_dialog::setze_index(int wert)&quot;.</translation>
    </message>
</context>
<context>
    <name>Element_aufbau</name>
    <message>
        <location filename="Element_aufbau.cpp" line="91"/>
        <source> Electrons</source>
        <oldsource> Elektrons</oldsource>
        <translation> Elektronen</translation>
    </message>
</context>
<context>
    <name>Legende</name>
    <message>
        <location filename="Legende.cpp" line="68"/>
        <source>Group 1</source>
        <translation>Gruppe 1</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="73"/>
        <source>Group 2</source>
        <translation>Gruppe 2</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="78"/>
        <source>Group 3</source>
        <translation>Gruppe 3</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="83"/>
        <source>Group 4</source>
        <translation>Gruppe 4</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="89"/>
        <source>Group 5</source>
        <translation>Gruppe 5</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="94"/>
        <source>Group 6</source>
        <translation>Gruppe 6</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="99"/>
        <source>Group 7</source>
        <translation>Gruppe 7</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="104"/>
        <source>Group 8</source>
        <translation>Gruppe 8</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="110"/>
        <source>Group 9</source>
        <translation>Gruppe 9</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="115"/>
        <source>Group 10</source>
        <translation>Gruppe 10</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="120"/>
        <source>Group 11</source>
        <translation>Gruppe 11</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="125"/>
        <source>Group 12</source>
        <translation>Gruppe 12</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="131"/>
        <source>Group 13</source>
        <translation>Gruppe 13</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="136"/>
        <source>Group 14</source>
        <translation>Gruppe 14</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="141"/>
        <source>Group 15</source>
        <translation>Gruppe 15</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="146"/>
        <source>Group 16</source>
        <translation>Gruppe 16</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="152"/>
        <source>Group 17</source>
        <translation>Gruppe 17</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="157"/>
        <source>Group 18</source>
        <translation>Gruppe 18</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="163"/>
        <source>Lanthanides</source>
        <translation>Lanthanoiden</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="169"/>
        <source>Actinides</source>
        <translation>Actinoiden</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="199"/>
        <source>Solid</source>
        <translation>Fest</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="204"/>
        <source>Liquid</source>
        <translation>Flüssig</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="209"/>
        <source>Gas</source>
        <translation>Gasförmig</translation>
    </message>
    <message>
        <location filename="Legende.cpp" line="214"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="MainWindow.ui" line="26"/>
        <source>QPeriodicTable</source>
        <oldsource>QPeriodensystem</oldsource>
        <translation>QPeriodensystem</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="66"/>
        <source>Overview</source>
        <translation>Übersicht</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="120"/>
        <location filename="MainWindow.ui" line="424"/>
        <source>Timeline</source>
        <translation>Zeitleiste</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="222"/>
        <source>Temperature</source>
        <oldsource>Temperatur</oldsource>
        <translation>Temperatur</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="210"/>
        <location filename="MainWindow.ui" line="432"/>
        <source>State of matter</source>
        <translation>Aggregatzustand</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="239"/>
        <source> Kelvin</source>
        <oldsource> °Kelvin</oldsource>
        <translation> Kelvin</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="287"/>
        <location filename="MainWindow.ui" line="440"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="374"/>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="381"/>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="392"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="408"/>
        <source>About QT</source>
        <translation>Über QT</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="416"/>
        <source>&amp;Overview</source>
        <translation>&amp;Übersicht</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="445"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="456"/>
        <source>Legend</source>
        <translation>Legende</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="301"/>
        <source>Enter here the name or symbol of a element.</source>
        <oldsource>Gebe hier den Namen, das Symbol oder die Atomzahl des gesuchten Elements ein.</oldsource>
        <translation>Gib hier den Namen oder das Symbol des gesuchten Elements ein.</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="134"/>
        <source>Year</source>
        <translation>Jahr</translation>
    </message>
    <message>
        <location filename="MainWindow.ui" line="403"/>
        <location filename="MainWindow.cpp" line="237"/>
        <source>About QPeriodicTable</source>
        <oldsource>About QPeriodensystem</oldsource>
        <translation>Über QPeriodensystem</translation>
    </message>
    <message>
        <location filename="MainWindow.cpp" line="216"/>
        <source>Unknown value in steuerung_werkzeug_box</source>
        <translation>Unbekannter wert in steuerung_werkzeug_box</translation>
    </message>
    <message>
        <location filename="MainWindow.cpp" line="237"/>
        <source>QPeriodicTable version %1 

Author:	Andreas Konarski
Licence:	gpl v3 or later

Contact:

programmieren@konarski-wuppertal.de
www.konarski-wuppertal.de</source>
        <translation>QPeriodensystem Version %1 

Author:	Andreas Konarski
Lizenz:	gpl v3 oder höher

Kontakt:

programmieren@konarski-wuppertal.de
www.konarski-wuppertal.de</translation>
    </message>
    <message>
        <location filename="MainWindow.cpp" line="306"/>
        <source> Elements</source>
        <translation> Elemente</translation>
    </message>
</context>
<context>
    <name>Scene</name>
    <message>
        <source>gruppenfarben is not ungleich 19 !!!</source>
        <translation type="obsolete">gruppenfarben ist ungleich 19 !!!</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="84"/>
        <source>Agregatzustandsfarben is not equal to 4 !!!</source>
        <oldsource>agregatzustandsfarben is not ungleich 4</oldsource>
        <translation>Agregatzustandsfarben ist ungleich 4 !!!</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="119"/>
        <source>Hydrogen</source>
        <translation>Wasserstoff</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="131"/>
        <location filename="Scene.cpp" line="245"/>
        <location filename="Scene.cpp" line="268"/>
        <location filename="Scene.cpp" line="291"/>
        <location filename="Scene.cpp" line="456"/>
        <location filename="Scene.cpp" line="480"/>
        <source>nonmetals</source>
        <oldsource>nonmetal</oldsource>
        <translation>Nichtmetalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="142"/>
        <source>Helium</source>
        <translation>Helium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="154"/>
        <location filename="Scene.cpp" line="337"/>
        <location filename="Scene.cpp" line="528"/>
        <location filename="Scene.cpp" line="977"/>
        <location filename="Scene.cpp" line="1443"/>
        <location filename="Scene.cpp" line="2306"/>
        <location filename="Scene.cpp" line="3203"/>
        <source>noble gases</source>
        <translation>Edelgase</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="164"/>
        <source>Lithium</source>
        <translation>Lithium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="176"/>
        <location filename="Scene.cpp" line="360"/>
        <location filename="Scene.cpp" line="552"/>
        <location filename="Scene.cpp" line="1002"/>
        <location filename="Scene.cpp" line="1469"/>
        <location filename="Scene.cpp" line="2333"/>
        <source>alkali metals</source>
        <oldsource>alkali metal</oldsource>
        <translation>Alkalimetalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="187"/>
        <source>Beryllium</source>
        <translation>Beryllium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="199"/>
        <location filename="Scene.cpp" line="384"/>
        <location filename="Scene.cpp" line="577"/>
        <location filename="Scene.cpp" line="1028"/>
        <location filename="Scene.cpp" line="1496"/>
        <location filename="Scene.cpp" line="2361"/>
        <source>alkaline earth metals</source>
        <oldsource>alkaline earth metal</oldsource>
        <translation>Erdalkalimetalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="210"/>
        <source>Boron</source>
        <translation>Bor</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="222"/>
        <location filename="Scene.cpp" line="432"/>
        <location filename="Scene.cpp" line="877"/>
        <location filename="Scene.cpp" line="902"/>
        <location filename="Scene.cpp" line="927"/>
        <location filename="Scene.cpp" line="1365"/>
        <location filename="Scene.cpp" line="1391"/>
        <source>metalloids</source>
        <oldsource>metalloid</oldsource>
        <translation>Halbmetalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="233"/>
        <source>Carbon</source>
        <translation>Kohlenstoff</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="256"/>
        <source>Nitrogen</source>
        <translation>Stickstoff</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="279"/>
        <source>Oxygen</source>
        <translation>Sauerstoff</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="302"/>
        <source>Fluorine</source>
        <translation>Fluor</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="314"/>
        <location filename="Scene.cpp" line="504"/>
        <location filename="Scene.cpp" line="952"/>
        <location filename="Scene.cpp" line="1417"/>
        <location filename="Scene.cpp" line="2279"/>
        <location filename="Scene.cpp" line="3173"/>
        <source>halogens</source>
        <oldsource>halogen</oldsource>
        <translation>Halogene</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="325"/>
        <source>Neon</source>
        <translation>Neon</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="348"/>
        <source>Sodium</source>
        <translation>Natrium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="372"/>
        <source>Magnesium</source>
        <translation>Magnesium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="396"/>
        <source>Aluminium</source>
        <translation>Aluminium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="408"/>
        <location filename="Scene.cpp" line="852"/>
        <location filename="Scene.cpp" line="1313"/>
        <location filename="Scene.cpp" line="1339"/>
        <location filename="Scene.cpp" line="2171"/>
        <location filename="Scene.cpp" line="2198"/>
        <location filename="Scene.cpp" line="2225"/>
        <location filename="Scene.cpp" line="2252"/>
        <location filename="Scene.cpp" line="3061"/>
        <location filename="Scene.cpp" line="3089"/>
        <location filename="Scene.cpp" line="3117"/>
        <location filename="Scene.cpp" line="3145"/>
        <source>metals</source>
        <oldsource>other metal</oldsource>
        <translation>Metalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="420"/>
        <source>Silicon</source>
        <translation>Silizium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="444"/>
        <source>Phosphorus</source>
        <translation>Phosphor</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="468"/>
        <source>Sulfur</source>
        <translation>Schwefel</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="492"/>
        <source>Chlorine</source>
        <translation>Chlor</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="516"/>
        <source>Argon</source>
        <translation>Argon</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="540"/>
        <source>Potassium</source>
        <translation>Kalium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="565"/>
        <source>Calcium</source>
        <translation>Kalzium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="590"/>
        <source>Scandium</source>
        <translation>Scandium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="602"/>
        <location filename="Scene.cpp" line="627"/>
        <location filename="Scene.cpp" line="652"/>
        <location filename="Scene.cpp" line="677"/>
        <location filename="Scene.cpp" line="702"/>
        <location filename="Scene.cpp" line="727"/>
        <location filename="Scene.cpp" line="752"/>
        <location filename="Scene.cpp" line="777"/>
        <location filename="Scene.cpp" line="802"/>
        <location filename="Scene.cpp" line="827"/>
        <location filename="Scene.cpp" line="1054"/>
        <location filename="Scene.cpp" line="1080"/>
        <location filename="Scene.cpp" line="1106"/>
        <location filename="Scene.cpp" line="1132"/>
        <location filename="Scene.cpp" line="1158"/>
        <location filename="Scene.cpp" line="1184"/>
        <location filename="Scene.cpp" line="1210"/>
        <location filename="Scene.cpp" line="1236"/>
        <location filename="Scene.cpp" line="1261"/>
        <location filename="Scene.cpp" line="1287"/>
        <location filename="Scene.cpp" line="1928"/>
        <location filename="Scene.cpp" line="1955"/>
        <location filename="Scene.cpp" line="1982"/>
        <location filename="Scene.cpp" line="2009"/>
        <location filename="Scene.cpp" line="2036"/>
        <location filename="Scene.cpp" line="2063"/>
        <location filename="Scene.cpp" line="2090"/>
        <location filename="Scene.cpp" line="2117"/>
        <location filename="Scene.cpp" line="2144"/>
        <location filename="Scene.cpp" line="2809"/>
        <location filename="Scene.cpp" line="2837"/>
        <location filename="Scene.cpp" line="2865"/>
        <location filename="Scene.cpp" line="2893"/>
        <location filename="Scene.cpp" line="2921"/>
        <location filename="Scene.cpp" line="2949"/>
        <location filename="Scene.cpp" line="2977"/>
        <location filename="Scene.cpp" line="3005"/>
        <location filename="Scene.cpp" line="3033"/>
        <source>transition metals</source>
        <oldsource>transition metal</oldsource>
        <translation>Übergangsmetalle</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="615"/>
        <source>Titanium</source>
        <translation>Titan</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="640"/>
        <source>Vanadium</source>
        <translation>Vanadium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="665"/>
        <source>Chromium</source>
        <translation>Chrom</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="690"/>
        <source>Manganese</source>
        <translation>Mangan</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="715"/>
        <source>Iron</source>
        <translation>Eisen</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="740"/>
        <source>Cobalt</source>
        <translation>Kobalt</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="765"/>
        <source>Nickel</source>
        <translation>Nickel</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="790"/>
        <source>Copper</source>
        <translation>Kupfer</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="815"/>
        <source>Zinc</source>
        <translation>Zink</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="840"/>
        <source>Gallium</source>
        <translation>Gallium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="865"/>
        <source>Germanium</source>
        <translation>Germanium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="890"/>
        <source>Arsenic</source>
        <translation>Arsen</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="915"/>
        <source>Selenium</source>
        <translation>Selen</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="940"/>
        <source>Bromine</source>
        <translation>Brom</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="965"/>
        <source>Krypton</source>
        <translation>Krypton</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="990"/>
        <source>Rubidium</source>
        <translation>Rubidium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1016"/>
        <source>Strontium</source>
        <translation>Strontium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1042"/>
        <source>Yttrium</source>
        <translation>Yttrium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1068"/>
        <source>Zirconium</source>
        <translation>Zirconium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1094"/>
        <source>Niobium</source>
        <translation>Niob</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1120"/>
        <source>Molybdenum</source>
        <translation>Molybdän</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1146"/>
        <source>Technetium</source>
        <translation>Technetium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1172"/>
        <source>Ruthenium</source>
        <translation>Ruthenium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1198"/>
        <source>Rhodium</source>
        <translation>Rhodium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1224"/>
        <source>Palladium</source>
        <translation>Palladium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1249"/>
        <source>Silver</source>
        <translation>Silber</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1275"/>
        <source>Cadmium</source>
        <translation>Cadmium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1301"/>
        <source>Indium</source>
        <translation>Indium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1327"/>
        <source>Tin</source>
        <translation>Zinn</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1353"/>
        <source>Antimony</source>
        <translation>Antimon</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1379"/>
        <source>Tellurium</source>
        <translation>Tellur</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1405"/>
        <source>Iodine</source>
        <translation>Iod</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1431"/>
        <source>Xenon</source>
        <translation>Xenon</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1457"/>
        <source>Caesium</source>
        <translation>Cäsium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1484"/>
        <source>Barium</source>
        <translation>Barium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1511"/>
        <source>Lanthanum</source>
        <translation>Lanthan</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1538"/>
        <source>Cerium</source>
        <translation>Cer</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3161"/>
        <source>Ununseptium</source>
        <translation>Ununseptium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3190"/>
        <source>Ununoctium</source>
        <translation>Ununoctium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1523"/>
        <location filename="Scene.cpp" line="1550"/>
        <location filename="Scene.cpp" line="1577"/>
        <location filename="Scene.cpp" line="1604"/>
        <location filename="Scene.cpp" line="1631"/>
        <location filename="Scene.cpp" line="1658"/>
        <location filename="Scene.cpp" line="1685"/>
        <location filename="Scene.cpp" line="1712"/>
        <location filename="Scene.cpp" line="1739"/>
        <location filename="Scene.cpp" line="1766"/>
        <location filename="Scene.cpp" line="1793"/>
        <location filename="Scene.cpp" line="1820"/>
        <location filename="Scene.cpp" line="1847"/>
        <location filename="Scene.cpp" line="1874"/>
        <location filename="Scene.cpp" line="1901"/>
        <source>lanthanides</source>
        <oldsource>lanthaniden</oldsource>
        <translation>Lanthanoiden</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="72"/>
        <source>Gruppenfarben is not equal to 21 !!!</source>
        <oldsource>Number of gruppenfarben is not 21 !!!</oldsource>
        <translation>Anzahl der Gruppenfarben ist nicht 21 !!!</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1565"/>
        <source>Praseodymium</source>
        <translation>Praseodym</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1592"/>
        <source>Neodymium</source>
        <translation>Neodym</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1619"/>
        <source>Promethium</source>
        <translation>Promethium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1646"/>
        <source>Samarium</source>
        <translation>Samarium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1673"/>
        <source>Europium</source>
        <translation>Europium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1700"/>
        <source>Gadolinium</source>
        <translation>Gadolinium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1727"/>
        <source>Terbium</source>
        <translation>Terbium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1754"/>
        <source>Dysprosium</source>
        <translation>Dysprosium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1781"/>
        <source>Holmium</source>
        <translation>Holmium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1808"/>
        <source>Erbium</source>
        <translation>Erbium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1835"/>
        <source>Thulium</source>
        <translation>Thulium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1862"/>
        <source>Ytterbium</source>
        <translation>Ytterbium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1889"/>
        <source>Lutetium</source>
        <translation>Lutetium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1916"/>
        <source>Hafnium</source>
        <translation>Hafnium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1943"/>
        <source>Tantalum</source>
        <translation>Tantal</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1970"/>
        <source>Tungsten</source>
        <translation>Wolfram</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="1997"/>
        <source>Rhenium</source>
        <translation>Rhenium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2024"/>
        <source>Osmium</source>
        <translation>Osmium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2051"/>
        <source>Iridium</source>
        <translation>Iridium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2078"/>
        <source>Platinum</source>
        <translation>Platin</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2105"/>
        <source>Gold</source>
        <translation>Gold</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2132"/>
        <source>Mercury</source>
        <translation>Quecksilber</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2159"/>
        <source>Thallium</source>
        <translation>Thallium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2186"/>
        <source>Lead</source>
        <translation>Blei</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2213"/>
        <source>Bismuth</source>
        <translation>Bismuth</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2240"/>
        <source>Polonium</source>
        <translation>Polonium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2267"/>
        <source>Astatine</source>
        <translation>Astat</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2294"/>
        <source>Radon</source>
        <translation>Radon</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2321"/>
        <source>Francium</source>
        <translation>Francium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2349"/>
        <source>Radium</source>
        <translation>Radium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2377"/>
        <source>Actinium</source>
        <translation>Actinium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2405"/>
        <source>Thorium</source>
        <translation>Thorium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2389"/>
        <location filename="Scene.cpp" line="2417"/>
        <location filename="Scene.cpp" line="2445"/>
        <location filename="Scene.cpp" line="2473"/>
        <location filename="Scene.cpp" line="2501"/>
        <location filename="Scene.cpp" line="2529"/>
        <location filename="Scene.cpp" line="2557"/>
        <location filename="Scene.cpp" line="2585"/>
        <location filename="Scene.cpp" line="2613"/>
        <location filename="Scene.cpp" line="2641"/>
        <location filename="Scene.cpp" line="2669"/>
        <location filename="Scene.cpp" line="2697"/>
        <location filename="Scene.cpp" line="2725"/>
        <location filename="Scene.cpp" line="2753"/>
        <location filename="Scene.cpp" line="2781"/>
        <source>actinides</source>
        <oldsource>actinide</oldsource>
        <translation>Actinoiden</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2433"/>
        <source>Protactinium</source>
        <translation>Protactinium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2461"/>
        <source>Uranium</source>
        <translation>Uran</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2489"/>
        <source>Neptunium</source>
        <translation>Neptunium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2517"/>
        <source>Plutonium</source>
        <translation>Plutonium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2545"/>
        <source>Americium</source>
        <translation>Americium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2573"/>
        <source>Curium</source>
        <translation>Curium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2601"/>
        <source>Berkelium</source>
        <translation>Berkelium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2629"/>
        <source>Californium</source>
        <translation>Californium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2657"/>
        <source>Einsteinium</source>
        <translation>Einsteinium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2685"/>
        <source>Fermium</source>
        <translation>Fermium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2713"/>
        <source>Mendelevium</source>
        <translation>Mendelevium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2741"/>
        <source>Nobelium</source>
        <translation>Nobelium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2769"/>
        <source>Lawrencium</source>
        <translation>Lawrencium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2797"/>
        <source>Rutherfordium</source>
        <translation>Rutherfordium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2825"/>
        <source>Dubnium</source>
        <translation>Dubnium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2853"/>
        <source>Seaborgium</source>
        <translation>Seaborgium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2881"/>
        <source>Bohrium</source>
        <translation>Bohrium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2909"/>
        <source>Hassium</source>
        <translation>Hassium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2937"/>
        <source>Meitnerium</source>
        <translation>Meitnerium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2965"/>
        <source>Darmstadtium</source>
        <translation>Darmstadtium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="2993"/>
        <source>Roentgenium</source>
        <translation>Röntgenium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3021"/>
        <source>Copernicium</source>
        <translation>Copernicium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3049"/>
        <source>Ununtrium</source>
        <translation>Ununtrium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3077"/>
        <source>Ununquadium</source>
        <translation>Ununquadium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3105"/>
        <source>Ununpentium</source>
        <translation>Ununpentium</translation>
    </message>
    <message>
        <location filename="Scene.cpp" line="3133"/>
        <source>Ununhexium</source>
        <translation>Ununhexium</translation>
    </message>
</context>
</TS>
