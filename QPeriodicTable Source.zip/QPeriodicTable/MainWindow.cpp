#include "MainWindow.h"
#include "Scene.h"
#include "Detail_dialog.h"
#include <QMessageBox>
#include <QSettings>
#include <QLabel>
#include <QDebug>
#include <QActionGroup>

#define UEBERSICHT_POSITION 0
#define ZEITLEISTE_POSITION 1
#define AGREGATZUSTAND_POSITION 2
#define SUCHE_POSITION 3

using namespace std;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    // die benutzeroberflaeche aufbauen
    setupUi(this);

    // osx spezifische einstellungen vornehmen
#ifdef Q_WS_MAC

    setUnifiedTitleAndToolBarOnMac(true);

#endif

    // unter macos soll menu_datei samt inhalt nicht zu sehen sein wenn nur action_schliessen enthalten ist
#ifdef Q_OS_MAC

    action_schliessen->setVisible(false);
    if (menu_datei->actions().size() == 1 && menu_datei->actions().first() == action_schliessen) menu_datei->menuAction()->setVisible(false);

#endif

    // scene erstellen
    scene = new Scene(viewer);

    // einstellungen erzeugen
    einstellungen = new QSettings("konarski-wuppertal", "QPeriodicTable", this);

    // detaildialog erstellen
    details = new Detail_dialog(this);

    // elementzahl_label erzeugen ...
    elementzahl_label = new QLabel(this);

    // die elementliste in details erzeugen
    details->registriere_elementliste(scene->get_elementliste());
    details->registriere_scene(scene);

    // ... und der statusleiste als permanentes widget hinzufuegen
    statusBar()->addPermanentWidget(elementzahl_label);

    // action_uebersicht, action_zeitleiste, action_agregatzustand und action_suche zu einer gruppe verbinden
    QActionGroup *ansicht_gruppe = new QActionGroup(this);
    ansicht_gruppe->addAction(action_uebersicht);
    ansicht_gruppe->addAction(action_zeitleiste);
    ansicht_gruppe->addAction(action_agregatzustand);
    ansicht_gruppe->addAction(action_suche);

    // signal - slot verbindungen
    // action_schliessen ermoeglichen
    connect(action_schliessen, SIGNAL(triggered(bool)), this, SLOT(close()));

    // action_about ermoeglichen
    connect(action_about, SIGNAL(triggered(bool)), this, SLOT(about()));

    // action_about_qt ermoeglichen
    connect(action_about_qt, SIGNAL(triggered(bool)), qApp, SLOT(aboutQt()));

    // das steuern der farbe ermoeglichen
    connect(werkzeug_box, SIGNAL(currentChanged(int)), this, SLOT(steuerung_werkzeug_box(int)));

    // das aendern der temperatur ermoeglichen
    connect(temperatur_box, SIGNAL(valueChanged(double)), scene, SLOT(zeige_temperatur(double)));

    // verbindung der temperatur box mit dem temperatur slider ermoeglichen
    connect(temperatur_slider, SIGNAL(valueChanged(int)), this, SLOT(steuerung_temperatur_slider(int)));
    connect(temperatur_box, SIGNAL(valueChanged(double)), this, SLOT(steuerung_temperatur_box(double)));

    // das anzeigen der daten des ausgewaehlten elements in uebersicht ermoeglichen
    connect(scene, SIGNAL(aktiviert(Element*)), uebersicht_1, SLOT(zeige(Element*)));
    connect(scene, SIGNAL(aktiviert(Element*)), uebersicht_2, SLOT(zeige(Element*)));
    connect(scene, SIGNAL(aktiviert(Element*)), uebersicht_3, SLOT(zeige(Element*)));
    connect(scene, SIGNAL(aktiviert(Element*)), uebersicht_4, SLOT(zeige(Element*)));

    // das senden des jahres ermoeglichen
    connect(zeit_box, SIGNAL(valueChanged(int)), this, SIGNAL(jahr(int)));
    connect(this, SIGNAL(jahr(int)), scene, SIGNAL(jahr(int)));

    // das setzen der seite von legende ermoeglichen
    connect(werkzeug_box, SIGNAL(currentChanged(int)), scene, SLOT(legende_setze_seite(int)));

    // das vearbeiten von sucheingaben ermoeglichen
    connect(suche_edit, SIGNAL(textChanged(const QString&)), this, SIGNAL(suche(const QString&)));
    connect(this, SIGNAL(suche(const QString&)), scene, SIGNAL(suche(const QString&)));

    // das anzeigen von detailinformationen in detail ermoeglichen
    connect(scene, SIGNAL(doppelgeklickt(Element*)), details, SLOT(zeige(Element*)));
    connect(uebersicht_1, SIGNAL(doppelgeklickt(Element*)), details, SLOT(zeige(Element*)));
    connect(uebersicht_2, SIGNAL(doppelgeklickt(Element*)), details, SLOT(zeige(Element*)));
    connect(uebersicht_3, SIGNAL(doppelgeklickt(Element*)), details, SLOT(zeige(Element*)));
    connect(uebersicht_4, SIGNAL(doppelgeklickt(Element*)), details, SLOT(zeige(Element*)));

    // das anzeigen der elementzahl ermoeglichen
    connect(scene, SIGNAL(vorhandene_elemente_geaendert(int)), this, SLOT(zeige_elementzahl(int)));

    // den uebersichten ermoeglichen, auf aenderung der sichtbaren elemente zu reagieren
    connect(scene, SIGNAL(vorhandene_elemente_geaendert(const QList<Element*>&)), uebersicht_1, SLOT(vorhandene_elemente_geaendert(const QList<Element*>&)));
    connect(scene, SIGNAL(vorhandene_elemente_geaendert(const QList<Element*>&)), uebersicht_2, SLOT(vorhandene_elemente_geaendert(const QList<Element*>&)));
    connect(scene, SIGNAL(vorhandene_elemente_geaendert(const QList<Element*>&)), uebersicht_3, SLOT(vorhandene_elemente_geaendert(const QList<Element*>&)));
    connect(scene, SIGNAL(vorhandene_elemente_geaendert(const QList<Element*>&)), uebersicht_4, SLOT(vorhandene_elemente_geaendert(const QList<Element*>&)));

    // das synchron halten von detail dialog mit den uebersichten ermoeglichen
    connect(details, SIGNAL(angezeigt(Element*)), uebersicht_1, SLOT(zeige(Element*)));
    connect(details, SIGNAL(angezeigt(Element*)), uebersicht_2, SLOT(zeige(Element*)));
    connect(details, SIGNAL(angezeigt(Element*)), uebersicht_3, SLOT(zeige(Element*)));
    connect(details, SIGNAL(angezeigt(Element*)), uebersicht_4, SLOT(zeige(Element*)));

    // den ansichtsaktionen das steuern der werkzeugbox ermoeglichen
    connect(action_uebersicht, SIGNAL(triggered(bool)), this, SLOT(zeige_uebersicht()));
    connect(action_zeitleiste, SIGNAL(triggered(bool)), this, SLOT(zeige_zeitleiste()));
    connect(action_agregatzustand, SIGNAL(triggered(bool)), this, SLOT(zeige_agregatzustand()));
    connect(action_suche, SIGNAL(triggered(bool)), this, SLOT(zeige_suche()));

    // die steuerung der sichtbarkeit der legende ermoeglichen
    connect(action_legende, SIGNAL(triggered(bool)), scene, SLOT(setze_sichtbarkeit_legende(bool)));

    // uebersicht mit wasserstoff (atomzahl 1) initialisieren
    uebersicht_1->zeige(scene->get_element(1));
    uebersicht_2->zeige(scene->get_element(1));
    uebersicht_3->zeige(scene->get_element(1));
    uebersicht_4->zeige(scene->get_element(1));
    zeige_elementzahl(scene->elementzahl());

    // weitere initialisierungen
    action_uebersicht->trigger();

    einstellungen_laden();
}


void MainWindow::steuerung_werkzeug_box(int wert)
{
    switch (wert)
    {
    // es wird die uebersicht angezeigt
    case UEBERSICHT_POSITION:

        // sicherstellen das die position der werkzeug_box stimmt
        if (werkzeug_box->currentIndex() != UEBERSICHT_POSITION)werkzeug_box->setCurrentIndex(UEBERSICHT_POSITION);

        action_uebersicht->setChecked(true);

        scene->zeige_gruppenfarbe();

        emit jahr(2010);
        emit suche("");

        break;


        // es wird die zeitleiste angezeigt
    case ZEITLEISTE_POSITION:

        // sicherstellen das die position der werkzeug_box stimmt
        if (werkzeug_box->currentIndex() != ZEITLEISTE_POSITION)werkzeug_box->setCurrentIndex(ZEITLEISTE_POSITION);

        action_zeitleiste->setChecked(true);

        scene->zeige_gruppenfarbe();

        emit suche("");
        emit jahr(zeit_box->value());

        break;


        // es wird der agrgatzustand angezeigt
    case AGREGATZUSTAND_POSITION:

        // sicherstellen das die position der werkzeug_box stimmt
        if (werkzeug_box->currentIndex() != AGREGATZUSTAND_POSITION)werkzeug_box->setCurrentIndex(AGREGATZUSTAND_POSITION);

        action_agregatzustand->setChecked(true);

        scene->zeige_agregatzustandfarbe(temperatur_box->value());

        emit jahr(2010);
        emit suche("");

        break;


        // es wird die suche angezeigt
    case SUCHE_POSITION:

        // sicherstellen das die position der werkzeug_box stimmt
        if (werkzeug_box->currentIndex() != SUCHE_POSITION)werkzeug_box->setCurrentIndex(SUCHE_POSITION);

        action_suche->setChecked(true);

        scene->zeige_gruppenfarbe();

        emit jahr(2010);
        emit suche(suche_edit->text());

        break;


        // fehler behandlung - sollte niemals eintreten
    default:

        qDebug() << tr("Unknown value in steuerung_werkzeug_box");

        break;
    }
}


void MainWindow::steuerung_temperatur_slider(int wert)
{
    if (wert != (int) temperatur_box->value()) temperatur_box->setValue((double) wert);
}


void MainWindow::steuerung_temperatur_box(double wert)
{
    temperatur_slider->setValue((int) wert);
}


void MainWindow::about()
{
    QMessageBox::about(this, tr("About QPeriodicTable"), tr("QPeriodicTable version %1 \n\nAuthor:\tAndreas Konarski\nLicence:\tgpl v3 or later\n\nContact:\n\nprogrammieren@konarski-wuppertal.de\nwww.konarski-wuppertal.de").arg(VERSION));
}


MainWindow::~MainWindow()
{
    einstellungen_speichern();
}


void MainWindow::einstellungen_laden()
{
    // die fenstergeometrie laden
    restoreGeometry(einstellungen->value("Hauptfenster/geometry").toByteArray());

    // die groesse des detail dialog laden
    details->resize(einstellungen->value("details/groesse", details->size()).toSize());

    // den wert von zeit_box laden
    zeit_box->setValue(einstellungen->value("Hauptfenster/zeit_box", zeit_box->maximum()).toInt());

    // den wert der temperatur_box laden
    temperatur_box->setValue(einstellungen->value("Haupfenster/temperatur_box", 0).toDouble());

    // den wert von suche_edit laden
    suche_edit->setText(einstellungen->value("Hauptfenster/suche_edit", "").toString());

    // den index der werkzeug_box laden
    steuerung_werkzeug_box(einstellungen->value("Hauptfenster/werkzeug_box", UEBERSICHT_POSITION).toInt());

    // sichtbarkeit der legende laden
    action_legende->setChecked(einstellungen->value("Scene/legende", true).toBool());
    scene->setze_sichtbarkeit_legende(einstellungen->value("Scene/legende", true).toBool());

    // index von details laden
    details->setze_index(einstellungen->value("Detail_dialog/index", 0).toInt());
}


void MainWindow::einstellungen_speichern()
{
    // die fenstergeometrie speichern
    einstellungen->setValue("Hauptfenster/geometry", saveGeometry());

    // die groesse des detail dialog speichern
    einstellungen->setValue("details/groesse", details->size());

    // den wert von zeit_box speichern
    einstellungen->setValue("Hauptfenster/zeit_box", zeit_box->value());

    // den wert der temperatur_box
    einstellungen->setValue("Haupfenster/temperatur_box", temperatur_box->value());

    // den wert von suche_edit speichern
    einstellungen->setValue("Hauptfenster/suche_edit", suche_edit->text());

    // den index der werkzeug_box speichern
    einstellungen->setValue("Hauptfenster/werkzeug_box", werkzeug_box->currentIndex());

    // sichtbarkeit der legende speichern
    einstellungen->setValue("Scene/legende", scene->sichtbarkeit_legende());

    // index von details speichern
    einstellungen->setValue("Detail_dialog/index", details->index());
}


void MainWindow::zeige_elementzahl(int wert)
{
    elementzahl_label->setText(QString::number(wert) + tr(" Elements"));
}


void MainWindow::zeige_uebersicht()
{
    werkzeug_box->setCurrentIndex(UEBERSICHT_POSITION);
}


void MainWindow::zeige_zeitleiste()
{
    werkzeug_box->setCurrentIndex(ZEITLEISTE_POSITION);
}


void MainWindow::zeige_agregatzustand()
{
    werkzeug_box->setCurrentIndex(AGREGATZUSTAND_POSITION);
}


void MainWindow::zeige_suche()
{
    werkzeug_box->setCurrentIndex(SUCHE_POSITION);
}

