/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef ELEMENT_AUFBAU_H
#define ELEMENT_AUFBAU_H

#include <QWidget>

class Element;

class Element_aufbau : public QWidget
{
    Q_OBJECT

public:
    Element_aufbau(QWidget *parent = 0);
    virtual ~Element_aufbau();

public slots:
    void zeige(Element*);

private:
    virtual void paintEvent(QPaintEvent*);

    Element *aktives_element;
};

#endif

