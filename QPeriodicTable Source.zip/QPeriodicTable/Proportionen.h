/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef PROPORTIONEN_H
#define PROPORTIONEN_H


#define ELEMENT_GROESSE 50

#define ELEMENT_AUFBAU_RINGE 7
#define ELEMENT_AUFBAU_RAND 10

#define LEGENDE_BREITE 480
#define LEGENDE_HOEHE 140
#define LEGENDE_RAND 20

#define SCENE_RAND 10


#endif

