#include "Uebersicht.h"
#include "Element.h"
#include "Proportionen.h"
#include <QPainter>

using namespace std;

Uebersicht::Uebersicht(QWidget *parent) : QWidget(parent), aktuelles_element(0)
{
    setFixedSize(214, 214);
}


Uebersicht::~Uebersicht()
{
}


void Uebersicht::zeige(Element* element)
{
    if (element != aktuelles_element)
    {
        aktuelles_element = element;

        update();
    }
}


void Uebersicht::paintEvent(QPaintEvent*)
{
    if (aktuelles_element != 0)
    {
        QPainter painter(this);

        // mit antialiasing
        painter.setRenderHint(QPainter::Antialiasing);

        // die hintergrundfarbe soll der gruppenfarbe des aktuellen elements entsprechen
        painter.setBrush(aktuelles_element->gruppenfarbe());

        // den rahmen malen
        painter.drawRect(QRectF(0, 0, width(), height()));



        // den font fuer das zeichen setzen
        QFont font(painter.font());

        // fuer mac osx
#ifdef Q_OS_MAC

        font.setPointSizeF((double) width() * 0.5);

        // fuer windows
#elif defined Q_OS_WIN

        font.setPointSizeF((double) width() * 0.4);

        // ansonsten
#else

        font.setPointSizeF((double) width() * 0.3);

#endif

        painter.setFont(font);



        // das zeichen malen
        painter.drawText(QRectF(0, 0, width(), height()), Qt::AlignCenter, aktuelles_element->symbol());



        // den font fuer den elementnamen und gruppe setzen
        // fuer mac osx
#ifdef Q_OS_MAC

        font.setPointSizeF((double) width() * 0.05827);

        // fuer windows
#elif defined Q_OS_WIN

        font.setPointSizeF((double) width() * 0.042);
        font.setBold(true);

        // ansonsten
#else

        font.setPointSizeF((double) width() * 0.042);

#endif

        painter.setFont(font);



        // den elementnamen malen
        painter.drawText(QRectF(2, 2, width(), font.pointSizeF() * 3), Qt::AlignLeft, aktuelles_element->element_name());

        // die gruppe malen
        painter.drawText(QRectF(2, 2, width() - 3, font.pointSizeF() * 3), Qt::AlignRight, aktuelles_element->familie());



        // den font fuer die atomzahl setzen
        // fuer mac osx
#ifdef Q_OS_MAC

        font.setPointSizeF((double) width() * 0.05827);

        // fuer windows
#elif defined Q_OS_WIN

        font.setPointSizeF((double) width() * 0.050);
        font.setBold(true);

        // ansonsten
#else

        font.setPointSizeF((double) width() * 0.045);

#endif

        painter.setFont(font);



        // die atomzahl malen
        if (aktuelles_element->symbol().size() == 1)
        {
            QPointF mitte((double) width() / 2, (double) height() / 2);

            mitte.setX(mitte.x() - (double) width() * 0.25);
            mitte.setY(mitte.y() - (double) height() * 0.23);

            painter.drawText(mitte, QString::number(aktuelles_element->atomzahl()));
        }

        else if (aktuelles_element->symbol().size() == 2)
        {
            QPointF mitte((double) width() / 2, (double) height() / 2);

            mitte.setX(mitte.x() - (double) width() * 0.40);
            mitte.setY(mitte.y() - (double) height() * 0.23);

            painter.drawText(mitte, QString::number(aktuelles_element->atomzahl()));
        }

        else if (aktuelles_element->symbol().size() == 3)
        {
            QPointF mitte((double) width() / 2, (double) height() / 2);

            mitte.setX(mitte.x() - (double) width() * 0.49);
            mitte.setY(mitte.y() - (double) height() * 0.23);

            painter.drawText(mitte, QString::number(aktuelles_element->atomzahl()));
        }



        // den font fuer die masse setzen
        // fuer mac osx
#ifdef Q_OS_MAC

        font.setPointSizeF((double) width() * 0.05827);

        // fuer windows
#elif defined Q_OS_WIN

        font.setPointSizeF((double) width() * 0.050);
        font.setBold(true);

        // ansonsten
#else

        font.setPointSizeF((double) width() * 0.045);

#endif

        painter.setFont(font);



        // die masse malen
        painter.drawText(QRectF(QPointF(0, height() - (font.pointSizeF() * 2)), QPointF(width() - 2, height() - 2)), Qt::AlignRight, QString(aktuelles_element->masse()).remove(" u"));
    }
}


void Uebersicht::mouseDoubleClickEvent(QMouseEvent* event)
{
    QWidget::mouseDoubleClickEvent(event);

    if (aktuelles_element != 0) emit doppelgeklickt(aktuelles_element);
}


void Uebersicht::vorhandene_elemente_geaendert(const QList<Element*>& liste)
{
    if (liste.contains(aktuelles_element) == false && liste.isEmpty() == false) zeige(liste.first());

    else if (liste.isEmpty() == true) zeige(0);
}

