/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef DETAIL_DIALOG_H
#define DETAIL_DIALOG_H

#include <QDialog>
#include <QMap>
#include "ui_Detail_dialog.h"

class Element;
class Scene;

class Detail_dialog : public QDialog, private Ui::Detail_dialog
{
    Q_OBJECT

public:
    Detail_dialog(QWidget *parent = 0);
    virtual ~Detail_dialog();

    void registriere_elementliste(const QMap<int, Element*>&);
    void registriere_scene(Scene*);

public slots:
    void zeige(Element*);
    void vorwaerts();
    void rueckwaerts();
    void oeffne_wikipedia();
    void oeffne_google();
    void setze_index(int);
    int index() const;

signals:
    void angezeigt(Element*);

private:
    Element *letztes_element;
    QMap<int, Element*> elementliste;
    Scene *scene;

    void baue_liste_auf(Element*);
    void setze_links(Element*);
};

#endif

