#include "Detail_dialog.h"
#include "Element.h"
#include "Scene.h"
#include <QTableWidgetItem>
#include <climits>
#include <QDesktopServices>
#include <QUrl>
#include <QDebug>

#define NAME_POSITION 0
#define SYMBOL_POSITION 1
#define ATOMZAHL_POSITION 2
#define MASSE_POSITION 3
#define EXAKTE_MASSE_POSITION 4
#define IONISATION_POSITION 5
#define ELEKTRONEN_AFFINITAET_POSITION 6
#define ELEKTRONEN_NEGATIVITAET_POSITION 7
#define KOVALENTER_POSITION 8
#define VAN_DER_WAALS_POSITION 9
#define SCHMELZPUNKT_POSITION 10
#define SIEDEPUNKT_POSITION 11
#define FAMILIE_POSITION 12
#define ENTDECKUNGSJAHR_POSITION 13

using namespace std;

Detail_dialog::Detail_dialog(QWidget *parent) : QDialog(parent), scene(0)
{
    setupUi(this);

    // werte_tabelle mit elementen befuellen
    for (register int idx = 0; idx < werte_tabelle->rowCount(); idx++) werte_tabelle->setItem(idx, 0, new QTableWidgetItem("leer"));

    // signal - slot verbindungen
    // vor_button ermoeglichen
    connect(vor_button, SIGNAL(clicked()), this, SLOT(vorwaerts()));

    // zurueck_button ermoeglichen
    connect(zurueck_button, SIGNAL(clicked()), this, SLOT(rueckwaerts()));

    // wikipedia_button ermoeglichen
    connect(wikipedia_button, SIGNAL(clicked()), this, SLOT(oeffne_wikipedia()));

    // google_button ermoeglichen
    connect(google_button, SIGNAL(clicked()), this, SLOT(oeffne_google()));
}


Detail_dialog::~Detail_dialog()
{
}


void Detail_dialog::zeige(Element* element)
{
    if (element != 0)
    {
        if (element != letztes_element)
        {
            uebersicht->zeige(element);

            baue_liste_auf(element);

            // wenn es sich um ein anderes element wie beim letzten mal handelt zum ersten element scrollen
            if (letztes_element != 0 && letztes_element != element)
            {
                werte_tabelle->scrollToItem(werte_tabelle->item(NAME_POSITION, 0), QAbstractItemView::PositionAtTop);

                // if (in_schleife == false) auswahl_tab->setCurrentIndex(0);
            }

            letztes_element = element;

            aufbau->zeige(element);

            setze_links(element);

            emit angezeigt(element);
        }

        show();
    }
}


void Detail_dialog::registriere_elementliste(const QMap<int, Element*>& liste)
{
    elementliste = liste;
}


void Detail_dialog::vorwaerts()
{
    if (letztes_element != 0 && scene->elementzahl() > 0)
    {

        do
        {
            if ((letztes_element->atomzahl() + 1) <= elementliste.size() && elementliste.contains(letztes_element->atomzahl() + 1) == true) zeige(elementliste.value(letztes_element->atomzahl() + 1));

            else if (elementliste.contains(1) == true) zeige(elementliste.value(1));

        } while(letztes_element->scene() == 0);
    }
}


void Detail_dialog::rueckwaerts()
{
    if (letztes_element != 0 && scene->elementzahl() > 0)
    {

        do
        {
            if ((letztes_element->atomzahl() - 1) > 0 && elementliste.contains(letztes_element->atomzahl() - 1) == true) zeige(elementliste.value(letztes_element->atomzahl() - 1));

            else if (elementliste.contains(elementliste.size()) == true) zeige(elementliste.value(elementliste.size()));

        } while(letztes_element->scene() == 0);
    }
}


void Detail_dialog::registriere_scene(Scene* scene_)
{
    scene = scene_;
}


void Detail_dialog::setze_links(Element* element)
{
    // wikipedia_buton
    if (letztes_element->element_name().isEmpty() == true) wikipedia_button->setEnabled(false);
    else wikipedia_button->setEnabled(true);

    if (element->element_name().isEmpty() == true) google_button->setEnabled(false);
    else google_button->setEnabled(true);

    if (element->element_name().isEmpty() == false) web_elementname_label->setText(element->element_name());
    else web_elementname_label->setText(tr("Error"));
}


void Detail_dialog::oeffne_wikipedia()
{
    if (letztes_element != 0 && letztes_element->element_name().isEmpty() == false) QDesktopServices::openUrl(QUrl(tr("http://en.wikipedia.org/wiki/") + letztes_element->element_name()));
}


void Detail_dialog::oeffne_google()
{
    if (letztes_element != 0 && letztes_element->element_name().isEmpty() == false) QDesktopServices::openUrl(QUrl(tr("http://www.google.com/#hl=en&q=") + letztes_element->element_name()));
}


void Detail_dialog::baue_liste_auf(Element* element)
{
    werte_tabelle->item(NAME_POSITION, 0)->setText(element->element_name());
    werte_tabelle->item(SYMBOL_POSITION, 0)->setText(element->symbol());
    werte_tabelle->item(ATOMZAHL_POSITION, 0)->setText(QString::number(element->atomzahl()));

    if (element->masse() != "-1") werte_tabelle->item(MASSE_POSITION, 0)->setText(element->masse());
    else werte_tabelle->item(MASSE_POSITION, 0)->setText(tr("Unknown"));

    if (element->exakte_masse() != "-1") werte_tabelle->item(EXAKTE_MASSE_POSITION, 0)->setText(element->exakte_masse());
    else werte_tabelle->item(EXAKTE_MASSE_POSITION, 0)->setText(tr("Unknown"));

    if (element->ionisation() != "-1") werte_tabelle->item(IONISATION_POSITION, 0)->setText(element->ionisation());
    else  werte_tabelle->item(IONISATION_POSITION, 0)->setText(tr("Unknown"));

    if (element->elektronenaffinitaet() != "-1") werte_tabelle->item(ELEKTRONEN_AFFINITAET_POSITION, 0)->setText(element->elektronenaffinitaet());
    else werte_tabelle->item(ELEKTRONEN_AFFINITAET_POSITION, 0)->setText(tr("Unknown"));

    if (element->elektronen_negativitaet() != "-1") werte_tabelle->item(ELEKTRONEN_NEGATIVITAET_POSITION, 0)->setText(element->elektronen_negativitaet());
    else werte_tabelle->item(ELEKTRONEN_NEGATIVITAET_POSITION, 0)->setText(tr("Unknown"));

    if (element->kovalenter() != "-1") werte_tabelle->item(KOVALENTER_POSITION, 0)->setText(element->kovalenter());
    else werte_tabelle->item(KOVALENTER_POSITION, 0)->setText(tr("Unknown"));

    if (element->van_der_waals_radius() != "-1") werte_tabelle->item(VAN_DER_WAALS_POSITION, 0)->setText(element->van_der_waals_radius());
    else werte_tabelle->item(VAN_DER_WAALS_POSITION, 0)->setText(tr("Unknown"));

    if (element->schmelzpunkt().toInt() != INT_MAX) werte_tabelle->item(SCHMELZPUNKT_POSITION, 0)->setText(element->schmelzpunkt() + tr(" Kelvin"));
    else werte_tabelle->item(SCHMELZPUNKT_POSITION, 0)->setText(tr("Unknown"));

    if (element->siedepunkt().toInt() != INT_MAX) werte_tabelle->item(SIEDEPUNKT_POSITION, 0)->setText(element->siedepunkt() + tr(" Kelvin"));
    else werte_tabelle->item(SIEDEPUNKT_POSITION, 0)->setText(tr("Unknown"));

    werte_tabelle->item(FAMILIE_POSITION, 0)->setText(element->familie());
    werte_tabelle->item(ENTDECKUNGSJAHR_POSITION, 0)->setText(QString::number(element->entdeckungsjahr()));
}


void Detail_dialog::setze_index(int wert)
{
    if (wert >= 0 && wert < auswahl_tab->count()) auswahl_tab->setCurrentIndex(wert);
    else qDebug() << tr("Invalid tab index in \"void Detail_dialog::setze_index(int wert)\".");
}


int Detail_dialog::index() const
{
    return auswahl_tab->currentIndex();
}

