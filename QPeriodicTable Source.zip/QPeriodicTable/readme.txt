Readme File for QPeriodicTable

Autor:		Andreas Konarski
Contact:	andreaskw@gmx.de
		programmieren@konarski-wuppertal.de
Licence:	GPL V3

Windows XP, Windows 7 and Windows 8:
Just extract the zip file and launch QPeriodicTable.exe. Place the QPeriodicTable folder where you want, but don’t change the internal structure of the folder, or the application will stop working.

MacOSX 10.10:
Just place the bundle where you want. It should solve all dependencies.
The binaries are now 64 bit only, because 32 bit build failed with QT 5.

Linux:
You have to build the application from scratch. First install the latest version of qt4, if not already happened. Extract the sources and run qmake and make inside the folder with the sources.

Other operating systems supported by qt4:
You have to build the application from scratch. Install the latest version of qt4 if not already happened and build the application the way, it should be done on your platform.