/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef SCENE_H
#define SCENE_H

#include <QGraphicsScene>
#include <QMap>
#include <QList>
#include <QColor>

class QGraphicsView;
class Element;
class Gruppennummer;
class Periodennummer;
class Legende;

class Scene : public QGraphicsScene
{
    Q_OBJECT

public:
    Scene(QGraphicsView* parent);
    virtual ~Scene();

    void zeige_gruppenfarbe();
    void zeige_agregatzustandfarbe(double);
    Element* get_element(int) const;
    int elementzahl() const;
    const QMap<int, Element*>& get_elementliste() const;
    bool sichtbarkeit_legende() const;

public slots:
    void zeige_temperatur(double);
    void legende_setze_seite(int);
    void fuege_element_hinzu(Element*);
    void entferne_element(Element*);
    void setze_sichtbarkeit_legende(bool);

signals:
    void gruppenfarbe_geordert();
    void agregatzustandfarbe_gefordert(double);
    void temperatur_geordert(double);
    void aktiviert(Element*);
    void doppelgeklickt(Element*);
    void jahr(int);
    void suche(const QString&);
    void vorhandene_elemente_geaendert(const QList<Element*>&);
    void vorhandene_elemente_geaendert(int);

private:
    QGraphicsView *meinviewer;
    QMap<int, Element*> elementliste;
    QMap<int, Gruppennummer*> gruppennummerliste;
    QMap<int, Periodennummer*> periodennummerliste;
    QList<QColor> gruppenfarben, agregatzustandsfarben;
    Legende *legende;
    QList<Element*> elemente_in_scene;
};

#endif

