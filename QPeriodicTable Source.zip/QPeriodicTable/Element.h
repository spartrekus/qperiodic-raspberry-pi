/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef ELEMENT_H
#define ELEMENT_H

#include <QObject>
#include <QGraphicsItem>
#include <QColor>
#include <QList>
#include <QMap>

class Scene;

class Element : public QObject, public QGraphicsItem
{
    Q_OBJECT

public:
    Element(Scene *parent);
    virtual ~Element();

    QRectF boundingRect() const;
    void setze_element_namen(const QString&);
    const QString& element_name() const;
    void setze_atomzahl(int);
    int atomzahl() const;
    void setze_symbol(const QString&);
    const QString& symbol() const;
    void setze_masse(const QString&);
    const QString& masse() const;
    void setze_exakte_masse(const QString&);
    const QString& exakte_masse() const;
    void setze_ionisation(const QString&);
    const QString& ionisation() const;
    void setze_elektronenaffinitaet(const QString&);
    const QString& elektronenaffinitaet() const;
    void setze_elektronen_negativitaet(const QString&);
    const QString& elektronen_negativitaet() const;
    void setze_kovalenter(const QString&);
    const QString& kovalenter() const;
    void setze_van_der_waals_radius(const QString&);
    const QString& van_der_waals_radius() const;
    void setze_schmelzpunkt(const QString&);
    const QString& schmelzpunkt() const;
    void setze_siedepunkt(const QString&);
    const QString& siedepunkt() const;
    void setze_familie(const QString&);
    const QString& familie() const;
    void setze_gruppenfarbe(const QColor&);
    const QColor& gruppenfarbe() const;
    void setze_position(int, int);
    int xposition() const;
    int yposition() const;
    void setze_entdeckungsjahr(int);
    int entdeckungsjahr() const;
    void registriere_agrgatzustandsfarben(const QList<QColor>&);
    void fuege_elektronen_hinzu(int ring, int menge);
    int elektronen_an_ring(int) const;
    int elektronen() const;

public slots:
    void zeige_gruppenfarbe();
    void zeige_agregatzustandfarbe(double);
    void setze_jahr(int);
    void suche(const QString&);

signals:
    void aktiviert(Element*);
    void doppelgeklickt(Element*);

private:
    Scene *meinescene;
    QString Element_name, Symbol, Familie, Masse, Exakte_masse, Ionisation, Elektronenafinitaet, Elektronen_negativitaet, Kovalenter, Van_der_waals_radius, Schmelzpunkt, Siedepunkt, Suchvorgang;
    int Atomzahl, Xposition, Yposition, Entdeckungsjahr;
    ;
    QColor aktive_farbe, Gruppenfarbe;
    QList<QColor> agregatzustandsfarben;
    QMap<int, int> Elektronenkonfiguration;

    void paint(QPainter*, const QStyleOptionGraphicsItem*, QWidget*);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent*);
    virtual void mouseDoubleClickEvent(QGraphicsSceneMouseEvent*);
};

#endif

