#include "Gruppennummer.h"
#include "Scene.h"
#include "Proportionen.h"
#include <QPainter>
#include <QFont>
#include <QGraphicsSceneMouseEvent>

using namespace std;

Gruppennummer::Gruppennummer(Scene *parent) : QObject(parent), QGraphicsItem(0), meinescene(parent), Nummer(0)
{
}


Gruppennummer::~Gruppennummer()
{
}


QRectF Gruppennummer::boundingRect() const
{
    QRectF erg(0, 0, ELEMENT_GROESSE, ELEMENT_GROESSE);

    return erg;
}


void Gruppennummer::paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    // den font setzen
    QFont font(painter->font());

    font.setPointSizeF((double) ELEMENT_GROESSE * 0.30);

    painter->setFont(font);

    // das zeichen malen
    painter->drawText(boundingRect(), Qt::AlignCenter, QString::number(Nummer));
}


void Gruppennummer::setze_nummer(int wert)
{
    Nummer = wert;
}


int Gruppennummer::nummer() const
{
    return Nummer;
}


void Gruppennummer::setze_sichtbarkeit(bool zustand)
{
    // wenn das element sichtbar sein soll
    if (zustand == true)
    {
        // nur, wenn scene 0 ist und dieses element sich nich nicht in der scene befindet.
        if (scene() == 0) meinescene->addItem(this);
    }

    // ansonsten
    else meinescene->removeItem(this);
}


bool Gruppennummer::ist_sichtbar() const
{
    return (scene() != 0);
}

