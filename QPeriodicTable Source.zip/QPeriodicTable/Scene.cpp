#include "Scene.h"
#include "Element.h"
#include "Gruppennummer.h"
#include "Periodennummer.h"
#include "Legende.h"
#include "Proportionen.h"
#include <QGraphicsView>
#include <climits>
#include <QUrl>
#include <QDebug>

#define GRUPPEN 18
#define PERIODEN 7

using namespace std;

Scene::Scene(QGraphicsView* parent) : QGraphicsScene(parent), meinviewer(parent)
{
    // im viewer registrieren
    meinviewer->setScene(this);

    // die gruppennummern aufbauen
    for (int idx = 1; idx <= GRUPPEN; idx++)
    {
        Gruppennummer *tmp_nummer = new Gruppennummer(this);

        tmp_nummer->setObjectName("gruppennummer_" + QString::number(idx));

        tmp_nummer->setze_nummer(idx);

        gruppennummerliste.insert(idx, tmp_nummer);
    }

    // die periodennummern aufbauen
    for (int idx = 1; idx <= PERIODEN; idx++)
    {
        Periodennummer *tmp_nummer = new Periodennummer(this);

        tmp_nummer->setObjectName("periodennummer_" + QString::number(idx));

        tmp_nummer->setze_nummer(idx);

        periodennummerliste.insert(idx, tmp_nummer);
    }

    // die gruppenfarben aufbauen
    gruppenfarben.append(QColor(0, 0, 0));
    gruppenfarben.append(QColor(221, 0, 238));
    gruppenfarben.append(QColor(34, 132, 238));
    gruppenfarben.append(QColor(145, 238, 127));
    gruppenfarben.append(QColor(200, 0, 0));
    gruppenfarben.append(QColor(238, 200, 9));
    gruppenfarben.append(QColor(72, 111, 139));
    gruppenfarben.append(QColor(238, 8, 66));
    gruppenfarben.append(QColor(180, 173, 255));
    gruppenfarben.append(QColor(180, 173, 255));
    gruppenfarben.append(QColor(180, 173, 255));
    gruppenfarben.append(QColor(221, 0, 238));
    gruppenfarben.append(QColor(34, 132, 238));
    gruppenfarben.append(QColor(145, 238, 127));
    gruppenfarben.append(QColor(200, 0, 0));
    gruppenfarben.append(QColor(238, 200, 9));
    gruppenfarben.append(QColor(72, 111, 139));
    gruppenfarben.append(QColor(238, 8, 66));
    gruppenfarben.append(QColor(180, 173, 255));
    gruppenfarben.append(QColor(145, 238, 238)); //lanthanides
    gruppenfarben.append(QColor(238, 238, 145)); //actinides

    // ueberpruefen, ob die gruppenfarben die korrekte elementzahl hat
    if (gruppenfarben.size() != 21)
    {
        qDebug() << tr("Gruppenfarben is not equal to 21 !!!");
    }

    // die agregatzustandsfarben aufbauen
    agregatzustandsfarben.append(Qt::darkGray);
    agregatzustandsfarben.append(QColor(255, 82 ,85));
    agregatzustandsfarben.append(QColor(180, 173, 255));
    agregatzustandsfarben.append(QColor(92, 255, 70));

    // die agregatzustandsfarben kontrollieren
    if (agregatzustandsfarben.size() != 4)
    {
        qDebug() << tr("Agregatzustandsfarben is not equal to 4 !!!");
    }

    // die legende erstellen
    legende = new Legende(this);
    legende->registriere_gruppenfarben(gruppenfarben);
    legende->registriere_agrgatzustandsfarben(agregatzustandsfarben);

    //the field exakte_masse will refer to the exact atomic mass of the
    //isotope of the element that has the highest natural abudance, for
    //naturally occuring elements, or has the longest half-life, for
    //synthesized ones

    //data from <de> and <en> wikipedia
    //exact atomic masses from
    //amdc.in2p3.fr/masstables/Ame2011int/mass.mas114
    //general cross-reference from
    //periodictable.com
    //electron affinities from
    //www.webelements.com/periodicity/electron_affinity/
    //some info from
    //www.knowledgedoor.com
    //ionization adjustments from
    //www.nist.gov/data/PDFfiles/jpcrd690.pdf
    //van der waals radii adjustments from
    //periodic.lanl.gov
    //atomic masses & isotope stability for elements Z>100 from
    //www.periodensystem-online.de/index.php?id=isotope and from
    //www.mrteverett.com/Chemistry/pdictable/pdictable.asp


    // die elemente aufbauen
    // wasserstoff (gruppe 1, Nichtmetalle)
    Element* wasserstoff = new Element(this);
    wasserstoff->setObjectName("wasserstoff");
    wasserstoff->setze_element_namen(tr("Hydrogen"));
    wasserstoff->setze_atomzahl(1);
    wasserstoff->setze_symbol("H");
    wasserstoff->setze_masse("1.00794 u");
    wasserstoff->setze_exakte_masse("1.007825");
    wasserstoff->setze_ionisation("1312 kJ/mol");
    wasserstoff->setze_elektronenaffinitaet("72.8 kJ/mol");
    wasserstoff->setze_elektronen_negativitaet("2.2");
    wasserstoff->setze_kovalenter("31 pm");
    wasserstoff->setze_van_der_waals_radius("110 pm");
    wasserstoff->setze_schmelzpunkt("14.01");
    wasserstoff->setze_siedepunkt("20.28");
    wasserstoff->setze_familie(tr("nonmetals"));
    wasserstoff->setze_gruppenfarbe(gruppenfarben.at(1));
    wasserstoff->setze_entdeckungsjahr(1766);
    wasserstoff->setze_position(0, 1);
    elementliste.insert(wasserstoff->atomzahl(), wasserstoff);
    wasserstoff->registriere_agrgatzustandsfarben(agregatzustandsfarben);
    wasserstoff->fuege_elektronen_hinzu(1, 1);

    // helium (gruppe 18, Edelgase)
    Element* helium = new Element(this);
    helium->setObjectName("helium");
    helium->setze_element_namen(tr("Helium"));
    helium->setze_atomzahl(2);
    helium->setze_symbol("He");
    helium->setze_masse("4.0026 u");
    helium->setze_exakte_masse("4.002603");
    helium->setze_ionisation("2372.3 kJ/mol");
    helium->setze_elektronenaffinitaet("0 kJ/mol");
    helium->setze_elektronen_negativitaet("-1");
    helium->setze_kovalenter("28 pm");
    helium->setze_van_der_waals_radius("140 pm");
    helium->setze_schmelzpunkt("0.95");
    helium->setze_siedepunkt("4.216");
    helium->setze_familie(tr("noble gases"));
    helium->setze_gruppenfarbe(gruppenfarben.at(18));
    helium->setze_entdeckungsjahr(1895);
    helium->setze_position(17, 1);
    elementliste.insert(helium->atomzahl(), helium);
    helium->fuege_elektronen_hinzu(1, 2);

    // lithium (gruppe 1, Alkalimetalle)
    Element* lithium = new Element(this);
    lithium->setObjectName("lithium");
    lithium->setze_element_namen(tr("Lithium"));
    lithium->setze_atomzahl(3);
    lithium->setze_symbol("Li");
    lithium->setze_masse("6.941 u");
    lithium->setze_exakte_masse("7.016003");
    lithium->setze_ionisation("520.2 kJ/mol");
    lithium->setze_elektronenaffinitaet("59.6 kJ/mol");
    lithium->setze_elektronen_negativitaet("0.98");
    lithium->setze_kovalenter("128 pm");
    lithium->setze_van_der_waals_radius("181 pm");
    lithium->setze_schmelzpunkt("453.69");
    lithium->setze_siedepunkt("1615");
    lithium->setze_familie(tr("alkali metals"));
    lithium->setze_gruppenfarbe(gruppenfarben.at(1));
    lithium->setze_entdeckungsjahr(1817);
    lithium->setze_position(0, 2);
    elementliste.insert(lithium->atomzahl(), lithium);
    lithium->fuege_elektronen_hinzu(1, 2);
    lithium->fuege_elektronen_hinzu(2, 1);

    // Beryllium (gruppe 2, Erdalkalimetalle)
    Element* beryllium = new Element(this);
    beryllium->setObjectName("beryllium");
    beryllium->setze_element_namen(tr("Beryllium"));
    beryllium->setze_atomzahl(4);
    beryllium->setze_symbol("Be");
    beryllium->setze_masse("9.01218 u");
    beryllium->setze_exakte_masse("9.012183");
    beryllium->setze_ionisation("899.5 kJ/mol");
    beryllium->setze_elektronenaffinitaet("0 kJ/mol");
    beryllium->setze_elektronen_negativitaet("1.57");
    beryllium->setze_kovalenter("96 pm");
    beryllium->setze_van_der_waals_radius("153 pm");
    beryllium->setze_schmelzpunkt("1560");
    beryllium->setze_siedepunkt("2742");
    beryllium->setze_familie(tr("alkaline earth metals"));
    beryllium->setze_gruppenfarbe(gruppenfarben.at(2));
    beryllium->setze_entdeckungsjahr(1798);
    beryllium->setze_position(1, 2);
    elementliste.insert(beryllium->atomzahl(), beryllium);
    beryllium->fuege_elektronen_hinzu(1, 2);
    beryllium->fuege_elektronen_hinzu(2, 2);

    // bor (gruppe 13, Halbmetalle)
    Element* bor = new Element(this);
    bor->setObjectName("bor");
    bor->setze_element_namen(tr("Boron"));
    bor->setze_atomzahl(5);
    bor->setze_symbol("B");
    bor->setze_masse("10.811 u");
    bor->setze_exakte_masse("11.009305");
    bor->setze_ionisation("800.6 kJ/mol");
    bor->setze_elektronenaffinitaet("26.7 kJ/mol");
    bor->setze_elektronen_negativitaet("2.04");
    bor->setze_kovalenter("84 pm");
    bor->setze_van_der_waals_radius("192 pm");
    bor->setze_schmelzpunkt("2349");
    bor->setze_siedepunkt("4200");
    bor->setze_familie(tr("metalloids"));
    bor->setze_gruppenfarbe(gruppenfarben.at(13));
    bor->setze_entdeckungsjahr(1808);
    bor->setze_position(12, 2);
    elementliste.insert(bor->atomzahl(), bor);
    bor->fuege_elektronen_hinzu(1, 2);
    bor->fuege_elektronen_hinzu(2, 3);

    // kohlenstoff (gruppe 14, Nichtmetalle)
    Element* kohlenstoff = new Element(this);
    kohlenstoff->setObjectName("kohlenstoff");
    kohlenstoff->setze_element_namen(tr("Carbon"));
    kohlenstoff->setze_atomzahl(6);
    kohlenstoff->setze_symbol("C");
    kohlenstoff->setze_masse("12.0107 u");
    kohlenstoff->setze_exakte_masse("12");
    kohlenstoff->setze_ionisation("1086.5 kJ/mol");
    kohlenstoff->setze_elektronenaffinitaet("153.9 kJ/mol");
    kohlenstoff->setze_elektronen_negativitaet("2.55");
    kohlenstoff->setze_kovalenter("77 pm");
    kohlenstoff->setze_van_der_waals_radius("170 pm");
    kohlenstoff->setze_schmelzpunkt("-1"); //sublimation
    kohlenstoff->setze_siedepunkt("3915");
    kohlenstoff->setze_familie(tr("nonmetals"));
    kohlenstoff->setze_gruppenfarbe(gruppenfarben.at(14));
    kohlenstoff->setze_entdeckungsjahr(-4000);
    kohlenstoff->setze_position(13, 2);
    elementliste.insert(kohlenstoff->atomzahl(), kohlenstoff);
    kohlenstoff->fuege_elektronen_hinzu(1, 2);
    kohlenstoff->fuege_elektronen_hinzu(2, 4);

    // Stickstoff (gruppe 15, Nichtmetalle)
    Element* stickstoff = new Element(this);
    stickstoff->setObjectName("stickstoff");
    stickstoff->setze_element_namen(tr("Nitrogen"));
    stickstoff->setze_atomzahl(7);
    stickstoff->setze_symbol("N");
    stickstoff->setze_masse("14.0067 u");
    stickstoff->setze_exakte_masse("14.003074");
    stickstoff->setze_ionisation("1402.3 kJ/mol");
    stickstoff->setze_elektronenaffinitaet("7 kJ/mol");
    stickstoff->setze_elektronen_negativitaet("3.04");
    stickstoff->setze_kovalenter("71 pm");
    stickstoff->setze_van_der_waals_radius("155 pm");
    stickstoff->setze_schmelzpunkt("63.15");
    stickstoff->setze_siedepunkt("77.36");
    stickstoff->setze_familie(tr("nonmetals"));
    stickstoff->setze_gruppenfarbe(gruppenfarben.at(15));
    stickstoff->setze_entdeckungsjahr(1772);
    stickstoff->setze_position(14, 2);
    elementliste.insert(stickstoff->atomzahl(), stickstoff);
    stickstoff->fuege_elektronen_hinzu(1, 2);
    stickstoff->fuege_elektronen_hinzu(2, 5);

    // sauerstoff (gruppe 16, Nichtmetalle)
    Element* sauerstoff = new Element(this);
    sauerstoff->setObjectName("sauerstoff");
    sauerstoff->setze_element_namen(tr("Oxygen"));
    sauerstoff->setze_atomzahl(8);
    sauerstoff->setze_symbol("O");
    sauerstoff->setze_masse("15.9994 u");
    sauerstoff->setze_exakte_masse("15.994915");
    sauerstoff->setze_ionisation("1313.9 kJ/mol");
    sauerstoff->setze_elektronenaffinitaet("141 kJ/mol");
    sauerstoff->setze_elektronen_negativitaet("3.44");
    sauerstoff->setze_kovalenter("66 pm");
    sauerstoff->setze_van_der_waals_radius("152 pm");
    sauerstoff->setze_schmelzpunkt("54.36");
    sauerstoff->setze_siedepunkt("90.2");
    sauerstoff->setze_familie(tr("nonmetals"));
    sauerstoff->setze_gruppenfarbe(gruppenfarben.at(16));
    sauerstoff->setze_entdeckungsjahr(1771);
    sauerstoff->setze_position(15, 2);
    elementliste.insert(sauerstoff->atomzahl(), sauerstoff);
    sauerstoff->fuege_elektronen_hinzu(1, 2);
    sauerstoff->fuege_elektronen_hinzu(2, 6);

    // fluor (gruppe 17, Halogene)
    Element* fluor = new Element(this);
    fluor->setObjectName("fluor");
    fluor->setze_element_namen(tr("Fluorine"));
    fluor->setze_atomzahl(9);
    fluor->setze_symbol("F");
    fluor->setze_masse("18.9984 u");
    fluor->setze_exakte_masse("18.998403");
    fluor->setze_ionisation("1681 kJ/mol");
    fluor->setze_elektronenaffinitaet("328 kJ/mol");
    fluor->setze_elektronen_negativitaet("3.98");
    fluor->setze_kovalenter("60 pm");
    fluor->setze_van_der_waals_radius("147 pm");
    fluor->setze_schmelzpunkt("53.55");
    fluor->setze_siedepunkt("85.03");
    fluor->setze_familie(tr("halogens"));
    fluor->setze_gruppenfarbe(gruppenfarben.at(17));
    fluor->setze_entdeckungsjahr(1886);
    fluor->setze_position(16, 2);
    elementliste.insert(fluor->atomzahl(), fluor);
    fluor->fuege_elektronen_hinzu(1, 2);
    fluor->fuege_elektronen_hinzu(2, 7);

    // neon (gruppe 18, Edelgase)
    Element* neon = new Element(this);
    neon->setObjectName("neon");
    neon->setze_element_namen(tr("Neon"));
    neon->setze_atomzahl(10);
    neon->setze_symbol("Ne");
    neon->setze_masse("20.1797 u");
    neon->setze_exakte_masse("19.992440");
    neon->setze_ionisation("2080.7 kJ/mol");
    neon->setze_elektronenaffinitaet("0 kJ/mol");
    neon->setze_elektronen_negativitaet("-1");
    neon->setze_kovalenter("58 pm");
    neon->setze_van_der_waals_radius("154 pm");
    neon->setze_schmelzpunkt("24.56");
    neon->setze_siedepunkt("27.07");
    neon->setze_familie(tr("noble gases"));
    neon->setze_gruppenfarbe(gruppenfarben.at(18));
    neon->setze_entdeckungsjahr(1898);
    neon->setze_position(17, 2);
    elementliste.insert(neon->atomzahl(), neon);
    neon->fuege_elektronen_hinzu(1, 2);
    neon->fuege_elektronen_hinzu(2, 8);

    // natrium (gruppe 1, Alkalimetalle)
    Element* natrium = new Element(this);
    natrium->setObjectName("natrium");
    natrium->setze_element_namen(tr("Sodium"));
    natrium->setze_atomzahl(11);
    natrium->setze_symbol("Na");
    natrium->setze_masse("22.98977 u");
    natrium->setze_exakte_masse("22.989769");
    natrium->setze_ionisation("495.8 kJ/mol");
    natrium->setze_elektronenaffinitaet("52.8 kJ/mol");
    natrium->setze_elektronen_negativitaet("0.93");
    natrium->setze_kovalenter("166 pm");
    natrium->setze_van_der_waals_radius("227 pm");
    natrium->setze_schmelzpunkt("370.8");
    natrium->setze_siedepunkt("1156");
    natrium->setze_familie(tr("alkali metals"));
    natrium->setze_gruppenfarbe(gruppenfarben.at(11));
    natrium->setze_entdeckungsjahr(1807);
    natrium->setze_position(0, 3);
    elementliste.insert(natrium->atomzahl(), natrium);
    natrium->fuege_elektronen_hinzu(1, 2);
    natrium->fuege_elektronen_hinzu(2, 8);
    natrium->fuege_elektronen_hinzu(3, 1);

    // magnesium (gruppe 2, Erdalkalimetalle)
    Element* magnesium = new Element(this);
    magnesium->setObjectName("magnesium");
    magnesium->setze_element_namen(tr("Magnesium"));
    magnesium->setze_atomzahl(12);
    magnesium->setze_symbol("Mg");
    magnesium->setze_masse("24.305 u");
    magnesium->setze_exakte_masse("23.985042");
    magnesium->setze_ionisation("737.7 kJ/mol");
    magnesium->setze_elektronenaffinitaet("0 kJ/mol");
    magnesium->setze_elektronen_negativitaet("1.31");
    magnesium->setze_kovalenter("141 pm");
    magnesium->setze_van_der_waals_radius("173 pm");
    magnesium->setze_schmelzpunkt("923");
    magnesium->setze_siedepunkt("1363");
    magnesium->setze_familie(tr("alkaline earth metals"));
    magnesium->setze_gruppenfarbe(gruppenfarben.at(2));
    magnesium->setze_entdeckungsjahr(1808);
    magnesium->setze_position(1, 3);
    elementliste.insert(magnesium->atomzahl(), magnesium);
    magnesium->fuege_elektronen_hinzu(1, 2);
    magnesium->fuege_elektronen_hinzu(2, 8);
    magnesium->fuege_elektronen_hinzu(3, 2);

    // aluminium (gruppe 13, Metalle)
    Element* aluminium = new Element(this);
    aluminium->setObjectName("aluminium");
    aluminium->setze_element_namen(tr("Aluminium"));
    aluminium->setze_atomzahl(13);
    aluminium->setze_symbol("Al");
    aluminium->setze_masse("26.9815 u");
    aluminium->setze_exakte_masse("26.981539");
    aluminium->setze_ionisation("577.5 kJ/mol");
    aluminium->setze_elektronenaffinitaet("42.5 kJ/mol");
    aluminium->setze_elektronen_negativitaet("1.61");
    aluminium->setze_kovalenter("121 pm");
    aluminium->setze_van_der_waals_radius("184 pm");
    aluminium->setze_schmelzpunkt("933.5");
    aluminium->setze_siedepunkt("2792");
    aluminium->setze_familie(tr("metals"));
    aluminium->setze_gruppenfarbe(gruppenfarben.at(13));
    aluminium->setze_entdeckungsjahr(1825);
    aluminium->setze_position(12, 3);
    elementliste.insert(aluminium->atomzahl(), aluminium);
    aluminium->fuege_elektronen_hinzu(1, 2);
    aluminium->fuege_elektronen_hinzu(2, 8);
    aluminium->fuege_elektronen_hinzu(3, 3);

    // silizium (gruppe 14, Halbmetalle)
    Element* silizium = new Element(this);
    silizium->setObjectName("silizium");
    silizium->setze_element_namen(tr("Silicon"));
    silizium->setze_atomzahl(14);
    silizium->setze_symbol("Si");
    silizium->setze_masse("28.0855 u");
    silizium->setze_exakte_masse("27.976927");
    silizium->setze_ionisation("786.5 kJ/mol");
    silizium->setze_elektronenaffinitaet("133.6 kJ/mol");
    silizium->setze_elektronen_negativitaet("1.9");
    silizium->setze_kovalenter("111 pm");
    silizium->setze_van_der_waals_radius("210 pm");
    silizium->setze_schmelzpunkt("1687");
    silizium->setze_siedepunkt("3538");
    silizium->setze_familie(tr("metalloids"));
    silizium->setze_gruppenfarbe(gruppenfarben.at(14));
    silizium->setze_entdeckungsjahr(1824);
    silizium->setze_position(13, 3);
    elementliste.insert(silizium->atomzahl(), silizium);
    silizium->fuege_elektronen_hinzu(1, 2);
    silizium->fuege_elektronen_hinzu(2, 8);
    silizium->fuege_elektronen_hinzu(3, 4);

    // phosphor (gruppe 15, Nichtmetalle)
    Element* phosphor = new Element(this);
    phosphor->setObjectName("phosphor");
    phosphor->setze_element_namen(tr("Phosphorus"));
    phosphor->setze_atomzahl(15);
    phosphor->setze_symbol("P");
    phosphor->setze_masse("30.9738 u");
    phosphor->setze_exakte_masse("30.973762");
    phosphor->setze_ionisation("1011.8 kJ/mol");
    phosphor->setze_elektronenaffinitaet("72 kJ/mol");
    phosphor->setze_elektronen_negativitaet("2.19");
    phosphor->setze_kovalenter("107 pm");
    phosphor->setze_van_der_waals_radius("180 pm");
    phosphor->setze_schmelzpunkt("317.3");
    phosphor->setze_siedepunkt("553.6");
    phosphor->setze_familie(tr("nonmetals"));
    phosphor->setze_gruppenfarbe(gruppenfarben.at(15));
    phosphor->setze_entdeckungsjahr(1669);
    phosphor->setze_position(14, 3);
    elementliste.insert(phosphor->atomzahl(), phosphor);
    phosphor->fuege_elektronen_hinzu(1, 2);
    phosphor->fuege_elektronen_hinzu(2, 8);
    phosphor->fuege_elektronen_hinzu(3, 5);

    // schwefel (gruppe 16, Nichtmetalle)
    Element* schwefel = new Element(this);
    schwefel->setObjectName("schwefel");
    schwefel->setze_element_namen(tr("Sulfur"));
    schwefel->setze_atomzahl(16);
    schwefel->setze_symbol("S");
    schwefel->setze_masse("32.065 u");
    schwefel->setze_exakte_masse("31.972071");
    schwefel->setze_ionisation("999.6 kJ/mol");
    schwefel->setze_elektronenaffinitaet("200 kJ/mol");
    schwefel->setze_elektronen_negativitaet("2.58");
    schwefel->setze_kovalenter("105 pm");
    schwefel->setze_van_der_waals_radius("180 pm");
    schwefel->setze_schmelzpunkt("388.4");
    schwefel->setze_siedepunkt("717.8");
    schwefel->setze_familie(tr("nonmetals"));
    schwefel->setze_gruppenfarbe(gruppenfarben.at(16));
    schwefel->setze_entdeckungsjahr(-2000);
    schwefel->setze_position(15, 3);
    elementliste.insert(schwefel->atomzahl(), schwefel);
    schwefel->fuege_elektronen_hinzu(1, 2);
    schwefel->fuege_elektronen_hinzu(2, 8);
    schwefel->fuege_elektronen_hinzu(3, 6);

    // chlor (gruppe 17, Halogene)
    Element* chlor = new Element(this);
    chlor->setObjectName("chlor");
    chlor->setze_element_namen(tr("Chlorine"));
    chlor->setze_atomzahl(17);
    chlor->setze_symbol("Cl");
    chlor->setze_masse("35.453 u");
    chlor->setze_exakte_masse("34.968853");
    chlor->setze_ionisation("1251.2 kJ/mol");
    chlor->setze_elektronenaffinitaet("349 kJ/mol");
    chlor->setze_elektronen_negativitaet("3.16");
    chlor->setze_kovalenter("102 pm");
    chlor->setze_van_der_waals_radius("175 pm");
    chlor->setze_schmelzpunkt("171.6");
    chlor->setze_siedepunkt("239.1");
    chlor->setze_familie(tr("halogens"));
    chlor->setze_gruppenfarbe(gruppenfarben.at(17));
    chlor->setze_entdeckungsjahr(1774);
    chlor->setze_position(16, 3);
    elementliste.insert(chlor->atomzahl(), chlor);
    chlor->fuege_elektronen_hinzu(1, 2);
    chlor->fuege_elektronen_hinzu(2, 8);
    chlor->fuege_elektronen_hinzu(3, 7);

    // argon (gruppe 18, Edelgase)
    Element* argon = new Element(this);
    argon->setObjectName("argon");
    argon->setze_element_namen(tr("Argon"));
    argon->setze_atomzahl(18);
    argon->setze_symbol("Ar");
    argon->setze_masse("39.948 u");
    argon->setze_exakte_masse("39.962383");
    argon->setze_ionisation("1520.6 kJ/mol");
    argon->setze_elektronenaffinitaet("0 kJ/mol");
    argon->setze_elektronen_negativitaet("-1");
    argon->setze_kovalenter("106 pm");
    argon->setze_van_der_waals_radius("188 pm");
    argon->setze_schmelzpunkt("83.8");
    argon->setze_siedepunkt("87.3");
    argon->setze_familie(tr("noble gases"));
    argon->setze_gruppenfarbe(gruppenfarben.at(18));
    argon->setze_entdeckungsjahr(1894);
    argon->setze_position(17, 3);
    elementliste.insert(argon->atomzahl(), argon);
    argon->fuege_elektronen_hinzu(1, 2);
    argon->fuege_elektronen_hinzu(2, 8);
    argon->fuege_elektronen_hinzu(3, 8);

    // kalium (gruppe 1, Alkalimetalle)
    Element* kalium = new Element(this);
    kalium->setObjectName("kalium");
    kalium->setze_element_namen(tr("Potassium"));
    kalium->setze_atomzahl(19);
    kalium->setze_symbol("K");
    kalium->setze_masse("39.0983 u");
    kalium->setze_exakte_masse("38.963706");
    kalium->setze_ionisation("418.8 kJ/mol");
    kalium->setze_elektronenaffinitaet("48.4 kJ/mol");
    kalium->setze_elektronen_negativitaet("0.82");
    kalium->setze_kovalenter("203 pm");
    kalium->setze_van_der_waals_radius("275 pm");
    kalium->setze_schmelzpunkt("336.5");
    kalium->setze_siedepunkt("1032");
    kalium->setze_familie(tr("alkali metals"));
    kalium->setze_gruppenfarbe(gruppenfarben.at(1));
    kalium->setze_entdeckungsjahr(1807);
    kalium->setze_position(0, 4);
    elementliste.insert(kalium->atomzahl(), kalium);
    kalium->fuege_elektronen_hinzu(1, 2);
    kalium->fuege_elektronen_hinzu(2, 8);
    kalium->fuege_elektronen_hinzu(3, 8);
    kalium->fuege_elektronen_hinzu(4, 1);

    // kalzium (gruppe 2, Erdalkalimetalle)
    Element* kalzium = new Element(this);
    kalzium->setObjectName("kalzium");
    kalzium->setze_element_namen(tr("Calcium"));
    kalzium->setze_atomzahl(20);
    kalzium->setze_symbol("Ca");
    kalzium->setze_masse("40.078 u");
    kalzium->setze_exakte_masse("39.962591");
    kalzium->setze_ionisation("589.8 kJ/mol");
    kalzium->setze_elektronenaffinitaet("2.37 kJ/mol");
    kalzium->setze_elektronen_negativitaet("1");
    kalzium->setze_kovalenter("176 pm");
    kalzium->setze_van_der_waals_radius("231 pm");
    kalzium->setze_schmelzpunkt("1115");
    kalzium->setze_siedepunkt("1757");
    kalzium->setze_familie(tr("alkaline earth metals"));
    kalzium->setze_gruppenfarbe(gruppenfarben.at(2));
    kalzium->setze_entdeckungsjahr(1808);
    kalzium->setze_position(1, 4);
    elementliste.insert(kalzium->atomzahl(), kalzium);
    kalzium->fuege_elektronen_hinzu(1, 2);
    kalzium->fuege_elektronen_hinzu(2, 8);
    kalzium->fuege_elektronen_hinzu(3, 8);
    kalzium->fuege_elektronen_hinzu(4, 2);

    // scandium (gruppe 3, Übergangsmetalle)
    Element* scandium = new Element(this);
    scandium->setObjectName("scandium");
    scandium->setze_element_namen(tr("Scandium"));
    scandium->setze_atomzahl(21);
    scandium->setze_symbol("Sc");
    scandium->setze_masse("44.9559 u");
    scandium->setze_exakte_masse("44.955909");
    scandium->setze_ionisation("633.1 kJ/mol");
    scandium->setze_elektronenaffinitaet("18.1 kJ/mol");
    scandium->setze_elektronen_negativitaet("1.36");
    scandium->setze_kovalenter("170 pm");
    scandium->setze_van_der_waals_radius("216 pm");
    scandium->setze_schmelzpunkt("1814");
    scandium->setze_siedepunkt("3109");
    scandium->setze_familie(tr("transition metals"));
    scandium->setze_gruppenfarbe(gruppenfarben.at(3));
    scandium->setze_entdeckungsjahr(1879);
    scandium->setze_position(2, 4);
    elementliste.insert(scandium->atomzahl(), scandium);
    scandium->fuege_elektronen_hinzu(1, 2);
    scandium->fuege_elektronen_hinzu(2, 8);
    scandium->fuege_elektronen_hinzu(3, 9);
    scandium->fuege_elektronen_hinzu(4, 2);

    // titan (gruppe 4, Übergangsmetalle)
    Element* titan = new Element(this);
    titan->setObjectName("titan");
    titan->setze_element_namen(tr("Titanium"));
    titan->setze_atomzahl(22);
    titan->setze_symbol("Ti");
    titan->setze_masse("47.867 u");
    titan->setze_exakte_masse("47.947942");
    titan->setze_ionisation("658.8 kJ/mol");
    titan->setze_elektronenaffinitaet("7.6 kJ/mol");
    titan->setze_elektronen_negativitaet("1.54");
    titan->setze_kovalenter("160 pm");
    titan->setze_van_der_waals_radius("187 pm");
    titan->setze_schmelzpunkt("1941");
    titan->setze_siedepunkt("3560");
    titan->setze_familie(tr("transition metals"));
    titan->setze_gruppenfarbe(gruppenfarben.at(4));
    titan->setze_entdeckungsjahr(1791);
    titan->setze_position(3, 4);
    elementliste.insert(titan->atomzahl(), titan);
    titan->fuege_elektronen_hinzu(1, 2);
    titan->fuege_elektronen_hinzu(2, 8);
    titan->fuege_elektronen_hinzu(3, 10);
    titan->fuege_elektronen_hinzu(4, 2);

    // vanadium (gruppe 5, Übergangsmetalle)
    Element* vanadium = new Element(this);
    vanadium->setObjectName("vanadium");
    vanadium->setze_element_namen(tr("Vanadium"));
    vanadium->setze_atomzahl(23);
    vanadium->setze_symbol("V");
    vanadium->setze_masse("50.9415 u");
    vanadium->setze_exakte_masse("50.943956");
    vanadium->setze_ionisation("650.9 kJ/mol");
    vanadium->setze_elektronenaffinitaet("50.6 kJ/mol");
    vanadium->setze_elektronen_negativitaet("1.63");
    vanadium->setze_kovalenter("153 pm");
    vanadium->setze_van_der_waals_radius("179 pm");
    vanadium->setze_schmelzpunkt("2183");
    vanadium->setze_siedepunkt("3680");
    vanadium->setze_familie(tr("transition metals"));
    vanadium->setze_gruppenfarbe(gruppenfarben.at(5));
    vanadium->setze_entdeckungsjahr(1801);
    vanadium->setze_position(4, 4);
    elementliste.insert(vanadium->atomzahl(), vanadium);
    vanadium->fuege_elektronen_hinzu(1, 2);
    vanadium->fuege_elektronen_hinzu(2, 8);
    vanadium->fuege_elektronen_hinzu(3, 11);
    vanadium->fuege_elektronen_hinzu(4, 2);

    // chrom (gruppe 6, Übergangsmetalle)
    Element* chrom = new Element(this);
    chrom->setObjectName("chrom");
    chrom->setze_element_namen(tr("Chromium"));
    chrom->setze_atomzahl(24);
    chrom->setze_symbol("Cr");
    chrom->setze_masse("51.9961 u");
    chrom->setze_exakte_masse("51.940506");
    chrom->setze_ionisation("652.9 kJ/mol");
    chrom->setze_elektronenaffinitaet("64.3 kJ/mol");
    chrom->setze_elektronen_negativitaet("1.66");
    chrom->setze_kovalenter("128 pm");
    chrom->setze_van_der_waals_radius("189 pm");
    chrom->setze_schmelzpunkt("2180");
    chrom->setze_siedepunkt("2944");
    chrom->setze_familie(tr("transition metals"));
    chrom->setze_gruppenfarbe(gruppenfarben.at(6));
    chrom->setze_entdeckungsjahr(-2000);
    chrom->setze_position(5, 4);
    elementliste.insert(chrom->atomzahl(), chrom);
    chrom->fuege_elektronen_hinzu(1, 2);
    chrom->fuege_elektronen_hinzu(2, 8);
    chrom->fuege_elektronen_hinzu(3, 13);
    chrom->fuege_elektronen_hinzu(4, 1);

    // mangan (gruppe 7, Übergangsmetalle)
    Element* mangan = new Element(this);
    mangan->setObjectName("mangan");
    mangan->setze_element_namen(tr("Manganese"));
    mangan->setze_atomzahl(25);
    mangan->setze_symbol("Mn");
    mangan->setze_masse("54.938 u");
    mangan->setze_exakte_masse("54.938044");
    mangan->setze_ionisation("717.3 kJ/mol");
    mangan->setze_elektronenaffinitaet("0 kJ/mol");
    mangan->setze_elektronen_negativitaet("1.55");
    mangan->setze_kovalenter("139 pm");
    mangan->setze_van_der_waals_radius("197 pm");
    mangan->setze_schmelzpunkt("1519");
    mangan->setze_siedepunkt("2234");
    mangan->setze_familie(tr("transition metals"));
    mangan->setze_gruppenfarbe(gruppenfarben.at(7));
    mangan->setze_entdeckungsjahr(1774);
    mangan->setze_position(6, 4);
    elementliste.insert(mangan->atomzahl(), mangan);
    mangan->fuege_elektronen_hinzu(1, 2);
    mangan->fuege_elektronen_hinzu(2, 8);
    mangan->fuege_elektronen_hinzu(3, 13);
    mangan->fuege_elektronen_hinzu(4, 2);

    // eisen (gruppe 8, Übergangsmetalle)
    Element* eisen = new Element(this);
    eisen->setObjectName("eisen");
    eisen->setze_element_namen(tr("Iron"));
    eisen->setze_atomzahl(26);
    eisen->setze_symbol("Fe");
    eisen->setze_masse("55.845 u");
    eisen->setze_exakte_masse("55.934936");
    eisen->setze_ionisation("762.5 kJ/mol");
    eisen->setze_elektronenaffinitaet("15.7 kJ/mol");
    eisen->setze_elektronen_negativitaet("1.83");
    eisen->setze_kovalenter("132 pm");
    eisen->setze_van_der_waals_radius("194 pm");
    eisen->setze_schmelzpunkt("1811");
    eisen->setze_siedepunkt("3134");
    eisen->setze_familie(tr("transition metals"));
    eisen->setze_gruppenfarbe(gruppenfarben.at(8));
    eisen->setze_entdeckungsjahr(-5000);
    eisen->setze_position(7, 4);
    elementliste.insert(eisen->atomzahl(), eisen);
    eisen->fuege_elektronen_hinzu(1, 2);
    eisen->fuege_elektronen_hinzu(2, 8);
    eisen->fuege_elektronen_hinzu(3, 14);
    eisen->fuege_elektronen_hinzu(4, 2);

    // kobalt (gruppe 9, Übergangsmetalle)
    Element* kobalt = new Element(this);
    kobalt->setObjectName("kobalt");
    kobalt->setze_element_namen(tr("Cobalt"));
    kobalt->setze_atomzahl(27);
    kobalt->setze_symbol("Co");
    kobalt->setze_masse("58.9332 u");
    kobalt->setze_exakte_masse("58.933194");
    kobalt->setze_ionisation("760.4 kJ/mol");
    kobalt->setze_elektronenaffinitaet("63.7 kJ/mol");
    kobalt->setze_elektronen_negativitaet("1.88");
    kobalt->setze_kovalenter("126 pm");
    kobalt->setze_van_der_waals_radius("192 pm");
    kobalt->setze_schmelzpunkt("1768");
    kobalt->setze_siedepunkt("3200");
    kobalt->setze_familie(tr("transition metals"));
    kobalt->setze_gruppenfarbe(gruppenfarben.at(9));
    kobalt->setze_entdeckungsjahr(1735);
    kobalt->setze_position(8, 4);
    elementliste.insert(kobalt->atomzahl(), kobalt);
    kobalt->fuege_elektronen_hinzu(1, 2);
    kobalt->fuege_elektronen_hinzu(2, 8);
    kobalt->fuege_elektronen_hinzu(3, 15);
    kobalt->fuege_elektronen_hinzu(4, 2);

    // nickel (gruppe 10, Übergangsmetalle)
    Element* nickel = new Element(this);
    nickel->setObjectName("nickel");
    nickel->setze_element_namen(tr("Nickel"));
    nickel->setze_atomzahl(28);
    nickel->setze_symbol("Ni");
    nickel->setze_masse("58.6934 u");
    nickel->setze_exakte_masse("57.935342");
    nickel->setze_ionisation("737.1 kJ/mol");
    nickel->setze_elektronenaffinitaet("112 kJ/mol");
    nickel->setze_elektronen_negativitaet("1.91");
    nickel->setze_kovalenter("124 pm");
    nickel->setze_van_der_waals_radius("184 pm");
    nickel->setze_schmelzpunkt("1728");
    nickel->setze_siedepunkt("3186");
    nickel->setze_familie(tr("transition metals"));
    nickel->setze_gruppenfarbe(gruppenfarben.at(10));
    nickel->setze_entdeckungsjahr(1751);
    nickel->setze_position(9, 4);
    elementliste.insert(nickel->atomzahl(), nickel);
    nickel->fuege_elektronen_hinzu(1, 2);
    nickel->fuege_elektronen_hinzu(2, 8);
    nickel->fuege_elektronen_hinzu(3, 16);
    nickel->fuege_elektronen_hinzu(4, 2);

    // kupfer (gruppe 11, Übergangsmetalle)
    Element* kupfer = new Element(this);
    kupfer->setObjectName("kupfer");
    kupfer->setze_element_namen(tr("Copper"));
    kupfer->setze_atomzahl(29);
    kupfer->setze_symbol("Cu");
    kupfer->setze_masse("63.546 u");
    kupfer->setze_exakte_masse("62.929598");
    kupfer->setze_ionisation("745.5 kJ/mol");
    kupfer->setze_elektronenaffinitaet("118.4 kJ/mol");
    kupfer->setze_elektronen_negativitaet("1.9");
    kupfer->setze_kovalenter("132 pm");
    kupfer->setze_van_der_waals_radius("186 pm");
    kupfer->setze_schmelzpunkt("1357.8");
    kupfer->setze_siedepunkt("2835");
    kupfer->setze_familie(tr("transition metals"));
    kupfer->setze_gruppenfarbe(gruppenfarben.at(11));
    kupfer->setze_entdeckungsjahr(-6000);
    kupfer->setze_position(10, 4);
    elementliste.insert(kupfer->atomzahl(), kupfer);
    kupfer->fuege_elektronen_hinzu(1, 2);
    kupfer->fuege_elektronen_hinzu(2, 8);
    kupfer->fuege_elektronen_hinzu(3, 18);
    kupfer->fuege_elektronen_hinzu(4, 1);

    // zink (gruppe 12, Übergangsmetalle)
    Element* zink = new Element(this);
    zink->setObjectName("zink");
    zink->setze_element_namen(tr("Zinc"));
    zink->setze_atomzahl(30);
    zink->setze_symbol("Zn");
    zink->setze_masse("65.38 u");
    zink->setze_exakte_masse("63.929142");
    zink->setze_ionisation("906.4 kJ/mol");
    zink->setze_elektronenaffinitaet("0 kJ/mol");
    zink->setze_elektronen_negativitaet("1.65");
    zink->setze_kovalenter("122 pm");
    zink->setze_van_der_waals_radius("210 pm");
    zink->setze_schmelzpunkt("692.7");
    zink->setze_siedepunkt("1180");
    zink->setze_familie(tr("transition metals"));
    zink->setze_gruppenfarbe(gruppenfarben.at(12));
    zink->setze_entdeckungsjahr(-1000);
    zink->setze_position(11, 4);
    elementliste.insert(zink->atomzahl(), zink);
    zink->fuege_elektronen_hinzu(1, 2);
    zink->fuege_elektronen_hinzu(2, 8);
    zink->fuege_elektronen_hinzu(3, 18);
    zink->fuege_elektronen_hinzu(4, 2);

    // gallium (gruppe 13, Metalle)
    Element* gallium = new Element(this);
    gallium->setObjectName("gallium");
    gallium->setze_element_namen(tr("Gallium"));
    gallium->setze_atomzahl(31);
    gallium->setze_symbol("Ga");
    gallium->setze_masse("69.723 u");
    gallium->setze_exakte_masse("68.925574");
    gallium->setze_ionisation("578.8 kJ/mol");
    gallium->setze_elektronenaffinitaet("28.9 kJ/mol");
    gallium->setze_elektronen_negativitaet("1.81");
    gallium->setze_kovalenter("122 pm");
    gallium->setze_van_der_waals_radius("187 pm");
    gallium->setze_schmelzpunkt("302.9");
    gallium->setze_siedepunkt("2477");
    gallium->setze_familie(tr("metals"));
    gallium->setze_gruppenfarbe(gruppenfarben.at(13));
    gallium->setze_entdeckungsjahr(1875);
    gallium->setze_position(12, 4);
    elementliste.insert(gallium->atomzahl(), gallium);
    gallium->fuege_elektronen_hinzu(1, 2);
    gallium->fuege_elektronen_hinzu(2, 8);
    gallium->fuege_elektronen_hinzu(3, 18);
    gallium->fuege_elektronen_hinzu(4, 3);

    // germanium (gruppe 14, Halbmetalle)
    Element* germanium = new Element(this);
    germanium->setObjectName("germanium");
    germanium->setze_element_namen(tr("Germanium"));
    germanium->setze_atomzahl(32);
    germanium->setze_symbol("Ge");
    germanium->setze_masse("72.63 u");
    germanium->setze_exakte_masse("73.921178");
    germanium->setze_ionisation("762 kJ/mol");
    germanium->setze_elektronenaffinitaet("119 kJ/mol");
    germanium->setze_elektronen_negativitaet("2.01");
    germanium->setze_kovalenter("122 pm");
    germanium->setze_van_der_waals_radius("211 pm");
    germanium->setze_schmelzpunkt("1211.4");
    germanium->setze_siedepunkt("3106");
    germanium->setze_familie(tr("metalloids"));
    germanium->setze_gruppenfarbe(gruppenfarben.at(14));
    germanium->setze_entdeckungsjahr(1886);
    germanium->setze_position(13, 4);
    elementliste.insert(germanium->atomzahl(), germanium);
    germanium->fuege_elektronen_hinzu(1, 2);
    germanium->fuege_elektronen_hinzu(2, 8);
    germanium->fuege_elektronen_hinzu(3, 18);
    germanium->fuege_elektronen_hinzu(4, 4);

    // arsen (gruppe 15, Halbmetalle)
    Element* arsen = new Element(this);
    arsen->setObjectName("arsen");
    arsen->setze_element_namen(tr("Arsenic"));
    arsen->setze_atomzahl(33);
    arsen->setze_symbol("As");
    arsen->setze_masse("74.9216 u");
    arsen->setze_exakte_masse("74.921595");
    arsen->setze_ionisation("947 kJ/mol");
    arsen->setze_elektronenaffinitaet("78 kJ/mol");
    arsen->setze_elektronen_negativitaet("2.18");
    arsen->setze_kovalenter("119 pm");
    arsen->setze_van_der_waals_radius("185 pm");
    arsen->setze_schmelzpunkt("-1"); //sublimation
    arsen->setze_siedepunkt("887");
    arsen->setze_familie(tr("metalloids"));
    arsen->setze_gruppenfarbe(gruppenfarben.at(15));
    arsen->setze_entdeckungsjahr(1250);
    arsen->setze_position(14, 4);
    elementliste.insert(arsen->atomzahl(), arsen);
    arsen->fuege_elektronen_hinzu(1, 2);
    arsen->fuege_elektronen_hinzu(2, 8);
    arsen->fuege_elektronen_hinzu(3, 18);
    arsen->fuege_elektronen_hinzu(4, 5);

    // selen (gruppe 16, Halbmetalle)
    Element* selen = new Element(this);
    selen->setObjectName("selen");
    selen->setze_element_namen(tr("Selenium"));
    selen->setze_atomzahl(34);
    selen->setze_symbol("Se");
    selen->setze_masse("78.96 u");
    selen->setze_exakte_masse("79.916521");
    selen->setze_ionisation("941 kJ/mol");
    selen->setze_elektronenaffinitaet("195 kJ/mol");
    selen->setze_elektronen_negativitaet("2.55");
    selen->setze_kovalenter("120 pm");
    selen->setze_van_der_waals_radius("190 pm");
    selen->setze_schmelzpunkt("494");
    selen->setze_siedepunkt("958");
    selen->setze_familie(tr("metalloids"));
    selen->setze_gruppenfarbe(gruppenfarben.at(16));
    selen->setze_entdeckungsjahr(1817);
    selen->setze_position(15, 4);
    elementliste.insert(selen->atomzahl(), selen);
    selen->fuege_elektronen_hinzu(1, 2);
    selen->fuege_elektronen_hinzu(2, 8);
    selen->fuege_elektronen_hinzu(3, 18);
    selen->fuege_elektronen_hinzu(4, 6);

    // brom (gruppe 17, Halogene)
    Element* brom = new Element(this);
    brom->setObjectName("brom");
    brom->setze_element_namen(tr("Bromine"));
    brom->setze_atomzahl(35);
    brom->setze_symbol("Br");
    brom->setze_masse("79.904 u");
    brom->setze_exakte_masse("78.918337");
    brom->setze_ionisation("1139.9 kJ/mol");
    brom->setze_elektronenaffinitaet("349 kJ/mol");
    brom->setze_elektronen_negativitaet("2.96");
    brom->setze_kovalenter("120 pm");
    brom->setze_van_der_waals_radius("183 pm");
    brom->setze_schmelzpunkt("265.8");
    brom->setze_siedepunkt("332");
    brom->setze_familie(tr("halogens"));
    brom->setze_gruppenfarbe(gruppenfarben.at(17));
    brom->setze_entdeckungsjahr(1825);
    brom->setze_position(16, 4);
    elementliste.insert(brom->atomzahl(), brom);
    brom->fuege_elektronen_hinzu(1, 2);
    brom->fuege_elektronen_hinzu(2, 8);
    brom->fuege_elektronen_hinzu(3, 18);
    brom->fuege_elektronen_hinzu(4, 7);

    // krypton (gruppe 18, Edelgase)
    Element* krypton = new Element(this);
    krypton->setObjectName("krypton");
    krypton->setze_element_namen(tr("Krypton"));
    krypton->setze_atomzahl(36);
    krypton->setze_symbol("Kr");
    krypton->setze_masse("83.798 u");
    krypton->setze_exakte_masse("83.911498");
    krypton->setze_ionisation("1350.8 kJ/mol");
    krypton->setze_elektronenaffinitaet("0 kJ/mol");
    krypton->setze_elektronen_negativitaet("3");
    krypton->setze_kovalenter("116 pm");
    krypton->setze_van_der_waals_radius("202 pm");
    krypton->setze_schmelzpunkt("115.8");
    krypton->setze_siedepunkt("119.9");
    krypton->setze_familie(tr("noble gases"));
    krypton->setze_gruppenfarbe(gruppenfarben.at(18));
    krypton->setze_entdeckungsjahr(1898);
    krypton->setze_position(17, 4);
    elementliste.insert(krypton->atomzahl(), krypton);
    krypton->fuege_elektronen_hinzu(1, 2);
    krypton->fuege_elektronen_hinzu(2, 8);
    krypton->fuege_elektronen_hinzu(3, 18);
    krypton->fuege_elektronen_hinzu(4, 8);

    // rubidium (gruppe 1, Alkalimetalle)
    Element* rubidium = new Element(this);
    rubidium->setObjectName("rubidium");
    rubidium->setze_element_namen(tr("Rubidium"));
    rubidium->setze_atomzahl(37);
    rubidium->setze_symbol("Rb");
    rubidium->setze_masse("85.4678 u");
    rubidium->setze_exakte_masse("84.911790");
    rubidium->setze_ionisation("403 kJ/mol");
    rubidium->setze_elektronenaffinitaet("46.9 kJ/mol");
    rubidium->setze_elektronen_negativitaet("0.82");
    rubidium->setze_kovalenter("220 pm");
    rubidium->setze_van_der_waals_radius("303 pm");
    rubidium->setze_schmelzpunkt("312.5");
    rubidium->setze_siedepunkt("961");
    rubidium->setze_familie(tr("alkali metals"));
    rubidium->setze_gruppenfarbe(gruppenfarben.at(1));
    rubidium->setze_entdeckungsjahr(1861);
    rubidium->setze_position(0, 5);
    elementliste.insert(rubidium->atomzahl(), rubidium);
    rubidium->fuege_elektronen_hinzu(1, 2);
    rubidium->fuege_elektronen_hinzu(2, 8);
    rubidium->fuege_elektronen_hinzu(3, 18);
    rubidium->fuege_elektronen_hinzu(4, 8);
    rubidium->fuege_elektronen_hinzu(5, 1);

    // strontium (gruppe 2, Erdalkalimetalle)
    Element* strontium = new Element(this);
    strontium->setObjectName("strontium");
    strontium->setze_element_namen(tr("Strontium"));
    strontium->setze_atomzahl(38);
    strontium->setze_symbol("Sr");
    strontium->setze_masse("87.62 u");
    strontium->setze_exakte_masse("87.905613");
    strontium->setze_ionisation("549.5 kJ/mol");
    strontium->setze_elektronenaffinitaet("5.03 kJ/mol");
    strontium->setze_elektronen_negativitaet("0.95");
    strontium->setze_kovalenter("195 pm");
    strontium->setze_van_der_waals_radius("249 pm");
    strontium->setze_schmelzpunkt("1050");
    strontium->setze_siedepunkt("1655");
    strontium->setze_familie(tr("alkaline earth metals"));
    strontium->setze_gruppenfarbe(gruppenfarben.at(2));
    strontium->setze_entdeckungsjahr(1790);
    strontium->setze_position(1, 5);
    elementliste.insert(strontium->atomzahl(), strontium);
    strontium->fuege_elektronen_hinzu(1, 2);
    strontium->fuege_elektronen_hinzu(2, 8);
    strontium->fuege_elektronen_hinzu(3, 18);
    strontium->fuege_elektronen_hinzu(4, 8);
    strontium->fuege_elektronen_hinzu(5, 2);

    // yttrium (gruppe 3, Übergangsmetalle)
    Element* yttrium = new Element(this);
    yttrium->setObjectName("yttrium");
    yttrium->setze_element_namen(tr("Yttrium"));
    yttrium->setze_atomzahl(39);
    yttrium->setze_symbol("Y");
    yttrium->setze_masse("88.906 u");
    yttrium->setze_exakte_masse("88.905840");
    yttrium->setze_ionisation("600 kJ/mol");
    yttrium->setze_elektronenaffinitaet("29.6 kJ/mol");
    yttrium->setze_elektronen_negativitaet("1.22");
    yttrium->setze_kovalenter("190 pm");
    yttrium->setze_van_der_waals_radius("219 pm");
    yttrium->setze_schmelzpunkt("1799");
    yttrium->setze_siedepunkt("3609");
    yttrium->setze_familie(tr("transition metals"));
    yttrium->setze_gruppenfarbe(gruppenfarben.at(3));
    yttrium->setze_entdeckungsjahr(1794);
    yttrium->setze_position(2, 5);
    elementliste.insert(yttrium->atomzahl(), yttrium);
    yttrium->fuege_elektronen_hinzu(1, 2);
    yttrium->fuege_elektronen_hinzu(2, 8);
    yttrium->fuege_elektronen_hinzu(3, 18);
    yttrium->fuege_elektronen_hinzu(4, 9);
    yttrium->fuege_elektronen_hinzu(5, 2);

    // zirconium (gruppe 4, Übergangsmetalle)
    Element* zirconium = new Element(this);
    zirconium->setObjectName("zirconium");
    zirconium->setze_element_namen(tr("Zirconium"));
    zirconium->setze_atomzahl(40);
    zirconium->setze_symbol("Zr");
    zirconium->setze_masse("91.224 u");
    zirconium->setze_exakte_masse("89.904697");
    zirconium->setze_ionisation("640.1 kJ/mol");
    zirconium->setze_elektronenaffinitaet("41.1 kJ/mol");
    zirconium->setze_elektronen_negativitaet("1.33");
    zirconium->setze_kovalenter("175 pm");
    zirconium->setze_van_der_waals_radius("186 pm");
    zirconium->setze_schmelzpunkt("2128");
    zirconium->setze_siedepunkt("4682");
    zirconium->setze_familie(tr("transition metals"));
    zirconium->setze_gruppenfarbe(gruppenfarben.at(4));
    zirconium->setze_entdeckungsjahr(1789);
    zirconium->setze_position(3, 5);
    elementliste.insert(zirconium->atomzahl(), zirconium);
    zirconium->fuege_elektronen_hinzu(1, 2);
    zirconium->fuege_elektronen_hinzu(2, 8);
    zirconium->fuege_elektronen_hinzu(3, 18);
    zirconium->fuege_elektronen_hinzu(4, 10);
    zirconium->fuege_elektronen_hinzu(5, 2);

    // niob (gruppe 5, Übergangsmetalle)
    Element* niob = new Element(this);
    niob->setObjectName("niob");
    niob->setze_element_namen(tr("Niobium"));
    niob->setze_atomzahl(41);
    niob->setze_symbol("Nb");
    niob->setze_masse("92.9064 u");
    niob->setze_exakte_masse("92.906372");
    niob->setze_ionisation("652.1 kJ/mol");
    niob->setze_elektronenaffinitaet("86.1 kJ/mol");
    niob->setze_elektronen_negativitaet("1.6");
    niob->setze_kovalenter("164 pm");
    niob->setze_van_der_waals_radius("207 pm");
    niob->setze_schmelzpunkt("2750");
    niob->setze_siedepunkt("5017");
    niob->setze_familie(tr("transition metals"));
    niob->setze_gruppenfarbe(gruppenfarben.at(5));
    niob->setze_entdeckungsjahr(1801);
    niob->setze_position(4, 5);
    elementliste.insert(niob->atomzahl(), niob);
    niob->fuege_elektronen_hinzu(1, 2);
    niob->fuege_elektronen_hinzu(2, 8);
    niob->fuege_elektronen_hinzu(3, 18);
    niob->fuege_elektronen_hinzu(4, 12);
    niob->fuege_elektronen_hinzu(5, 1);

    // molybdaen (gruppe 6, Übergangsmetalle)
    Element* molybdaen = new Element(this);
    molybdaen->setObjectName("molybdaen");
    molybdaen->setze_element_namen(tr("Molybdenum"));
    molybdaen->setze_atomzahl(42);
    molybdaen->setze_symbol("Mo");
    molybdaen->setze_masse("95.94 u");
    molybdaen->setze_exakte_masse("97.905403");
    molybdaen->setze_ionisation("684.3 kJ/mol");
    molybdaen->setze_elektronenaffinitaet("71.9 kJ/mol");
    molybdaen->setze_elektronen_negativitaet("2.16");
    molybdaen->setze_kovalenter("154 pm");
    molybdaen->setze_van_der_waals_radius("209 pm");
    molybdaen->setze_schmelzpunkt("2896");
    molybdaen->setze_siedepunkt("4912");
    molybdaen->setze_familie(tr("transition metals"));
    molybdaen->setze_gruppenfarbe(gruppenfarben.at(6));
    molybdaen->setze_entdeckungsjahr(1778);
    molybdaen->setze_position(5, 5);
    elementliste.insert(molybdaen->atomzahl(), molybdaen);
    molybdaen->fuege_elektronen_hinzu(1, 2);
    molybdaen->fuege_elektronen_hinzu(2, 8);
    molybdaen->fuege_elektronen_hinzu(3, 18);
    molybdaen->fuege_elektronen_hinzu(4, 13);
    molybdaen->fuege_elektronen_hinzu(5, 1);

    // technetium (gruppe 7, Übergangsmetalle)
    Element* technetium = new Element(this);
    technetium->setObjectName("technetium");
    technetium->setze_element_namen(tr("Technetium"));
    technetium->setze_atomzahl(43);
    technetium->setze_symbol("Tc");
    technetium->setze_masse("98 u"); //certain
    technetium->setze_exakte_masse("97.907212");
    technetium->setze_ionisation("702 kJ/mol");
    technetium->setze_elektronenaffinitaet("53 kJ/mol");
    technetium->setze_elektronen_negativitaet("1.9");
    technetium->setze_kovalenter("147 pm");
    technetium->setze_van_der_waals_radius("209 pm");
    technetium->setze_schmelzpunkt("2430");
    technetium->setze_siedepunkt("4538");
    technetium->setze_familie(tr("transition metals"));
    technetium->setze_gruppenfarbe(gruppenfarben.at(7));
    technetium->setze_entdeckungsjahr(1937);
    technetium->setze_position(6, 5);
    elementliste.insert(technetium->atomzahl(), technetium);
    technetium->fuege_elektronen_hinzu(1, 2);
    technetium->fuege_elektronen_hinzu(2, 8);
    technetium->fuege_elektronen_hinzu(3, 18);
    technetium->fuege_elektronen_hinzu(4, 14);
    technetium->fuege_elektronen_hinzu(5, 1);

    // ruthenium (gruppe 8, Übergangsmetalle)
    Element* ruthenium = new Element(this);
    ruthenium->setObjectName("ruthenium");
    ruthenium->setze_element_namen(tr("Ruthenium"));
    ruthenium->setze_atomzahl(44);
    ruthenium->setze_symbol("Ru");
    ruthenium->setze_masse("101.07 u");
    ruthenium->setze_exakte_masse("101.904346");
    ruthenium->setze_ionisation("710.2 kJ/mol");
    ruthenium->setze_elektronenaffinitaet("101.3 kJ/mol");
    ruthenium->setze_elektronen_negativitaet("2.2");
    ruthenium->setze_kovalenter("146 pm");
    ruthenium->setze_van_der_waals_radius("207 pm");
    ruthenium->setze_schmelzpunkt("2607");
    ruthenium->setze_siedepunkt("4423");
    ruthenium->setze_familie(tr("transition metals"));
    ruthenium->setze_gruppenfarbe(gruppenfarben.at(8));
    ruthenium->setze_entdeckungsjahr(1844);
    ruthenium->setze_position(7, 5);
    elementliste.insert(ruthenium->atomzahl(), ruthenium);
    ruthenium->fuege_elektronen_hinzu(1, 2);
    ruthenium->fuege_elektronen_hinzu(2, 8);
    ruthenium->fuege_elektronen_hinzu(3, 18);
    ruthenium->fuege_elektronen_hinzu(4, 15);
    ruthenium->fuege_elektronen_hinzu(5, 1);

    // rhodium (gruppe 9, Übergangsmetalle)
    Element* rhodium = new Element(this);
    rhodium->setObjectName("rhodium");
    rhodium->setze_element_namen(tr("Rhodium"));
    rhodium->setze_atomzahl(45);
    rhodium->setze_symbol("Rh");
    rhodium->setze_masse("102.906 u");
    rhodium->setze_exakte_masse("102.90551");
    rhodium->setze_ionisation("719.7 kJ/mol");
    rhodium->setze_elektronenaffinitaet("109.7 kJ/mol");
    rhodium->setze_elektronen_negativitaet("2.28");
    rhodium->setze_kovalenter("142 pm");
    rhodium->setze_van_der_waals_radius("195 pm");
    rhodium->setze_schmelzpunkt("2237");
    rhodium->setze_siedepunkt("3968");
    rhodium->setze_familie(tr("transition metals"));
    rhodium->setze_gruppenfarbe(gruppenfarben.at(9));
    rhodium->setze_entdeckungsjahr(1803);
    rhodium->setze_position(8, 5);
    elementliste.insert(rhodium->atomzahl(), rhodium);
    rhodium->fuege_elektronen_hinzu(1, 2);
    rhodium->fuege_elektronen_hinzu(2, 8);
    rhodium->fuege_elektronen_hinzu(3, 18);
    rhodium->fuege_elektronen_hinzu(4, 16);
    rhodium->fuege_elektronen_hinzu(5, 1);

    // palladium (gruppe 10, Übergangsmetalle)
    Element* palladium = new Element(this);
    palladium->setObjectName("palladium");
    palladium->setze_element_namen(tr("Palladium"));
    palladium->setze_atomzahl(46);
    palladium->setze_symbol("Pd");
    palladium->setze_masse("106.42 u");
    palladium->setze_exakte_masse("105.903482");
    palladium->setze_ionisation("804.4 kJ/mol");
    palladium->setze_elektronenaffinitaet("53.7 kJ/mol");
    palladium->setze_elektronen_negativitaet("2.2");
    palladium->setze_kovalenter("139 pm");
    palladium->setze_van_der_waals_radius("202 pm");
    palladium->setze_schmelzpunkt("1828.1");
    palladium->setze_siedepunkt("3236");
    palladium->setze_familie(tr("transition metals"));
    palladium->setze_gruppenfarbe(gruppenfarben.at(10));
    palladium->setze_entdeckungsjahr(1803);
    palladium->setze_position(9, 5);
    elementliste.insert(palladium->atomzahl(), palladium);
    palladium->fuege_elektronen_hinzu(1, 2);
    palladium->fuege_elektronen_hinzu(2, 8);
    palladium->fuege_elektronen_hinzu(3, 18);
    palladium->fuege_elektronen_hinzu(4, 18);

    // silber (gruppe 11, Übergangsmetalle)
    Element* silber = new Element(this);
    silber->setObjectName("silber");
    silber->setze_element_namen(tr("Silver"));
    silber->setze_atomzahl(47);
    silber->setze_symbol("Ag");
    silber->setze_masse("107.8682 u");
    silber->setze_exakte_masse("106.905093");
    silber->setze_ionisation("731 kJ/mol");
    silber->setze_elektronenaffinitaet("125.6 kJ/mol");
    silber->setze_elektronen_negativitaet("1.93");
    silber->setze_kovalenter("172 pm");
    silber->setze_van_der_waals_radius("203 pm");
    silber->setze_schmelzpunkt("1234.9");
    silber->setze_siedepunkt("2435");
    silber->setze_familie(tr("transition metals"));
    silber->setze_gruppenfarbe(gruppenfarben.at(11));
    silber->setze_entdeckungsjahr(-4000);
    silber->setze_position(10, 5);
    elementliste.insert(silber->atomzahl(), silber);
    silber->fuege_elektronen_hinzu(1, 2);
    silber->fuege_elektronen_hinzu(2, 8);
    silber->fuege_elektronen_hinzu(3, 18);
    silber->fuege_elektronen_hinzu(4, 18);
    silber->fuege_elektronen_hinzu(5, 1);

    // cadmium (gruppe 12, Übergangsmetalle)
    Element* cadmium = new Element(this);
    cadmium->setObjectName("cadmium");
    cadmium->setze_element_namen(tr("Cadmium"));
    cadmium->setze_atomzahl(48);
    cadmium->setze_symbol("Cd");
    cadmium->setze_masse("112.411 u");
    cadmium->setze_exakte_masse("113.903361");
    cadmium->setze_ionisation("867.8 kJ/mol");
    cadmium->setze_elektronenaffinitaet("0 kJ/mol");
    cadmium->setze_elektronen_negativitaet("1.69");
    cadmium->setze_kovalenter("144 pm");
    cadmium->setze_van_der_waals_radius("230 pm");
    cadmium->setze_schmelzpunkt("594.2");
    cadmium->setze_siedepunkt("1040");
    cadmium->setze_familie(tr("transition metals"));
    cadmium->setze_gruppenfarbe(gruppenfarben.at(12));
    cadmium->setze_entdeckungsjahr(1817);
    cadmium->setze_position(11, 5);
    elementliste.insert(cadmium->atomzahl(), cadmium);
    cadmium->fuege_elektronen_hinzu(1, 2);
    cadmium->fuege_elektronen_hinzu(2, 8);
    cadmium->fuege_elektronen_hinzu(3, 18);
    cadmium->fuege_elektronen_hinzu(4, 18);
    cadmium->fuege_elektronen_hinzu(5, 2);

    // indium (gruppe 13, Metalle)
    Element* indium = new Element(this);
    indium->setObjectName("indium");
    indium->setze_element_namen(tr("Indium"));
    indium->setze_atomzahl(49);
    indium->setze_symbol("In");
    indium->setze_masse("114.818 u");
    indium->setze_exakte_masse("114.903879");
    indium->setze_ionisation("558.3 kJ/mol");
    indium->setze_elektronenaffinitaet("28.9 kJ/mol");
    indium->setze_elektronen_negativitaet("1.78");
    indium->setze_kovalenter("142 pm");
    indium->setze_van_der_waals_radius("193 pm");
    indium->setze_schmelzpunkt("429.7");
    indium->setze_siedepunkt("2345");
    indium->setze_familie(tr("metals"));
    indium->setze_gruppenfarbe(gruppenfarben.at(13));
    indium->setze_entdeckungsjahr(1863);
    indium->setze_position(12, 5);
    elementliste.insert(indium->atomzahl(), indium);
    indium->fuege_elektronen_hinzu(1, 2);
    indium->fuege_elektronen_hinzu(2, 8);
    indium->fuege_elektronen_hinzu(3, 18);
    indium->fuege_elektronen_hinzu(4, 18);
    indium->fuege_elektronen_hinzu(5, 3);

    // zinn (gruppe 14, Metalle)
    Element* zinn = new Element(this);
    zinn->setObjectName("zinn");
    zinn->setze_element_namen(tr("Tin"));
    zinn->setze_atomzahl(50);
    zinn->setze_symbol("Sn");
    zinn->setze_masse("118.71 u");
    zinn->setze_exakte_masse("119.902202");
    zinn->setze_ionisation("708.6 kJ/mol");
    zinn->setze_elektronenaffinitaet("107.3 kJ/mol");
    zinn->setze_elektronen_negativitaet("1.96");
    zinn->setze_kovalenter("139 pm");
    zinn->setze_van_der_waals_radius("217 pm");
    zinn->setze_schmelzpunkt("505.1");
    zinn->setze_siedepunkt("2876");
    zinn->setze_familie(tr("metals"));
    zinn->setze_gruppenfarbe(gruppenfarben.at(14));
    zinn->setze_entdeckungsjahr(-3000);
    zinn->setze_position(13, 5);
    elementliste.insert(zinn->atomzahl(), zinn);
    zinn->fuege_elektronen_hinzu(1, 2);
    zinn->fuege_elektronen_hinzu(2, 8);
    zinn->fuege_elektronen_hinzu(3, 18);
    zinn->fuege_elektronen_hinzu(4, 18);
    zinn->fuege_elektronen_hinzu(5, 4);

    // antimon (gruppe 15, Halbmetalle)
    Element* antimon = new Element(this);
    antimon->setObjectName("antimon");
    antimon->setze_element_namen(tr("Antimony"));
    antimon->setze_atomzahl(51);
    antimon->setze_symbol("Sb");
    antimon->setze_masse("121.76 u");
    antimon->setze_exakte_masse("120.903811");
    antimon->setze_ionisation("834 kJ/mol");
    antimon->setze_elektronenaffinitaet("103.2 kJ/mol");
    antimon->setze_elektronen_negativitaet("2.05");
    antimon->setze_kovalenter("139 pm");
    antimon->setze_van_der_waals_radius("206 pm");
    antimon->setze_schmelzpunkt("903.8");
    antimon->setze_siedepunkt("1860");
    antimon->setze_familie(tr("metalloids"));
    antimon->setze_gruppenfarbe(gruppenfarben.at(15));
    antimon->setze_entdeckungsjahr(-3000);
    antimon->setze_position(14, 5);
    elementliste.insert(antimon->atomzahl(), antimon);
    antimon->fuege_elektronen_hinzu(1, 2);
    antimon->fuege_elektronen_hinzu(2, 8);
    antimon->fuege_elektronen_hinzu(3, 18);
    antimon->fuege_elektronen_hinzu(4, 18);
    antimon->fuege_elektronen_hinzu(5, 5);

    // tellur (gruppe 16, Halbmetalle)
    Element* tellur = new Element(this);
    tellur->setObjectName("tellur");
    tellur->setze_element_namen(tr("Tellurium"));
    tellur->setze_atomzahl(52);
    tellur->setze_symbol("Te");
    tellur->setze_masse("127.6 u");
    tellur->setze_exakte_masse("129.906223");
    tellur->setze_ionisation("869.3 kJ/mol");
    tellur->setze_elektronenaffinitaet("190.2 kJ/mol");
    tellur->setze_elektronen_negativitaet("2.1");
    tellur->setze_kovalenter("138 pm");
    tellur->setze_van_der_waals_radius("206 pm");
    tellur->setze_schmelzpunkt("722.7");
    tellur->setze_siedepunkt("1261");
    tellur->setze_familie(tr("metalloids"));
    tellur->setze_gruppenfarbe(gruppenfarben.at(16));
    tellur->setze_entdeckungsjahr(1782);
    tellur->setze_position(15, 5);
    elementliste.insert(tellur->atomzahl(), tellur);
    tellur->fuege_elektronen_hinzu(1, 2);
    tellur->fuege_elektronen_hinzu(2, 8);
    tellur->fuege_elektronen_hinzu(3, 18);
    tellur->fuege_elektronen_hinzu(4, 18);
    tellur->fuege_elektronen_hinzu(5, 6);

    // iod (gruppe 17, Halogene)
    Element* iod = new Element(this);
    iod->setObjectName("iod");
    iod->setze_element_namen(tr("Iodine"));
    iod->setze_atomzahl(53);
    iod->setze_symbol("I");
    iod->setze_masse("126.904 u");
    iod->setze_exakte_masse("126.904471");
    iod->setze_ionisation("1008.4 kJ/mol");
    iod->setze_elektronenaffinitaet("295.2 kJ/mol");
    iod->setze_elektronen_negativitaet("2.66");
    iod->setze_kovalenter("139 pm");
    iod->setze_van_der_waals_radius("198 pm");
    iod->setze_schmelzpunkt("386.9");
    iod->setze_siedepunkt("457.4");
    iod->setze_familie(tr("halogens"));
    iod->setze_gruppenfarbe(gruppenfarben.at(17));
    iod->setze_entdeckungsjahr(1811);
    iod->setze_position(16, 5);
    elementliste.insert(iod->atomzahl(), iod);
    iod->fuege_elektronen_hinzu(1, 2);
    iod->fuege_elektronen_hinzu(2, 8);
    iod->fuege_elektronen_hinzu(3, 18);
    iod->fuege_elektronen_hinzu(4, 18);
    iod->fuege_elektronen_hinzu(5, 7);

    // xenon (gruppe 18, Edelgase)
    Element* xenon = new Element(this);
    xenon->setObjectName("xenon");
    xenon->setze_element_namen(tr("Xenon"));
    xenon->setze_atomzahl(54);
    xenon->setze_symbol("Xe");
    xenon->setze_masse("131.293 u");
    xenon->setze_exakte_masse("131.904155");
    xenon->setze_ionisation("1170.4 kJ/mol");
    xenon->setze_elektronenaffinitaet("0 kJ/mol");
    xenon->setze_elektronen_negativitaet("2.6");
    xenon->setze_kovalenter("140 pm");
    xenon->setze_van_der_waals_radius("216 pm");
    xenon->setze_schmelzpunkt("161.4");
    xenon->setze_siedepunkt("165");
    xenon->setze_familie(tr("noble gases"));
    xenon->setze_gruppenfarbe(gruppenfarben.at(18));
    xenon->setze_entdeckungsjahr(1898);
    xenon->setze_position(17, 5);
    elementliste.insert(xenon->atomzahl(), xenon);
    xenon->fuege_elektronen_hinzu(1, 2);
    xenon->fuege_elektronen_hinzu(2, 8);
    xenon->fuege_elektronen_hinzu(3, 18);
    xenon->fuege_elektronen_hinzu(4, 18);
    xenon->fuege_elektronen_hinzu(5, 8);

    // caesium (gruppe 1, Alkalimetalle)
    Element* caesium = new Element(this);
    caesium->setObjectName("caesium");
    caesium->setze_element_namen(tr("Caesium"));
    caesium->setze_atomzahl(55);
    caesium->setze_symbol("Cs");
    caesium->setze_masse("132.905 u");
    caesium->setze_exakte_masse("132.905452");
    caesium->setze_ionisation("375.7 kJ/mol");
    caesium->setze_elektronenaffinitaet("45.5 kJ/mol");
    caesium->setze_elektronen_negativitaet("0.79");
    caesium->setze_kovalenter("244 pm");
    caesium->setze_van_der_waals_radius("343 pm");
    caesium->setze_schmelzpunkt("301.6");
    caesium->setze_siedepunkt("944");
    caesium->setze_familie(tr("alkali metals"));
    caesium->setze_gruppenfarbe(gruppenfarben.at(1));
    caesium->setze_entdeckungsjahr(1860);
    caesium->setze_position(0, 6);
    elementliste.insert(caesium->atomzahl(), caesium);
    caesium->fuege_elektronen_hinzu(1, 2);
    caesium->fuege_elektronen_hinzu(2, 8);
    caesium->fuege_elektronen_hinzu(3, 18);
    caesium->fuege_elektronen_hinzu(4, 18);
    caesium->fuege_elektronen_hinzu(5, 8);
    caesium->fuege_elektronen_hinzu(6, 1);

    // barium (gruppe 2, Erdalkalimetalle)
    Element* barium = new Element(this);
    barium->setObjectName("barium");
    barium->setze_element_namen(tr("Barium"));
    barium->setze_atomzahl(56);
    barium->setze_symbol("Ba");
    barium->setze_masse("137.33 u");
    barium->setze_exakte_masse("137.905247");
    barium->setze_ionisation("502.9 kJ/mol");
    barium->setze_elektronenaffinitaet("13.95 kJ/mol");
    barium->setze_elektronen_negativitaet("0.89");
    barium->setze_kovalenter("215 pm");
    barium->setze_van_der_waals_radius("268 pm");
    barium->setze_schmelzpunkt("1000");
    barium->setze_siedepunkt("2170");
    barium->setze_familie(tr("alkaline earth metals"));
    barium->setze_gruppenfarbe(gruppenfarben.at(2));
    barium->setze_entdeckungsjahr(1808);
    barium->setze_position(1, 6);
    elementliste.insert(barium->atomzahl(), barium);
    barium->fuege_elektronen_hinzu(1, 2);
    barium->fuege_elektronen_hinzu(2, 8);
    barium->fuege_elektronen_hinzu(3, 18);
    barium->fuege_elektronen_hinzu(4, 18);
    barium->fuege_elektronen_hinzu(5, 8);
    barium->fuege_elektronen_hinzu(6, 2);

    // lanthan (gruppe 19, Lanthanoide)
    Element* lanthan = new Element(this);
    lanthan->setObjectName("lanthan");
    lanthan->setze_element_namen(tr("Lanthanum"));
    lanthan->setze_atomzahl(57);
    lanthan->setze_symbol("La");
    lanthan->setze_masse("138.905 u");
    lanthan->setze_exakte_masse("138.906357");
    lanthan->setze_ionisation("538.1 kJ/mol");
    lanthan->setze_elektronenaffinitaet("48 kJ/mol");
    lanthan->setze_elektronen_negativitaet("1.1");
    lanthan->setze_kovalenter("207 pm");
    lanthan->setze_van_der_waals_radius("240 pm");
    lanthan->setze_schmelzpunkt("1193");
    lanthan->setze_siedepunkt("3737");
    lanthan->setze_familie(tr("lanthanides"));
    lanthan->setze_gruppenfarbe(gruppenfarben.at(19));
    lanthan->setze_entdeckungsjahr(1839);
    lanthan->setze_position(2, 8);
    elementliste.insert(lanthan->atomzahl(), lanthan);
    lanthan->fuege_elektronen_hinzu(1, 2);
    lanthan->fuege_elektronen_hinzu(2, 8);
    lanthan->fuege_elektronen_hinzu(3, 18);
    lanthan->fuege_elektronen_hinzu(4, 18);
    lanthan->fuege_elektronen_hinzu(5, 9);
    lanthan->fuege_elektronen_hinzu(6, 2);

    // cer (gruppe 19, Lanthanoide)
    Element* cer = new Element(this);
    cer->setObjectName("cer");
    cer->setze_element_namen(tr("Cerium"));
    cer->setze_atomzahl(58);
    cer->setze_symbol("Ce");
    cer->setze_masse("140.116 u");
    cer->setze_exakte_masse("139.905443");
    cer->setze_ionisation("534.4 kJ/mol");
    cer->setze_elektronenaffinitaet("50 kJ/mol");
    cer->setze_elektronen_negativitaet("1.12");
    cer->setze_kovalenter("204 pm");
    cer->setze_van_der_waals_radius("235 pm");
    cer->setze_schmelzpunkt("1068");
    cer->setze_siedepunkt("3716");
    cer->setze_familie(tr("lanthanides"));
    cer->setze_gruppenfarbe(gruppenfarben.at(19));
    cer->setze_entdeckungsjahr(1803);
    cer->setze_position(3, 8);
    elementliste.insert(cer->atomzahl(), cer);
    cer->fuege_elektronen_hinzu(1, 2);
    cer->fuege_elektronen_hinzu(2, 8);
    cer->fuege_elektronen_hinzu(3, 18);
    cer->fuege_elektronen_hinzu(4, 19);
    cer->fuege_elektronen_hinzu(5, 9);
    cer->fuege_elektronen_hinzu(6, 2);

    // praseodym (gruppe 19, Lanthanoide)
    Element* praseodym = new Element(this);
    praseodym->setObjectName("praseodym");
    praseodym->setze_element_namen(tr("Praseodymium"));
    praseodym->setze_atomzahl(59);
    praseodym->setze_symbol("Pr");
    praseodym->setze_masse("140.908 u");
    praseodym->setze_exakte_masse("140.907658");
    praseodym->setze_ionisation("527 kJ/mol");
    praseodym->setze_elektronenaffinitaet("50 kJ/mol");
    praseodym->setze_elektronen_negativitaet("1.13");
    praseodym->setze_kovalenter("203 pm");
    praseodym->setze_van_der_waals_radius("239 pm");
    praseodym->setze_schmelzpunkt("1208");
    praseodym->setze_siedepunkt("3793");
    praseodym->setze_familie(tr("lanthanides"));
    praseodym->setze_gruppenfarbe(gruppenfarben.at(19));
    praseodym->setze_entdeckungsjahr(1885);
    praseodym->setze_position(4, 8);
    elementliste.insert(praseodym->atomzahl(), praseodym);
    praseodym->fuege_elektronen_hinzu(1, 2);
    praseodym->fuege_elektronen_hinzu(2, 8);
    praseodym->fuege_elektronen_hinzu(3, 18);
    praseodym->fuege_elektronen_hinzu(4, 21);
    praseodym->fuege_elektronen_hinzu(5, 8);
    praseodym->fuege_elektronen_hinzu(6, 2);

    // neodym (gruppe 19, Lanthanoide)
    Element* neodym = new Element(this);
    neodym->setObjectName("neodym");
    neodym->setze_element_namen(tr("Neodymium"));
    neodym->setze_atomzahl(60);
    neodym->setze_symbol("Nd");
    neodym->setze_masse("144.242 u");
    neodym->setze_exakte_masse("141.907730");
    neodym->setze_ionisation("533.1 kJ/mol");
    neodym->setze_elektronenaffinitaet("50 kJ/mol");
    neodym->setze_elektronen_negativitaet("1.14");
    neodym->setze_kovalenter("201 pm");
    neodym->setze_van_der_waals_radius("229 pm");
    neodym->setze_schmelzpunkt("1297");
    neodym->setze_siedepunkt("3347");
    neodym->setze_familie(tr("lanthanides"));
    neodym->setze_gruppenfarbe(gruppenfarben.at(19));
    neodym->setze_entdeckungsjahr(1885);
    neodym->setze_position(5, 8);
    elementliste.insert(neodym->atomzahl(), neodym);
    neodym->fuege_elektronen_hinzu(1, 2);
    neodym->fuege_elektronen_hinzu(2, 8);
    neodym->fuege_elektronen_hinzu(3, 18);
    neodym->fuege_elektronen_hinzu(4, 22);
    neodym->fuege_elektronen_hinzu(5, 8);
    neodym->fuege_elektronen_hinzu(6, 2);

    // promethium (gruppe 19, Lanthanoide)
    Element* promethium = new Element(this);
    promethium->setObjectName("promethium");
    promethium->setze_element_namen(tr("Promethium"));
    promethium->setze_atomzahl(61);
    promethium->setze_symbol("Pm");
    promethium->setze_masse("145 u");
    promethium->setze_exakte_masse("144.912756");
    promethium->setze_ionisation("540 kJ/mol");
    promethium->setze_elektronenaffinitaet("50 kJ/mol");
    promethium->setze_elektronen_negativitaet("1.13");
    promethium->setze_kovalenter("199 pm");
    promethium->setze_van_der_waals_radius("236 pm");
    promethium->setze_schmelzpunkt("1315");
    promethium->setze_siedepunkt("3273");
    promethium->setze_familie(tr("lanthanides"));
    promethium->setze_gruppenfarbe(gruppenfarben.at(19));
    promethium->setze_entdeckungsjahr(1945);
    promethium->setze_position(6, 8);
    elementliste.insert(promethium->atomzahl(), promethium);
    promethium->fuege_elektronen_hinzu(1, 2);
    promethium->fuege_elektronen_hinzu(2, 8);
    promethium->fuege_elektronen_hinzu(3, 18);
    promethium->fuege_elektronen_hinzu(4, 23);
    promethium->fuege_elektronen_hinzu(5, 8);
    promethium->fuege_elektronen_hinzu(6, 2);

    // samarium (gruppe 19, Lanthanoide)
    Element* samarium = new Element(this);
    samarium->setObjectName("samarium");
    samarium->setze_element_namen(tr("Samarium"));
    samarium->setze_atomzahl(62);
    samarium->setze_symbol("Sm");
    samarium->setze_masse("150.36 u");
    samarium->setze_exakte_masse("151.919739");
    samarium->setze_ionisation("544.5 kJ/mol");
    samarium->setze_elektronenaffinitaet("50 kJ/mol");
    samarium->setze_elektronen_negativitaet("1.17");
    samarium->setze_kovalenter("198 pm");
    samarium->setze_van_der_waals_radius("229 pm");
    samarium->setze_schmelzpunkt("1345");
    samarium->setze_siedepunkt("2067");
    samarium->setze_familie(tr("lanthanides"));
    samarium->setze_gruppenfarbe(gruppenfarben.at(19));
    samarium->setze_entdeckungsjahr(1879);
    samarium->setze_position(7, 8);
    elementliste.insert(samarium->atomzahl(), samarium);
    samarium->fuege_elektronen_hinzu(1, 2);
    samarium->fuege_elektronen_hinzu(2, 8);
    samarium->fuege_elektronen_hinzu(3, 18);
    samarium->fuege_elektronen_hinzu(4, 24);
    samarium->fuege_elektronen_hinzu(5, 8);
    samarium->fuege_elektronen_hinzu(6, 2);

    // europium (gruppe 19, Lanthanoide)
    Element* europium = new Element(this);
    europium->setObjectName("europium");
    europium->setze_element_namen(tr("Europium"));
    europium->setze_atomzahl(63);
    europium->setze_symbol("Eu");
    europium->setze_masse("151.964 u");
    europium->setze_exakte_masse("152.921238");
    europium->setze_ionisation("547.1 kJ/mol");
    europium->setze_elektronenaffinitaet("50 kJ/mol");
    europium->setze_elektronen_negativitaet("1.2");
    europium->setze_kovalenter("198 pm");
    europium->setze_van_der_waals_radius("233 pm");
    europium->setze_schmelzpunkt("1099");
    europium->setze_siedepunkt("1802");
    europium->setze_familie(tr("lanthanides"));
    europium->setze_gruppenfarbe(gruppenfarben.at(19));
    europium->setze_entdeckungsjahr(1901);
    europium->setze_position(8, 8);
    elementliste.insert(europium->atomzahl(), europium);
    europium->fuege_elektronen_hinzu(1, 2);
    europium->fuege_elektronen_hinzu(2, 8);
    europium->fuege_elektronen_hinzu(3, 18);
    europium->fuege_elektronen_hinzu(4, 25);
    europium->fuege_elektronen_hinzu(5, 8);
    europium->fuege_elektronen_hinzu(6, 2);

    // gadolinium (gruppe 19, Lanthanoide)
    Element* gadolinium = new Element(this);
    gadolinium->setObjectName("gadolinium");
    gadolinium->setze_element_namen(tr("Gadolinium"));
    gadolinium->setze_atomzahl(64);
    gadolinium->setze_symbol("Gd");
    gadolinium->setze_masse("157.25 u");
    gadolinium->setze_exakte_masse("157.924112");
    gadolinium->setze_ionisation("593.4 kJ/mol");
    gadolinium->setze_elektronenaffinitaet("50 kJ/mol");
    gadolinium->setze_elektronen_negativitaet("1.2");
    gadolinium->setze_kovalenter("196 pm");
    gadolinium->setze_van_der_waals_radius("237 pm");
    gadolinium->setze_schmelzpunkt("1585");
    gadolinium->setze_siedepunkt("3546");
    gadolinium->setze_familie(tr("lanthanides"));
    gadolinium->setze_gruppenfarbe(gruppenfarben.at(19));
    gadolinium->setze_entdeckungsjahr(1880);
    gadolinium->setze_position(9, 8);
    elementliste.insert(gadolinium->atomzahl(), gadolinium);
    gadolinium->fuege_elektronen_hinzu(1, 2);
    gadolinium->fuege_elektronen_hinzu(2, 8);
    gadolinium->fuege_elektronen_hinzu(3, 18);
    gadolinium->fuege_elektronen_hinzu(4, 25);
    gadolinium->fuege_elektronen_hinzu(5, 9);
    gadolinium->fuege_elektronen_hinzu(6, 2);

    // terbium (gruppe 19, Lanthanoide)
    Element* terbium = new Element(this);
    terbium->setObjectName("terbium");
    terbium->setze_element_namen(tr("Terbium"));
    terbium->setze_atomzahl(65);
    terbium->setze_symbol("Tb");
    terbium->setze_masse("158.925 u");
    terbium->setze_exakte_masse("158.925355");
    terbium->setze_ionisation("565.8 kJ/mol");
    terbium->setze_elektronenaffinitaet("50 kJ/mol");
    terbium->setze_elektronen_negativitaet("1.2");
    terbium->setze_kovalenter("194 pm");
    terbium->setze_van_der_waals_radius("221 pm");
    terbium->setze_schmelzpunkt("1629");
    terbium->setze_siedepunkt("3503");
    terbium->setze_familie(tr("lanthanides"));
    terbium->setze_gruppenfarbe(gruppenfarben.at(19));
    terbium->setze_entdeckungsjahr(1843);
    terbium->setze_position(10, 8);
    elementliste.insert(terbium->atomzahl(), terbium);
    terbium->fuege_elektronen_hinzu(1, 2);
    terbium->fuege_elektronen_hinzu(2, 8);
    terbium->fuege_elektronen_hinzu(3, 18);
    terbium->fuege_elektronen_hinzu(4, 27);
    terbium->fuege_elektronen_hinzu(5, 8);
    terbium->fuege_elektronen_hinzu(6, 2);

    // dysprosium (gruppe 19, Lanthanoide)
    Element* dysprosium = new Element(this);
    dysprosium->setObjectName("dysprosium");
    dysprosium->setze_element_namen(tr("Dysprosium"));
    dysprosium->setze_atomzahl(66);
    dysprosium->setze_symbol("Dy");
    dysprosium->setze_masse("162.5 u");
    dysprosium->setze_exakte_masse("163.929182");
    dysprosium->setze_ionisation("573 kJ/mol");
    dysprosium->setze_elektronenaffinitaet("50 kJ/mol");
    dysprosium->setze_elektronen_negativitaet("1.22");
    dysprosium->setze_kovalenter("192 pm");
    dysprosium->setze_van_der_waals_radius("229 pm");
    dysprosium->setze_schmelzpunkt("1680");
    dysprosium->setze_siedepunkt("2840");
    dysprosium->setze_familie(tr("lanthanides"));
    dysprosium->setze_gruppenfarbe(gruppenfarben.at(19));
    dysprosium->setze_entdeckungsjahr(1886);
    dysprosium->setze_position(11, 8);
    elementliste.insert(dysprosium->atomzahl(), dysprosium);
    dysprosium->fuege_elektronen_hinzu(1, 2);
    dysprosium->fuege_elektronen_hinzu(2, 8);
    dysprosium->fuege_elektronen_hinzu(3, 18);
    dysprosium->fuege_elektronen_hinzu(4, 28);
    dysprosium->fuege_elektronen_hinzu(5, 8);
    dysprosium->fuege_elektronen_hinzu(6, 2);

    // holmium (gruppe 19, Lanthanoide)
    Element* holmium = new Element(this);
    holmium->setObjectName("holmium");
    holmium->setze_element_namen(tr("Holmium"));
    holmium->setze_atomzahl(67);
    holmium->setze_symbol("Ho");
    holmium->setze_masse("164.93 u");
    holmium->setze_exakte_masse("164.930329");
    holmium->setze_ionisation("581 kJ/mol");
    holmium->setze_elektronenaffinitaet("50 kJ/mol");
    holmium->setze_elektronen_negativitaet("1.23");
    holmium->setze_kovalenter("192 pm");
    holmium->setze_van_der_waals_radius("216 pm");
    holmium->setze_schmelzpunkt("1734");
    holmium->setze_siedepunkt("2993");
    holmium->setze_familie(tr("lanthanides"));
    holmium->setze_gruppenfarbe(gruppenfarben.at(19));
    holmium->setze_entdeckungsjahr(1878);
    holmium->setze_position(12, 8);
    elementliste.insert(holmium->atomzahl(), holmium);
    holmium->fuege_elektronen_hinzu(1, 2);
    holmium->fuege_elektronen_hinzu(2, 8);
    holmium->fuege_elektronen_hinzu(3, 18);
    holmium->fuege_elektronen_hinzu(4, 29);
    holmium->fuege_elektronen_hinzu(5, 8);
    holmium->fuege_elektronen_hinzu(6, 2);

    // erbium (gruppe 19, Lanthanoide)
    Element* erbium = new Element(this);
    erbium->setObjectName("erbium");
    erbium->setze_element_namen(tr("Erbium"));
    erbium->setze_atomzahl(68);
    erbium->setze_symbol("Er");
    erbium->setze_masse("167.259 u");
    erbium->setze_exakte_masse("165.930301");
    erbium->setze_ionisation("589.3 kJ/mol");
    erbium->setze_elektronenaffinitaet("50 kJ/mol");
    erbium->setze_elektronen_negativitaet("1.24");
    erbium->setze_kovalenter("189 pm");
    erbium->setze_van_der_waals_radius("235 pm");
    erbium->setze_schmelzpunkt("1802");
    erbium->setze_siedepunkt("3141");
    erbium->setze_familie(tr("lanthanides"));
    erbium->setze_gruppenfarbe(gruppenfarben.at(19));
    erbium->setze_entdeckungsjahr(1842);
    erbium->setze_position(13, 8);
    elementliste.insert(erbium->atomzahl(), erbium);
    erbium->fuege_elektronen_hinzu(1, 2);
    erbium->fuege_elektronen_hinzu(2, 8);
    erbium->fuege_elektronen_hinzu(3, 18);
    erbium->fuege_elektronen_hinzu(4, 30);
    erbium->fuege_elektronen_hinzu(5, 8);
    erbium->fuege_elektronen_hinzu(6, 2);

    // thulium (gruppe 19, Lanthanoide)
    Element* thulium = new Element(this);
    thulium->setObjectName("thulium");
    thulium->setze_element_namen(tr("Thulium"));
    thulium->setze_atomzahl(69);
    thulium->setze_symbol("Tm");
    thulium->setze_masse("168.934 u");
    thulium->setze_exakte_masse("168.934219");
    thulium->setze_ionisation("596.7 kJ/mol");
    thulium->setze_elektronenaffinitaet("50 kJ/mol");
    thulium->setze_elektronen_negativitaet("1.25");
    thulium->setze_kovalenter("190 pm");
    thulium->setze_van_der_waals_radius("227 pm");
    thulium->setze_schmelzpunkt("1818");
    thulium->setze_siedepunkt("2223");
    thulium->setze_familie(tr("lanthanides"));
    thulium->setze_gruppenfarbe(gruppenfarben.at(19));
    thulium->setze_entdeckungsjahr(1879);
    thulium->setze_position(14, 8);
    elementliste.insert(thulium->atomzahl(), thulium);
    thulium->fuege_elektronen_hinzu(1, 2);
    thulium->fuege_elektronen_hinzu(2, 8);
    thulium->fuege_elektronen_hinzu(3, 18);
    thulium->fuege_elektronen_hinzu(4, 31);
    thulium->fuege_elektronen_hinzu(5, 8);
    thulium->fuege_elektronen_hinzu(6, 2);

    // ytterbium (gruppe 19, Lanthanoide)
    Element* ytterbium = new Element(this);
    ytterbium->setObjectName("ytterbium");
    ytterbium->setze_element_namen(tr("Ytterbium"));
    ytterbium->setze_atomzahl(70);
    ytterbium->setze_symbol("Yb");
    ytterbium->setze_masse("173.05 u");
    ytterbium->setze_exakte_masse("173.938868");
    ytterbium->setze_ionisation("603.4 kJ/mol");
    ytterbium->setze_elektronenaffinitaet("50 kJ/mol");
    ytterbium->setze_elektronen_negativitaet("1.1");
    ytterbium->setze_kovalenter("187 pm");
    ytterbium->setze_van_der_waals_radius("242 pm");
    ytterbium->setze_schmelzpunkt("1097");
    ytterbium->setze_siedepunkt("1469");
    ytterbium->setze_familie(tr("lanthanides"));
    ytterbium->setze_gruppenfarbe(gruppenfarben.at(19));
    ytterbium->setze_entdeckungsjahr(1878);
    ytterbium->setze_position(15, 8);
    elementliste.insert(ytterbium->atomzahl(), ytterbium);
    ytterbium->fuege_elektronen_hinzu(1, 2);
    ytterbium->fuege_elektronen_hinzu(2, 8);
    ytterbium->fuege_elektronen_hinzu(3, 18);
    ytterbium->fuege_elektronen_hinzu(4, 32);
    ytterbium->fuege_elektronen_hinzu(5, 8);
    ytterbium->fuege_elektronen_hinzu(6, 2);

    // lutetium (gruppe 19, Lanthanoide)
    Element* lutetium = new Element(this);
    lutetium->setObjectName("lutetium");
    lutetium->setze_element_namen(tr("Lutetium"));
    lutetium->setze_atomzahl(71);
    lutetium->setze_symbol("Lu");
    lutetium->setze_masse("174.967 u");
    lutetium->setze_exakte_masse("174.940777");
    lutetium->setze_ionisation("523.5 kJ/mol");
    lutetium->setze_elektronenaffinitaet("50 kJ/mol");
    lutetium->setze_elektronen_negativitaet("1.27");
    lutetium->setze_kovalenter("187 pm");
    lutetium->setze_van_der_waals_radius("221 pm");
    lutetium->setze_schmelzpunkt("1925");
    lutetium->setze_siedepunkt("3675");
    lutetium->setze_familie(tr("lanthanides"));
    lutetium->setze_gruppenfarbe(gruppenfarben.at(19));
    lutetium->setze_entdeckungsjahr(1907);
    lutetium->setze_position(16, 8);
    elementliste.insert(lutetium->atomzahl(), lutetium);
    lutetium->fuege_elektronen_hinzu(1, 2);
    lutetium->fuege_elektronen_hinzu(2, 8);
    lutetium->fuege_elektronen_hinzu(3, 18);
    lutetium->fuege_elektronen_hinzu(4, 32);
    lutetium->fuege_elektronen_hinzu(5, 9);
    lutetium->fuege_elektronen_hinzu(6, 2);

    // hafnium (gruppe 4, Übergangsmetalle)
    Element* hafnium = new Element(this);
    hafnium->setObjectName("hafnium");
    hafnium->setze_element_namen(tr("Hafnium"));
    hafnium->setze_atomzahl(72);
    hafnium->setze_symbol("Hf");
    hafnium->setze_masse("178.49 u");
    hafnium->setze_exakte_masse("179.946555");
    hafnium->setze_ionisation("658.5 kJ/mol");
    hafnium->setze_elektronenaffinitaet("0 kJ/mol");
    hafnium->setze_elektronen_negativitaet("1.3");
    hafnium->setze_kovalenter("175 pm");
    hafnium->setze_van_der_waals_radius("212 pm");
    hafnium->setze_schmelzpunkt("2506");
    hafnium->setze_siedepunkt("4876");
    hafnium->setze_familie(tr("transition metals"));
    hafnium->setze_gruppenfarbe(gruppenfarben.at(4));
    hafnium->setze_entdeckungsjahr(1923);
    hafnium->setze_position(3, 6);
    elementliste.insert(hafnium->atomzahl(), hafnium);
    hafnium->fuege_elektronen_hinzu(1, 2);
    hafnium->fuege_elektronen_hinzu(2, 8);
    hafnium->fuege_elektronen_hinzu(3, 18);
    hafnium->fuege_elektronen_hinzu(4, 32);
    hafnium->fuege_elektronen_hinzu(5, 10);
    hafnium->fuege_elektronen_hinzu(6, 2);

    // tantal (gruppe 5, Übergangsmetalle)
    Element* tantal = new Element(this);
    tantal->setObjectName("tantal");
    tantal->setze_element_namen(tr("Tantalum"));
    tantal->setze_atomzahl(73);
    tantal->setze_symbol("Ta");
    tantal->setze_masse("180.948 u");
    tantal->setze_exakte_masse("180.947995");
    tantal->setze_ionisation("761 kJ/mol");
    tantal->setze_elektronenaffinitaet("31 kJ/mol");
    tantal->setze_elektronen_negativitaet("1.5");
    tantal->setze_kovalenter("138 pm");
    tantal->setze_van_der_waals_radius("217 pm");
    tantal->setze_schmelzpunkt("3290");
    tantal->setze_siedepunkt("5731");
    tantal->setze_familie(tr("transition metals"));
    tantal->setze_gruppenfarbe(gruppenfarben.at(5));
    tantal->setze_entdeckungsjahr(1802);
    tantal->setze_position(4, 6);
    elementliste.insert(tantal->atomzahl(), tantal);
    tantal->fuege_elektronen_hinzu(1, 2);
    tantal->fuege_elektronen_hinzu(2, 8);
    tantal->fuege_elektronen_hinzu(3, 18);
    tantal->fuege_elektronen_hinzu(4, 32);
    tantal->fuege_elektronen_hinzu(5, 11);
    tantal->fuege_elektronen_hinzu(6, 2);

    // wolfram (gruppe 6, Übergangsmetalle)
    Element* wolfram = new Element(this);
    wolfram->setObjectName("wolfram");
    wolfram->setze_element_namen(tr("Tungsten"));
    wolfram->setze_atomzahl(74);
    wolfram->setze_symbol("W");
    wolfram->setze_masse("183.84 u");
    wolfram->setze_exakte_masse("183.950931");
    wolfram->setze_ionisation("770 kJ/mol");
    wolfram->setze_elektronenaffinitaet("78.6 kJ/mol");
    wolfram->setze_elektronen_negativitaet("2.36");
    wolfram->setze_kovalenter("162 pm");
    wolfram->setze_van_der_waals_radius("210 pm");
    wolfram->setze_schmelzpunkt("3695");
    wolfram->setze_siedepunkt("5828");
    wolfram->setze_familie(tr("transition metals"));
    wolfram->setze_gruppenfarbe(gruppenfarben.at(6));
    wolfram->setze_entdeckungsjahr(1783);
    wolfram->setze_position(5, 6);
    elementliste.insert(wolfram->atomzahl(), wolfram);
    wolfram->fuege_elektronen_hinzu(1, 2);
    wolfram->fuege_elektronen_hinzu(2, 8);
    wolfram->fuege_elektronen_hinzu(3, 18);
    wolfram->fuege_elektronen_hinzu(4, 32);
    wolfram->fuege_elektronen_hinzu(5, 12);
    wolfram->fuege_elektronen_hinzu(6, 2);

    // rhenium (gruppe 7, Übergangsmetalle)
    Element* rhenium = new Element(this);
    rhenium->setObjectName("rhenium");
    rhenium->setze_element_namen(tr("Rhenium"));
    rhenium->setze_atomzahl(75);
    rhenium->setze_symbol("Re");
    rhenium->setze_masse("186.207 u");
    rhenium->setze_exakte_masse("186.955750");
    rhenium->setze_ionisation("760 kJ/mol");
    rhenium->setze_elektronenaffinitaet("14.5 kJ/mol");
    rhenium->setze_elektronen_negativitaet("1.9");
    rhenium->setze_kovalenter("151 pm");
    rhenium->setze_van_der_waals_radius("217 pm");
    rhenium->setze_schmelzpunkt("3459");
    rhenium->setze_siedepunkt("5869");
    rhenium->setze_familie(tr("transition metals"));
    rhenium->setze_gruppenfarbe(gruppenfarben.at(7));
    rhenium->setze_entdeckungsjahr(1925);
    rhenium->setze_position(6, 6);
    elementliste.insert(rhenium->atomzahl(), rhenium);
    rhenium->fuege_elektronen_hinzu(1, 2);
    rhenium->fuege_elektronen_hinzu(2, 8);
    rhenium->fuege_elektronen_hinzu(3, 18);
    rhenium->fuege_elektronen_hinzu(4, 32);
    rhenium->fuege_elektronen_hinzu(5, 13);
    rhenium->fuege_elektronen_hinzu(6, 2);

    // osmium (gruppe 8, Übergangsmetalle)
    Element* osmium = new Element(this);
    osmium->setObjectName("osmium");
    osmium->setze_element_namen(tr("Osmium"));
    osmium->setze_atomzahl(76);
    osmium->setze_symbol("Os");
    osmium->setze_masse("190.23 u");
    osmium->setze_exakte_masse("191.961477");
    osmium->setze_ionisation("840 kJ/mol");
    osmium->setze_elektronenaffinitaet("106.1 kJ/mol");
    osmium->setze_elektronen_negativitaet("2.2");
    osmium->setze_kovalenter("144 pm");
    osmium->setze_van_der_waals_radius("216 pm");
    osmium->setze_schmelzpunkt("3306");
    osmium->setze_siedepunkt("5285");
    osmium->setze_familie(tr("transition metals"));
    osmium->setze_gruppenfarbe(gruppenfarben.at(8));
    osmium->setze_entdeckungsjahr(1803);
    osmium->setze_position(7, 6);
    elementliste.insert(osmium->atomzahl(), osmium);
    osmium->fuege_elektronen_hinzu(1, 2);
    osmium->fuege_elektronen_hinzu(2, 8);
    osmium->fuege_elektronen_hinzu(3, 18);
    osmium->fuege_elektronen_hinzu(4, 32);
    osmium->fuege_elektronen_hinzu(5, 14);
    osmium->fuege_elektronen_hinzu(6, 2);

    // iridium (gruppe 9, Übergangsmetalle)
    Element* iridium = new Element(this);
    iridium->setObjectName("iridium");
    iridium->setze_element_namen(tr("Iridium"));
    iridium->setze_atomzahl(77);
    iridium->setze_symbol("Ir");
    iridium->setze_masse("192.217 u");
    iridium->setze_exakte_masse("192.962922");
    iridium->setze_ionisation("880 kJ/mol");
    iridium->setze_elektronenaffinitaet("151 kJ/mol");
    iridium->setze_elektronen_negativitaet("2.2");
    iridium->setze_kovalenter("141 pm");
    iridium->setze_van_der_waals_radius("202 pm");
    iridium->setze_schmelzpunkt("2739");
    iridium->setze_siedepunkt("4701");
    iridium->setze_familie(tr("transition metals"));
    iridium->setze_gruppenfarbe(gruppenfarben.at(9));
    iridium->setze_entdeckungsjahr(1803);
    iridium->setze_position(8, 6);
    elementliste.insert(iridium->atomzahl(), iridium);
    iridium->fuege_elektronen_hinzu(1, 2);
    iridium->fuege_elektronen_hinzu(2, 8);
    iridium->fuege_elektronen_hinzu(3, 18);
    iridium->fuege_elektronen_hinzu(4, 32);
    iridium->fuege_elektronen_hinzu(5, 15);
    iridium->fuege_elektronen_hinzu(6, 2);

    // platin (gruppe 10, Übergangsmetalle)
    Element* platin = new Element(this);
    platin->setObjectName("platin");
    platin->setze_element_namen(tr("Platinum"));
    platin->setze_atomzahl(78);
    platin->setze_symbol("Pt");
    platin->setze_masse("195.084 u");
    platin->setze_exakte_masse("194.964792");
    platin->setze_ionisation("870 kJ/mol");
    platin->setze_elektronenaffinitaet("205.3 kJ/mol");
    platin->setze_elektronen_negativitaet("2.28");
    platin->setze_kovalenter("136 pm");
    platin->setze_van_der_waals_radius("209 pm");
    platin->setze_schmelzpunkt("2041.4");
    platin->setze_siedepunkt("4098");
    platin->setze_familie(tr("transition metals"));
    platin->setze_gruppenfarbe(gruppenfarben.at(10));
    platin->setze_entdeckungsjahr(1735);
    platin->setze_position(9, 6);
    elementliste.insert(platin->atomzahl(), platin);
    platin->fuege_elektronen_hinzu(1, 2);
    platin->fuege_elektronen_hinzu(2, 8);
    platin->fuege_elektronen_hinzu(3, 18);
    platin->fuege_elektronen_hinzu(4, 32);
    platin->fuege_elektronen_hinzu(5, 17);
    platin->fuege_elektronen_hinzu(6, 1);

    // gold (gruppe 11, Übergangsmetalle)
    Element* gold = new Element(this);
    gold->setObjectName("gold");
    gold->setze_element_namen(tr("Gold"));
    gold->setze_atomzahl(79);
    gold->setze_symbol("Au");
    gold->setze_masse("196.967 u");
    gold->setze_exakte_masse("196.966569");
    gold->setze_ionisation("890.1 kJ/mol");
    gold->setze_elektronenaffinitaet("222.8 kJ/mol");
    gold->setze_elektronen_negativitaet("2.54");
    gold->setze_kovalenter("136 pm");
    gold->setze_van_der_waals_radius("217 pm");
    gold->setze_schmelzpunkt("1337.3");
    gold->setze_siedepunkt("3129");
    gold->setze_familie(tr("transition metals"));
    gold->setze_gruppenfarbe(gruppenfarben.at(11));
    gold->setze_entdeckungsjahr(-5000);
    gold->setze_position(10, 6);
    elementliste.insert(gold->atomzahl(), gold);
    gold->fuege_elektronen_hinzu(1, 2);
    gold->fuege_elektronen_hinzu(2, 8);
    gold->fuege_elektronen_hinzu(3, 18);
    gold->fuege_elektronen_hinzu(4, 32);
    gold->fuege_elektronen_hinzu(5, 18);
    gold->fuege_elektronen_hinzu(6, 1);

    // quecksilber (gruppe 12, Übergangsmetalle)
    Element* quecksilber = new Element(this);
    quecksilber->setObjectName("quecksilber");
    quecksilber->setze_element_namen(tr("Mercury"));
    quecksilber->setze_atomzahl(80);
    quecksilber->setze_symbol("Hg");
    quecksilber->setze_masse("200.59 u");
    quecksilber->setze_exakte_masse("201.970643");
    quecksilber->setze_ionisation("1007.1 kJ/mol");
    quecksilber->setze_elektronenaffinitaet("0 kJ/mol");
    quecksilber->setze_elektronen_negativitaet("2");
    quecksilber->setze_kovalenter("132 pm");
    quecksilber->setze_van_der_waals_radius("209 pm");
    quecksilber->setze_schmelzpunkt("234.3");
    quecksilber->setze_siedepunkt("629.9");
    quecksilber->setze_familie(tr("transition metals"));
    quecksilber->setze_gruppenfarbe(gruppenfarben.at(12));
    quecksilber->setze_entdeckungsjahr(-1500);
    quecksilber->setze_position(11, 6);
    elementliste.insert(quecksilber->atomzahl(), quecksilber);
    quecksilber->fuege_elektronen_hinzu(1, 2);
    quecksilber->fuege_elektronen_hinzu(2, 8);
    quecksilber->fuege_elektronen_hinzu(3, 18);
    quecksilber->fuege_elektronen_hinzu(4, 32);
    quecksilber->fuege_elektronen_hinzu(5, 18);
    quecksilber->fuege_elektronen_hinzu(6, 2);

    // thallium (gruppe 13, Metalle)
    Element* thallium = new Element(this);
    thallium->setObjectName("thallium");
    thallium->setze_element_namen(tr("Thallium"));
    thallium->setze_atomzahl(81);
    thallium->setze_symbol("Tl");
    thallium->setze_masse("204.383 u");
    thallium->setze_exakte_masse("204.974427");
    thallium->setze_ionisation("589.4 kJ/mol");
    thallium->setze_elektronenaffinitaet("19.2 kJ/mol");
    thallium->setze_elektronen_negativitaet("1.62");
    thallium->setze_kovalenter("145 pm");
    thallium->setze_van_der_waals_radius("196 pm");
    thallium->setze_schmelzpunkt("577");
    thallium->setze_siedepunkt("1746");
    thallium->setze_familie(tr("metals"));
    thallium->setze_gruppenfarbe(gruppenfarben.at(13));
    thallium->setze_entdeckungsjahr(1861);
    thallium->setze_position(12, 6);
    elementliste.insert(thallium->atomzahl(), thallium);
    thallium->fuege_elektronen_hinzu(1, 2);
    thallium->fuege_elektronen_hinzu(2, 8);
    thallium->fuege_elektronen_hinzu(3, 18);
    thallium->fuege_elektronen_hinzu(4, 32);
    thallium->fuege_elektronen_hinzu(5, 18);
    thallium->fuege_elektronen_hinzu(6, 3);

    // blei (gruppe 14, Metalle)
    Element* blei = new Element(this);
    blei->setObjectName("blei");
    blei->setze_element_namen(tr("Lead"));
    blei->setze_atomzahl(82);
    blei->setze_symbol("Pb");
    blei->setze_masse("207.2 u");
    blei->setze_exakte_masse("207.976651");
    blei->setze_ionisation("715.6 kJ/mol");
    blei->setze_elektronenaffinitaet("35.1 kJ/mol");
    blei->setze_elektronen_negativitaet("2.33");
    blei->setze_kovalenter("146 pm");
    blei->setze_van_der_waals_radius("202 pm");
    blei->setze_schmelzpunkt("600.6");
    blei->setze_siedepunkt("2022");
    blei->setze_familie(tr("metals"));
    blei->setze_gruppenfarbe(gruppenfarben.at(14));
    blei->setze_entdeckungsjahr(-4000);
    blei->setze_position(13, 6);
    elementliste.insert(blei->atomzahl(), blei);
    blei->fuege_elektronen_hinzu(1, 2);
    blei->fuege_elektronen_hinzu(2, 8);
    blei->fuege_elektronen_hinzu(3, 18);
    blei->fuege_elektronen_hinzu(4, 32);
    blei->fuege_elektronen_hinzu(5, 18);
    blei->fuege_elektronen_hinzu(6, 4);

    // bismuth (gruppe 15, Metalle)
    Element* bismuth = new Element(this);
    bismuth->setObjectName("bismuth");
    bismuth->setze_element_namen(tr("Bismuth"));
    bismuth->setze_atomzahl(83);
    bismuth->setze_symbol("Bi");
    bismuth->setze_masse("208.98 u");
    bismuth->setze_exakte_masse("208.980398");
    bismuth->setze_ionisation("703 kJ/mol");
    bismuth->setze_elektronenaffinitaet("91.2 kJ/mol");
    bismuth->setze_elektronen_negativitaet("2.02");
    bismuth->setze_kovalenter("148 pm");
    bismuth->setze_van_der_waals_radius("207 pm");
    bismuth->setze_schmelzpunkt("544.7");
    bismuth->setze_siedepunkt("1837");
    bismuth->setze_familie(tr("metals"));
    bismuth->setze_gruppenfarbe(gruppenfarben.at(15));
    bismuth->setze_entdeckungsjahr(1450);
    bismuth->setze_position(14, 6);
    elementliste.insert(bismuth->atomzahl(), bismuth);
    bismuth->fuege_elektronen_hinzu(1, 2);
    bismuth->fuege_elektronen_hinzu(2, 8);
    bismuth->fuege_elektronen_hinzu(3, 18);
    bismuth->fuege_elektronen_hinzu(4, 32);
    bismuth->fuege_elektronen_hinzu(5, 18);
    bismuth->fuege_elektronen_hinzu(6, 5);

    // polonium (gruppe 16, Metalle)
    Element* polonium = new Element(this);
    polonium->setObjectName("polonium");
    polonium->setze_element_namen(tr("Polonium"));
    polonium->setze_atomzahl(84);
    polonium->setze_symbol("Po");
    polonium->setze_masse("209 u"); //certain
    polonium->setze_exakte_masse("208.982430");
    polonium->setze_ionisation("812.1 kJ/mol");
    polonium->setze_elektronenaffinitaet("183.3 kJ/mol");
    polonium->setze_elektronen_negativitaet("2");
    polonium->setze_kovalenter("140 pm");
    polonium->setze_van_der_waals_radius("197 pm");
    polonium->setze_schmelzpunkt("527");
    polonium->setze_siedepunkt("1235");
    polonium->setze_familie(tr("metals"));
    polonium->setze_gruppenfarbe(gruppenfarben.at(16));
    polonium->setze_entdeckungsjahr(1898);
    polonium->setze_position(15, 6);
    elementliste.insert(polonium->atomzahl(), polonium);
    polonium->fuege_elektronen_hinzu(1, 2);
    polonium->fuege_elektronen_hinzu(2, 8);
    polonium->fuege_elektronen_hinzu(3, 18);
    polonium->fuege_elektronen_hinzu(4, 32);
    polonium->fuege_elektronen_hinzu(5, 18);
    polonium->fuege_elektronen_hinzu(6, 6);

    // astat (gruppe 17, Halogene)
    Element* astat = new Element(this);
    astat->setObjectName("astat");
    astat->setze_element_namen(tr("Astatine"));
    astat->setze_atomzahl(85);
    astat->setze_symbol("At");
    astat->setze_masse("210 u"); //certain
    astat->setze_exakte_masse("209.987147");
    astat->setze_ionisation("890 kJ/mol");
    astat->setze_elektronenaffinitaet("270.1 kJ/mol");
    astat->setze_elektronen_negativitaet("2.2");
    astat->setze_kovalenter("150 pm");
    astat->setze_van_der_waals_radius("202 pm");
    astat->setze_schmelzpunkt("575");
    astat->setze_siedepunkt("610");
    astat->setze_familie(tr("halogens"));
    astat->setze_gruppenfarbe(gruppenfarben.at(17));
    astat->setze_entdeckungsjahr(1940);
    astat->setze_position(16, 6);
    elementliste.insert(astat->atomzahl(), astat);
    astat->fuege_elektronen_hinzu(1, 2);
    astat->fuege_elektronen_hinzu(2, 8);
    astat->fuege_elektronen_hinzu(3, 18);
    astat->fuege_elektronen_hinzu(4, 32);
    astat->fuege_elektronen_hinzu(5, 18);
    astat->fuege_elektronen_hinzu(6, 7);

    // radon (gruppe 18, Edelgase)
    Element* radon = new Element(this);
    radon->setObjectName("radon");
    radon->setze_element_namen(tr("Radon"));
    radon->setze_atomzahl(86);
    radon->setze_symbol("Rn");
    radon->setze_masse("222 u"); //certain
    radon->setze_exakte_masse("222.022160");
    radon->setze_ionisation("1037 kJ/mol");
    radon->setze_elektronenaffinitaet("0 kJ/mol");
    radon->setze_elektronen_negativitaet("2.2");
    radon->setze_kovalenter("150 pm");
    radon->setze_van_der_waals_radius("220 pm");
    radon->setze_schmelzpunkt("202");
    radon->setze_siedepunkt("211.3");
    radon->setze_familie(tr("noble gases"));
    radon->setze_gruppenfarbe(gruppenfarben.at(18));
    radon->setze_entdeckungsjahr(1900);
    radon->setze_position(17, 6);
    elementliste.insert(radon->atomzahl(), radon);
    radon->fuege_elektronen_hinzu(1, 2);
    radon->fuege_elektronen_hinzu(2, 8);
    radon->fuege_elektronen_hinzu(3, 18);
    radon->fuege_elektronen_hinzu(4, 32);
    radon->fuege_elektronen_hinzu(5, 18);
    radon->fuege_elektronen_hinzu(6, 8);

    // francium (gruppe 1, Alkalimetalle)
    Element* francium = new Element(this);
    francium->setObjectName("francium");
    francium->setze_element_namen(tr("Francium"));
    francium->setze_atomzahl(87);
    francium->setze_symbol("Fr");
    francium->setze_masse("223 u"); //certain
    francium->setze_exakte_masse("223.019736");
    francium->setze_ionisation("393 kJ/mol");
    francium->setze_elektronenaffinitaet("46.9 kJ/mol");
    francium->setze_elektronen_negativitaet("0.7");
    francium->setze_kovalenter("260 pm");
    francium->setze_van_der_waals_radius("348 pm");
    francium->setze_schmelzpunkt("300.1");
    francium->setze_siedepunkt("946.2");
    francium->setze_familie(tr("alkali metals"));
    francium->setze_gruppenfarbe(gruppenfarben.at(1));
    francium->setze_entdeckungsjahr(1939);
    francium->setze_position(0, 7);
    elementliste.insert(francium->atomzahl(), francium);
    francium->fuege_elektronen_hinzu(1, 2);
    francium->fuege_elektronen_hinzu(2, 8);
    francium->fuege_elektronen_hinzu(3, 18);
    francium->fuege_elektronen_hinzu(4, 32);
    francium->fuege_elektronen_hinzu(5, 18);
    francium->fuege_elektronen_hinzu(6, 8);
    francium->fuege_elektronen_hinzu(7, 1);

    // radium (gruppe 2, Erdalkalimetalle)
    Element* radium = new Element(this);
    radium->setObjectName("radium");
    radium->setze_element_namen(tr("Radium"));
    radium->setze_atomzahl(88);
    radium->setze_symbol("Ra");
    radium->setze_masse("226 u"); //certain
    radium->setze_exakte_masse("226.025409");
    radium->setze_ionisation("509.3 kJ/mol");
    radium->setze_elektronenaffinitaet("9.65 kJ/mol");
    radium->setze_elektronen_negativitaet("0.9");
    radium->setze_kovalenter("221 pm");
    radium->setze_van_der_waals_radius("283 pm");
    radium->setze_schmelzpunkt("973");
    radium->setze_siedepunkt("1413");
    radium->setze_familie(tr("alkaline earth metals"));
    radium->setze_gruppenfarbe(gruppenfarben.at(2));
    radium->setze_entdeckungsjahr(1898);
    radium->setze_position(1, 7);
    elementliste.insert(radium->atomzahl(), radium);
    radium->fuege_elektronen_hinzu(1, 2);
    radium->fuege_elektronen_hinzu(2, 8);
    radium->fuege_elektronen_hinzu(3, 18);
    radium->fuege_elektronen_hinzu(4, 32);
    radium->fuege_elektronen_hinzu(5, 18);
    radium->fuege_elektronen_hinzu(6, 8);
    radium->fuege_elektronen_hinzu(7, 2);

    // actinium (gruppe 20, Actinoide)
    Element* actinium = new Element(this);
    actinium->setObjectName("actinium");
    actinium->setze_element_namen(tr("Actinium"));
    actinium->setze_atomzahl(89);
    actinium->setze_symbol("Ac");
    actinium->setze_masse("227 u"); //certain
    actinium->setze_exakte_masse("227.027752");
    actinium->setze_ionisation("499 kJ/mol");
    actinium->setze_elektronenaffinitaet("33.77 kJ/mol");
    actinium->setze_elektronen_negativitaet("1.1");
    actinium->setze_kovalenter("215 pm");
    actinium->setze_van_der_waals_radius("260 pm");
    actinium->setze_schmelzpunkt("1323");
    actinium->setze_siedepunkt("3471");
    actinium->setze_familie(tr("actinides"));
    actinium->setze_gruppenfarbe(gruppenfarben.at(20));
    actinium->setze_entdeckungsjahr(1899);
    actinium->setze_position(2, 9);
    elementliste.insert(actinium->atomzahl(), actinium);
    actinium->fuege_elektronen_hinzu(1, 2);
    actinium->fuege_elektronen_hinzu(2, 8);
    actinium->fuege_elektronen_hinzu(3, 18);
    actinium->fuege_elektronen_hinzu(4, 32);
    actinium->fuege_elektronen_hinzu(5, 18);
    actinium->fuege_elektronen_hinzu(6, 9);
    actinium->fuege_elektronen_hinzu(7, 2);

    // thorium (gruppe 20, Actinoide)
    Element* thorium = new Element(this);
    thorium->setObjectName("thorium");
    thorium->setze_element_namen(tr("Thorium"));
    thorium->setze_atomzahl(90);
    thorium->setze_symbol("Th");
    thorium->setze_masse("232.038 u");
    thorium->setze_exakte_masse("232.038060");
    thorium->setze_ionisation("608.5 kJ/mol");
    thorium->setze_elektronenaffinitaet("-1");
    thorium->setze_elektronen_negativitaet("1.3");
    thorium->setze_kovalenter("206 pm");
    thorium->setze_van_der_waals_radius("237 pm");
    thorium->setze_schmelzpunkt("2020");
    thorium->setze_siedepunkt("5061");
    thorium->setze_familie(tr("actinides"));
    thorium->setze_gruppenfarbe(gruppenfarben.at(20));
    thorium->setze_entdeckungsjahr(1829);
    thorium->setze_position(3, 9);
    elementliste.insert(thorium->atomzahl(), thorium);
    thorium->fuege_elektronen_hinzu(1, 2);
    thorium->fuege_elektronen_hinzu(2, 8);
    thorium->fuege_elektronen_hinzu(3, 18);
    thorium->fuege_elektronen_hinzu(4, 32);
    thorium->fuege_elektronen_hinzu(5, 18);
    thorium->fuege_elektronen_hinzu(6, 10);
    thorium->fuege_elektronen_hinzu(7, 2);

    // protactinium (gruppe 20, Actinoide)
    Element* protactinium = new Element(this);
    protactinium->setObjectName("protactinium");
    protactinium->setze_element_namen(tr("Protactinium"));
    protactinium->setze_atomzahl(91);
    protactinium->setze_symbol("Pa");
    protactinium->setze_masse("231.036 u");
    protactinium->setze_exakte_masse("231.035884");
    protactinium->setze_ionisation("568 kJ/mol");
    protactinium->setze_elektronenaffinitaet("-1");
    protactinium->setze_elektronen_negativitaet("1.5");
    protactinium->setze_kovalenter("200 pm");
    protactinium->setze_van_der_waals_radius("243 pm");
    protactinium->setze_schmelzpunkt("1843");
    protactinium->setze_siedepunkt("4300");
    protactinium->setze_familie(tr("actinides"));
    protactinium->setze_gruppenfarbe(gruppenfarben.at(20));
    protactinium->setze_entdeckungsjahr(1913);
    protactinium->setze_position(4, 9);
    elementliste.insert(protactinium->atomzahl(), protactinium);
    protactinium->fuege_elektronen_hinzu(1, 2);
    protactinium->fuege_elektronen_hinzu(2, 8);
    protactinium->fuege_elektronen_hinzu(3, 18);
    protactinium->fuege_elektronen_hinzu(4, 32);
    protactinium->fuege_elektronen_hinzu(5, 20);
    protactinium->fuege_elektronen_hinzu(6, 9);
    protactinium->fuege_elektronen_hinzu(7, 2);

    // uran (gruppe 20, Actinoide)
    Element* uran = new Element(this);
    uran->setObjectName("uran");
    uran->setze_element_namen(tr("Uranium"));
    uran->setze_atomzahl(92);
    uran->setze_symbol("U");
    uran->setze_masse("238.029 u");
    uran->setze_exakte_masse("238.050789");
    uran->setze_ionisation("597.6 kJ/mol");
    uran->setze_elektronenaffinitaet("-1");
    uran->setze_elektronen_negativitaet("1.38");
    uran->setze_kovalenter("196 pm");
    uran->setze_van_der_waals_radius("240 pm");
    uran->setze_schmelzpunkt("1405.3");
    uran->setze_siedepunkt("4404");
    uran->setze_familie(tr("actinides"));
    uran->setze_gruppenfarbe(gruppenfarben.at(20));
    uran->setze_entdeckungsjahr(1789);
    uran->setze_position(5, 9);
    elementliste.insert(uran->atomzahl(), uran);
    uran->fuege_elektronen_hinzu(1, 2);
    uran->fuege_elektronen_hinzu(2, 8);
    uran->fuege_elektronen_hinzu(3, 18);
    uran->fuege_elektronen_hinzu(4, 32);
    uran->fuege_elektronen_hinzu(5, 21);
    uran->fuege_elektronen_hinzu(6, 9);
    uran->fuege_elektronen_hinzu(7, 2);

    // neptunium (gruppe 20, Actinoide)
    Element* neptunium = new Element(this);
    neptunium->setObjectName("neptunium");
    neptunium->setze_element_namen(tr("Neptunium"));
    neptunium->setze_atomzahl(93);
    neptunium->setze_symbol("Np");
    neptunium->setze_masse("237 u"); //certain
    neptunium->setze_exakte_masse("237.048175");
    neptunium->setze_ionisation("604.5 kJ/mol");
    neptunium->setze_elektronenaffinitaet("-1");
    neptunium->setze_elektronen_negativitaet("1.36");
    neptunium->setze_kovalenter("190 pm");
    neptunium->setze_van_der_waals_radius("221 pm");
    neptunium->setze_schmelzpunkt("910");
    neptunium->setze_siedepunkt("4175");
    neptunium->setze_familie(tr("actinides"));
    neptunium->setze_gruppenfarbe(gruppenfarben.at(20));
    neptunium->setze_entdeckungsjahr(1940);
    neptunium->setze_position(6, 9);
    elementliste.insert(neptunium->atomzahl(), neptunium);
    neptunium->fuege_elektronen_hinzu(1, 2);
    neptunium->fuege_elektronen_hinzu(2, 8);
    neptunium->fuege_elektronen_hinzu(3, 18);
    neptunium->fuege_elektronen_hinzu(4, 32);
    neptunium->fuege_elektronen_hinzu(5, 22);
    neptunium->fuege_elektronen_hinzu(6, 9);
    neptunium->fuege_elektronen_hinzu(7, 2);

    // plutonium (gruppe 20, Actinoide)
    Element* plutonium = new Element(this);
    plutonium->setObjectName("plutonium");
    plutonium->setze_element_namen(tr("Plutonium"));
    plutonium->setze_atomzahl(94);
    plutonium->setze_symbol("Pu");
    plutonium->setze_masse("244 u"); //certain
    plutonium->setze_exakte_masse("244.064205");
    plutonium->setze_ionisation("581.4 kJ/mol");
    plutonium->setze_elektronenaffinitaet("-1");
    plutonium->setze_elektronen_negativitaet("1.28");
    plutonium->setze_kovalenter("187 pm");
    plutonium->setze_van_der_waals_radius("243 pm");
    plutonium->setze_schmelzpunkt("912.5");
    plutonium->setze_siedepunkt("3501");
    plutonium->setze_familie(tr("actinides"));
    plutonium->setze_gruppenfarbe(gruppenfarben.at(20));
    plutonium->setze_entdeckungsjahr(1940);
    plutonium->setze_position(7, 9);
    elementliste.insert(plutonium->atomzahl(), plutonium);
    plutonium->fuege_elektronen_hinzu(1, 2);
    plutonium->fuege_elektronen_hinzu(2, 8);
    plutonium->fuege_elektronen_hinzu(3, 18);
    plutonium->fuege_elektronen_hinzu(4, 32);
    plutonium->fuege_elektronen_hinzu(5, 24);
    plutonium->fuege_elektronen_hinzu(6, 8);
    plutonium->fuege_elektronen_hinzu(7, 2);

    // americium (gruppe 20, Actinoide)
    Element* americium = new Element(this);
    americium->setObjectName("americium");
    americium->setze_element_namen(tr("Americium"));
    americium->setze_atomzahl(95);
    americium->setze_symbol("Am");
    americium->setze_masse("243 u"); //certain
    americium->setze_exakte_masse("243.061383");
    americium->setze_ionisation("576.3 kJ/mol");
    americium->setze_elektronenaffinitaet("-1");
    americium->setze_elektronen_negativitaet("1.3");
    americium->setze_kovalenter("180 pm");
    americium->setze_van_der_waals_radius("244 pm");
    americium->setze_schmelzpunkt("1449");
    americium->setze_siedepunkt("2880");
    americium->setze_familie(tr("actinides"));
    americium->setze_gruppenfarbe(gruppenfarben.at(20));
    americium->setze_entdeckungsjahr(1944);
    americium->setze_position(8, 9);
    elementliste.insert(americium->atomzahl(), americium);
    americium->fuege_elektronen_hinzu(1, 2);
    americium->fuege_elektronen_hinzu(2, 8);
    americium->fuege_elektronen_hinzu(3, 18);
    americium->fuege_elektronen_hinzu(4, 32);
    americium->fuege_elektronen_hinzu(5, 25);
    americium->fuege_elektronen_hinzu(6, 8);
    americium->fuege_elektronen_hinzu(7, 2);

    // curium (gruppe 20, Actinoide)
    Element* curium = new Element(this);
    curium->setObjectName("curium");
    curium->setze_element_namen(tr("Curium"));
    curium->setze_atomzahl(96);
    curium->setze_symbol("Cm");
    curium->setze_masse("247 u"); //certain
    curium->setze_exakte_masse("247.070355");
    curium->setze_ionisation("578 kJ/mol");
    curium->setze_elektronenaffinitaet("-1");
    curium->setze_elektronen_negativitaet("1.3");
    curium->setze_kovalenter("169 pm");
    curium->setze_van_der_waals_radius("245 pm");
    curium->setze_schmelzpunkt("1618");
    curium->setze_siedepunkt("3383");
    curium->setze_familie(tr("actinides"));
    curium->setze_gruppenfarbe(gruppenfarben.at(20));
    curium->setze_entdeckungsjahr(1944);
    curium->setze_position(9, 9);
    elementliste.insert(curium->atomzahl(), curium);
    curium->fuege_elektronen_hinzu(1, 2);
    curium->fuege_elektronen_hinzu(2, 8);
    curium->fuege_elektronen_hinzu(3, 18);
    curium->fuege_elektronen_hinzu(4, 32);
    curium->fuege_elektronen_hinzu(5, 25);
    curium->fuege_elektronen_hinzu(6, 9);
    curium->fuege_elektronen_hinzu(7, 2);

    // berkelium (gruppe 20, Actinoide)
    Element* berkelium = new Element(this);
    berkelium->setObjectName("berkelium");
    berkelium->setze_element_namen(tr("Berkelium"));
    berkelium->setze_atomzahl(97);
    berkelium->setze_symbol("Bk");
    berkelium->setze_masse("247 u"); //certain
    berkelium->setze_exakte_masse("247.070309");
    berkelium->setze_ionisation("598 kJ/mol");
    berkelium->setze_elektronenaffinitaet("-1");
    berkelium->setze_elektronen_negativitaet("1.3");
    berkelium->setze_kovalenter("-1"); //uncertain data
    berkelium->setze_van_der_waals_radius("244 pm");
    berkelium->setze_schmelzpunkt("1323");
    berkelium->setze_siedepunkt("3173");
    berkelium->setze_familie(tr("actinides"));
    berkelium->setze_gruppenfarbe(gruppenfarben.at(20));
    berkelium->setze_entdeckungsjahr(1949);
    berkelium->setze_position(10, 9);
    elementliste.insert(berkelium->atomzahl(), berkelium);
    berkelium->fuege_elektronen_hinzu(1, 2);
    berkelium->fuege_elektronen_hinzu(2, 8);
    berkelium->fuege_elektronen_hinzu(3, 18);
    berkelium->fuege_elektronen_hinzu(4, 32);
    berkelium->fuege_elektronen_hinzu(5, 27);
    berkelium->fuege_elektronen_hinzu(6, 8);
    berkelium->fuege_elektronen_hinzu(7, 2);

    // californium (gruppe 20, Actinoide)
    Element* californium = new Element(this);
    californium->setObjectName("californium");
    californium->setze_element_namen(tr("Californium"));
    californium->setze_atomzahl(98);
    californium->setze_symbol("Cf");
    californium->setze_masse("251 u"); //certain
    californium->setze_exakte_masse("251.079589");
    californium->setze_ionisation("606 kJ/mol");
    californium->setze_elektronenaffinitaet("-1");
    californium->setze_elektronen_negativitaet("1.3");
    californium->setze_kovalenter("-1");
    californium->setze_van_der_waals_radius("245 pm");
    californium->setze_schmelzpunkt("1173");
    californium->setze_siedepunkt("1745");
    californium->setze_familie(tr("actinides"));
    californium->setze_gruppenfarbe(gruppenfarben.at(20));
    californium->setze_entdeckungsjahr(1950);
    californium->setze_position(11, 9);
    elementliste.insert(californium->atomzahl(), californium);
    californium->fuege_elektronen_hinzu(1, 2);
    californium->fuege_elektronen_hinzu(2, 8);
    californium->fuege_elektronen_hinzu(3, 18);
    californium->fuege_elektronen_hinzu(4, 32);
    californium->fuege_elektronen_hinzu(5, 28);
    californium->fuege_elektronen_hinzu(6, 8);
    californium->fuege_elektronen_hinzu(7, 2);

    // einsteinium (gruppe 20, Actinoide)
    Element* einsteinium = new Element(this);
    einsteinium->setObjectName("einsteinium");
    einsteinium->setze_element_namen(tr("Einsteinium"));
    einsteinium->setze_atomzahl(99);
    einsteinium->setze_symbol("Es");
    einsteinium->setze_masse("252 u"); //certain
    einsteinium->setze_exakte_masse("252.082980");
    einsteinium->setze_ionisation("619.7 kJ/mol");
    einsteinium->setze_elektronenaffinitaet("-1");
    einsteinium->setze_elektronen_negativitaet("1.3");
    einsteinium->setze_kovalenter("-1");
    einsteinium->setze_van_der_waals_radius("245 pm");
    einsteinium->setze_schmelzpunkt("1133");
    einsteinium->setze_siedepunkt(QString::number(INT_MAX));
    einsteinium->setze_familie(tr("actinides"));
    einsteinium->setze_gruppenfarbe(gruppenfarben.at(20));
    einsteinium->setze_entdeckungsjahr(1952);
    einsteinium->setze_position(12, 9);
    elementliste.insert(einsteinium->atomzahl(), einsteinium);
    einsteinium->fuege_elektronen_hinzu(1, 2);
    einsteinium->fuege_elektronen_hinzu(2, 8);
    einsteinium->fuege_elektronen_hinzu(3, 18);
    einsteinium->fuege_elektronen_hinzu(4, 32);
    einsteinium->fuege_elektronen_hinzu(5, 29);
    einsteinium->fuege_elektronen_hinzu(6, 8);
    einsteinium->fuege_elektronen_hinzu(7, 2);

    // fermium (gruppe 20, Actinoide)
    Element* fermium = new Element(this);
    fermium->setObjectName("fermium");
    fermium->setze_element_namen(tr("Fermium"));
    fermium->setze_atomzahl(100);
    fermium->setze_symbol("Fm");
    fermium->setze_masse("257 u"); //certain
    fermium->setze_exakte_masse("257.095106");
    fermium->setze_ionisation("627 kJ/mol");
    fermium->setze_elektronenaffinitaet("-1");
    fermium->setze_elektronen_negativitaet("1.3");
    fermium->setze_kovalenter("-1");
    fermium->setze_van_der_waals_radius("245 pm");
    fermium->setze_schmelzpunkt("1800");
    fermium->setze_siedepunkt(QString::number(INT_MAX));
    fermium->setze_familie(tr("actinides"));
    fermium->setze_gruppenfarbe(gruppenfarben.at(20));
    fermium->setze_entdeckungsjahr(1952);
    fermium->setze_position(13, 9);
    elementliste.insert(fermium->atomzahl(), fermium);
    fermium->fuege_elektronen_hinzu(1, 2);
    fermium->fuege_elektronen_hinzu(2, 8);
    fermium->fuege_elektronen_hinzu(3, 18);
    fermium->fuege_elektronen_hinzu(4, 32);
    fermium->fuege_elektronen_hinzu(5, 30);
    fermium->fuege_elektronen_hinzu(6, 8);
    fermium->fuege_elektronen_hinzu(7, 2);

    // mendelevium (gruppe 20, Actinoide)
    Element* mendelevium = new Element(this);
    mendelevium->setObjectName("mendelevium");
    mendelevium->setze_element_namen(tr("Mendelevium"));
    mendelevium->setze_atomzahl(101);
    mendelevium->setze_symbol("Md");
    mendelevium->setze_masse("258 u"); //certain
    mendelevium->setze_exakte_masse("258.098433");
    mendelevium->setze_ionisation("635 kJ/mol");
    mendelevium->setze_elektronenaffinitaet("-1");
    mendelevium->setze_elektronen_negativitaet("1.3");
    mendelevium->setze_kovalenter("-1");
    mendelevium->setze_van_der_waals_radius("246 pm");
    mendelevium->setze_schmelzpunkt("1100");
    mendelevium->setze_siedepunkt(QString::number(INT_MAX));
    mendelevium->setze_familie(tr("actinides"));
    mendelevium->setze_gruppenfarbe(gruppenfarben.at(20));
    mendelevium->setze_entdeckungsjahr(1955);
    mendelevium->setze_position(14, 9);
    elementliste.insert(mendelevium->atomzahl(), mendelevium);
    mendelevium->fuege_elektronen_hinzu(1, 2);
    mendelevium->fuege_elektronen_hinzu(2, 8);
    mendelevium->fuege_elektronen_hinzu(3, 18);
    mendelevium->fuege_elektronen_hinzu(4, 32);
    mendelevium->fuege_elektronen_hinzu(5, 31);
    mendelevium->fuege_elektronen_hinzu(6, 8);
    mendelevium->fuege_elektronen_hinzu(7, 2);

    // nobelium (gruppe 20, Actinoide)
    Element* nobelium = new Element(this);
    nobelium->setObjectName("nobelium");
    nobelium->setze_element_namen(tr("Nobelium"));
    nobelium->setze_atomzahl(102);
    nobelium->setze_symbol("No");
    nobelium->setze_masse("261 u"); //certain?
    nobelium->setze_exakte_masse("261.105750");
    nobelium->setze_ionisation("641.6 kJ/mol");
    nobelium->setze_elektronenaffinitaet("-1");
    nobelium->setze_elektronen_negativitaet("1.3");
    nobelium->setze_kovalenter("-1");
    nobelium->setze_van_der_waals_radius("246 pm");
    nobelium->setze_schmelzpunkt("1100");
    nobelium->setze_siedepunkt(QString::number(INT_MAX));
    nobelium->setze_familie(tr("actinides"));
    nobelium->setze_gruppenfarbe(gruppenfarben.at(20));
    nobelium->setze_entdeckungsjahr(1958);
    nobelium->setze_position(15, 9);
    elementliste.insert(nobelium->atomzahl(), nobelium);
    nobelium->fuege_elektronen_hinzu(1, 2);
    nobelium->fuege_elektronen_hinzu(2, 8);
    nobelium->fuege_elektronen_hinzu(3, 18);
    nobelium->fuege_elektronen_hinzu(4, 32);
    nobelium->fuege_elektronen_hinzu(5, 32);
    nobelium->fuege_elektronen_hinzu(6, 8);
    nobelium->fuege_elektronen_hinzu(7, 2);

    // lawrencium (gruppe 20, Actinoide)
    Element* lawrencium = new Element(this);
    lawrencium->setObjectName("lawrencium");
    lawrencium->setze_element_namen(tr("Lawrencium"));
    lawrencium->setze_atomzahl(103);
    lawrencium->setze_symbol("Lr");
    lawrencium->setze_masse("263 u"); //certain?
    lawrencium->setze_exakte_masse("263.111296");
    lawrencium->setze_ionisation("472.8 kJ/mol");
    lawrencium->setze_elektronenaffinitaet("-1");
    lawrencium->setze_elektronen_negativitaet("1.3");
    lawrencium->setze_kovalenter("-1");
    lawrencium->setze_van_der_waals_radius("246 pm");
    lawrencium->setze_schmelzpunkt("1900");
    lawrencium->setze_siedepunkt(QString::number(INT_MAX));
    lawrencium->setze_familie(tr("actinides"));
    lawrencium->setze_gruppenfarbe(gruppenfarben.at(20));
    lawrencium->setze_entdeckungsjahr(1961);
    lawrencium->setze_position(16, 9);
    elementliste.insert(lawrencium->atomzahl(), lawrencium);
    lawrencium->fuege_elektronen_hinzu(1, 2);
    lawrencium->fuege_elektronen_hinzu(2, 8);
    lawrencium->fuege_elektronen_hinzu(3, 18);
    lawrencium->fuege_elektronen_hinzu(4, 32);
    lawrencium->fuege_elektronen_hinzu(5, 32);
    lawrencium->fuege_elektronen_hinzu(6, 9);
    lawrencium->fuege_elektronen_hinzu(7, 2);

    // rutherfordium (gruppe 4, Übergangsmetalle)
    Element* rutherfordium = new Element(this);
    rutherfordium->setObjectName("rutherfordium");
    rutherfordium->setze_element_namen(tr("Rutherfordium"));
    rutherfordium->setze_atomzahl(104);
    rutherfordium->setze_symbol("Rf");
    rutherfordium->setze_masse("265 u"); //uncertain
    rutherfordium->setze_exakte_masse("265.116834");
    rutherfordium->setze_ionisation("492 kJ/mol");
    rutherfordium->setze_elektronenaffinitaet("-1");
    rutherfordium->setze_elektronen_negativitaet("-1");
    rutherfordium->setze_kovalenter("-1");
    rutherfordium->setze_van_der_waals_radius("-1");
    rutherfordium->setze_schmelzpunkt("2400");
    rutherfordium->setze_siedepunkt("5800");
    rutherfordium->setze_familie(tr("transition metals"));
    rutherfordium->setze_gruppenfarbe(gruppenfarben.at(4));
    rutherfordium->setze_entdeckungsjahr(1964);
    rutherfordium->setze_position(3, 7);
    elementliste.insert(rutherfordium->atomzahl(), rutherfordium);
    rutherfordium->fuege_elektronen_hinzu(1, 2);
    rutherfordium->fuege_elektronen_hinzu(2, 8);
    rutherfordium->fuege_elektronen_hinzu(3, 18);
    rutherfordium->fuege_elektronen_hinzu(4, 32);
    rutherfordium->fuege_elektronen_hinzu(5, 32);
    rutherfordium->fuege_elektronen_hinzu(6, 10);
    rutherfordium->fuege_elektronen_hinzu(7, 2);

    // dubnium (gruppe 5, Übergangsmetalle)
    Element* dubnium = new Element(this);
    dubnium->setObjectName("dubnium");
    dubnium->setze_element_namen(tr("Dubnium"));
    dubnium->setze_atomzahl(105);
    dubnium->setze_symbol("Db");
    dubnium->setze_masse("265 u"); //uncertain
    dubnium->setze_exakte_masse("265.118602");
    dubnium->setze_ionisation("637 kJ/mol");
    dubnium->setze_elektronenaffinitaet("-1");
    dubnium->setze_elektronen_negativitaet("-1");
    dubnium->setze_kovalenter("-1");
    dubnium->setze_van_der_waals_radius("-1");
    dubnium->setze_schmelzpunkt(QString::number(INT_MAX));
    dubnium->setze_siedepunkt(QString::number(INT_MAX));
    dubnium->setze_familie(tr("transition metals"));
    dubnium->setze_gruppenfarbe(gruppenfarben.at(5));
    dubnium->setze_entdeckungsjahr(1967);
    dubnium->setze_position(4, 7);
    elementliste.insert(dubnium->atomzahl(), dubnium);
    dubnium->fuege_elektronen_hinzu(1, 2);
    dubnium->fuege_elektronen_hinzu(2, 8);
    dubnium->fuege_elektronen_hinzu(3, 18);
    dubnium->fuege_elektronen_hinzu(4, 32);
    dubnium->fuege_elektronen_hinzu(5, 32);
    dubnium->fuege_elektronen_hinzu(6, 11);
    dubnium->fuege_elektronen_hinzu(7, 2);

    // seaborgium (gruppe 6, Übergangsmetalle)
    Element* seaborgium = new Element(this);
    seaborgium->setObjectName("seaborgium");
    seaborgium->setze_element_namen(tr("Seaborgium"));
    seaborgium->setze_atomzahl(106);
    seaborgium->setze_symbol("Sg");
    seaborgium->setze_masse("270 u"); //uncertain
    seaborgium->setze_exakte_masse("270.130223");
    seaborgium->setze_ionisation("733 kJ/mol");
    seaborgium->setze_elektronenaffinitaet("-1");
    seaborgium->setze_elektronen_negativitaet("-1");
    seaborgium->setze_kovalenter("-1");
    seaborgium->setze_van_der_waals_radius("-1");
    seaborgium->setze_schmelzpunkt(QString::number(INT_MAX));
    seaborgium->setze_siedepunkt(QString::number(INT_MAX));
    seaborgium->setze_familie(tr("transition metals"));
    seaborgium->setze_gruppenfarbe(gruppenfarben.at(6));
    seaborgium->setze_entdeckungsjahr(1974);
    seaborgium->setze_position(5, 7);
    elementliste.insert(seaborgium->atomzahl(), seaborgium);
    seaborgium->fuege_elektronen_hinzu(1, 2);
    seaborgium->fuege_elektronen_hinzu(2, 8);
    seaborgium->fuege_elektronen_hinzu(3, 18);
    seaborgium->fuege_elektronen_hinzu(4, 32);
    seaborgium->fuege_elektronen_hinzu(5, 32);
    seaborgium->fuege_elektronen_hinzu(6, 12);
    seaborgium->fuege_elektronen_hinzu(7, 2);

    // bohrium (gruppe 7, Übergangsmetalle)
    Element* bohrium = new Element(this);
    bohrium->setObjectName("bohrium");
    bohrium->setze_element_namen(tr("Bohrium"));
    bohrium->setze_atomzahl(107);
    bohrium->setze_symbol("Bh");
    bohrium->setze_masse("274 u"); //uncertain
    bohrium->setze_exakte_masse("274.143140");
    bohrium->setze_ionisation("666 kJ/mol");
    bohrium->setze_elektronenaffinitaet("-1");
    bohrium->setze_elektronen_negativitaet("-1");
    bohrium->setze_kovalenter("-1");
    bohrium->setze_van_der_waals_radius("-1");
    bohrium->setze_schmelzpunkt(QString::number(INT_MAX));
    bohrium->setze_siedepunkt(QString::number(INT_MAX));
    bohrium->setze_familie(tr("transition metals"));
    bohrium->setze_gruppenfarbe(gruppenfarben.at(7));
    bohrium->setze_entdeckungsjahr(1981);
    bohrium->setze_position(6, 7);
    elementliste.insert(bohrium->atomzahl(), bohrium);
    bohrium->fuege_elektronen_hinzu(1, 2);
    bohrium->fuege_elektronen_hinzu(2, 8);
    bohrium->fuege_elektronen_hinzu(3, 18);
    bohrium->fuege_elektronen_hinzu(4, 32);
    bohrium->fuege_elektronen_hinzu(5, 32);
    bohrium->fuege_elektronen_hinzu(6, 13);
    bohrium->fuege_elektronen_hinzu(7, 2);

    // hassium (gruppe 8, Übergangsmetalle)
    Element* hassium = new Element(this);
    hassium->setObjectName("hassium");
    hassium->setze_element_namen(tr("Hassium"));
    hassium->setze_atomzahl(108);
    hassium->setze_symbol("Hs");
    hassium->setze_masse("277 u"); //uncertain
    hassium->setze_exakte_masse("277.151456");
    hassium->setze_ionisation("753 kJ/mol");
    hassium->setze_elektronenaffinitaet("-1");
    hassium->setze_elektronen_negativitaet("-1");
    hassium->setze_kovalenter("-1");
    hassium->setze_van_der_waals_radius("-1");
    hassium->setze_schmelzpunkt(QString::number(INT_MAX));
    hassium->setze_siedepunkt(QString::number(INT_MAX));
    hassium->setze_familie(tr("transition metals"));
    hassium->setze_gruppenfarbe(gruppenfarben.at(8));
    hassium->setze_entdeckungsjahr(1984);
    hassium->setze_position(7, 7);
    elementliste.insert(hassium->atomzahl(), hassium);
    hassium->fuege_elektronen_hinzu(1, 2);
    hassium->fuege_elektronen_hinzu(2, 8);
    hassium->fuege_elektronen_hinzu(3, 18);
    hassium->fuege_elektronen_hinzu(4, 32);
    hassium->fuege_elektronen_hinzu(5, 32);
    hassium->fuege_elektronen_hinzu(6, 14);
    hassium->fuege_elektronen_hinzu(7, 2);

    // meitnerium (gruppe 9, Übergangsmetalle)
    Element* meitnerium = new Element(this);
    meitnerium->setObjectName("meitnerium");
    meitnerium->setze_element_namen(tr("Meitnerium"));
    meitnerium->setze_atomzahl(109);
    meitnerium->setze_symbol("Mt");
    meitnerium->setze_masse("278 u"); //uncertain
    meitnerium->setze_exakte_masse("278.155824");
    meitnerium->setze_ionisation("839 kJ/mol");
    meitnerium->setze_elektronenaffinitaet("-1");
    meitnerium->setze_elektronen_negativitaet("-1");
    meitnerium->setze_kovalenter("-1");
    meitnerium->setze_van_der_waals_radius("-1");
    meitnerium->setze_schmelzpunkt(QString::number(INT_MAX));
    meitnerium->setze_siedepunkt(QString::number(INT_MAX));
    meitnerium->setze_familie(tr("transition metals"));
    meitnerium->setze_gruppenfarbe(gruppenfarben.at(9));
    meitnerium->setze_entdeckungsjahr(1982);
    meitnerium->setze_position(8, 7);
    elementliste.insert(meitnerium->atomzahl(), meitnerium);
    meitnerium->fuege_elektronen_hinzu(1, 2);
    meitnerium->fuege_elektronen_hinzu(2, 8);
    meitnerium->fuege_elektronen_hinzu(3, 18);
    meitnerium->fuege_elektronen_hinzu(4, 32);
    meitnerium->fuege_elektronen_hinzu(5, 32);
    meitnerium->fuege_elektronen_hinzu(6, 15);
    meitnerium->fuege_elektronen_hinzu(7, 2);

    // darmstadtium (gruppe 10, Übergangsmetalle)
    Element* darmstadtium = new Element(this);
    darmstadtium->setObjectName("darmstadtium");
    darmstadtium->setze_element_namen(tr("Darmstadtium"));
    darmstadtium->setze_atomzahl(110);
    darmstadtium->setze_symbol("Ds");
    darmstadtium->setze_masse("280 u"); //uncertain
    darmstadtium->setze_exakte_masse("280.160635");
    darmstadtium->setze_ionisation("926 kJ/mol");
    darmstadtium->setze_elektronenaffinitaet("-1");
    darmstadtium->setze_elektronen_negativitaet("-1");
    darmstadtium->setze_kovalenter("-1");
    darmstadtium->setze_van_der_waals_radius("-1");
    darmstadtium->setze_schmelzpunkt(QString::number(INT_MAX));
    darmstadtium->setze_siedepunkt(QString::number(INT_MAX));
    darmstadtium->setze_familie(tr("transition metals"));
    darmstadtium->setze_gruppenfarbe(gruppenfarben.at(10));
    darmstadtium->setze_entdeckungsjahr(1994);
    darmstadtium->setze_position(9, 7);
    elementliste.insert(darmstadtium->atomzahl(), darmstadtium);
    darmstadtium->fuege_elektronen_hinzu(1, 2);
    darmstadtium->fuege_elektronen_hinzu(2, 8);
    darmstadtium->fuege_elektronen_hinzu(3, 18);
    darmstadtium->fuege_elektronen_hinzu(4, 32);
    darmstadtium->fuege_elektronen_hinzu(5, 32);
    darmstadtium->fuege_elektronen_hinzu(6, 17);
    darmstadtium->fuege_elektronen_hinzu(7, 1);

    // roentgenium (gruppe 11, Übergangsmetalle)
    Element* roentgenium = new Element(this);
    roentgenium->setObjectName("roentgenium");
    roentgenium->setze_element_namen(tr("Roentgenium"));
    roentgenium->setze_atomzahl(111);
    roentgenium->setze_symbol("Rg");
    roentgenium->setze_masse("283 u"); //uncertain
    roentgenium->setze_exakte_masse("283.169770");
    roentgenium->setze_ionisation("1013 kJ/mol");
    roentgenium->setze_elektronenaffinitaet("-1");
    roentgenium->setze_elektronen_negativitaet("-1");
    roentgenium->setze_kovalenter("-1");
    roentgenium->setze_van_der_waals_radius("-1");
    roentgenium->setze_schmelzpunkt(QString::number(INT_MAX));
    roentgenium->setze_siedepunkt(QString::number(INT_MAX));
    roentgenium->setze_familie(tr("transition metals"));
    roentgenium->setze_gruppenfarbe(gruppenfarben.at(11));
    roentgenium->setze_entdeckungsjahr(1994);
    roentgenium->setze_position(10, 7);
    elementliste.insert(roentgenium->atomzahl(), roentgenium);
    roentgenium->fuege_elektronen_hinzu(1, 2);
    roentgenium->fuege_elektronen_hinzu(2, 8);
    roentgenium->fuege_elektronen_hinzu(3, 18);
    roentgenium->fuege_elektronen_hinzu(4, 32);
    roentgenium->fuege_elektronen_hinzu(5, 32);
    roentgenium->fuege_elektronen_hinzu(6, 18);
    roentgenium->fuege_elektronen_hinzu(7, 1);

    // copernicium (gruppe 12, Übergangsmetalle)
    Element* ununbium = new Element(this);
    ununbium->setObjectName("copernicium");
    ununbium->setze_element_namen(tr("Copernicium"));
    ununbium->setze_atomzahl(112);
    ununbium->setze_symbol("Cp");
    ununbium->setze_masse("285 u"); //uncertain
    ununbium->setze_exakte_masse("285.176182");
    ununbium->setze_ionisation("1100 kJ/mol");
    ununbium->setze_elektronenaffinitaet("-1");
    ununbium->setze_elektronen_negativitaet("-1");
    ununbium->setze_kovalenter("-1");
    ununbium->setze_van_der_waals_radius("-1");
    ununbium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununbium->setze_siedepunkt(QString::number(INT_MAX));
    ununbium->setze_familie(tr("transition metals"));
    ununbium->setze_gruppenfarbe(gruppenfarben.at(12));
    ununbium->setze_entdeckungsjahr(1996);
    ununbium->setze_position(11, 7);
    elementliste.insert(ununbium->atomzahl(), ununbium);
    ununbium->fuege_elektronen_hinzu(1, 2);
    ununbium->fuege_elektronen_hinzu(2, 8);
    ununbium->fuege_elektronen_hinzu(3, 18);
    ununbium->fuege_elektronen_hinzu(4, 32);
    ununbium->fuege_elektronen_hinzu(5, 32);
    ununbium->fuege_elektronen_hinzu(6, 18);
    ununbium->fuege_elektronen_hinzu(7, 2);

    // ununtrium (gruppe 13, Metalle)
    Element* ununtrium = new Element(this);
    ununtrium->setObjectName("ununtrium");
    ununtrium->setze_element_namen(tr("Ununtrium"));
    ununtrium->setze_atomzahl(113);
    ununtrium->setze_symbol("Uut");
    ununtrium->setze_masse("286 u"); //uncertain
    ununtrium->setze_exakte_masse("286.181317");
    ununtrium->setze_ionisation("714 kJ/mol");
    ununtrium->setze_elektronenaffinitaet("-1");
    ununtrium->setze_elektronen_negativitaet("-1");
    ununtrium->setze_kovalenter("-1");
    ununtrium->setze_van_der_waals_radius("-1");
    ununtrium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununtrium->setze_siedepunkt(QString::number(INT_MAX));
    ununtrium->setze_familie(tr("metals"));
    ununtrium->setze_gruppenfarbe(gruppenfarben.at(13));
    ununtrium->setze_entdeckungsjahr(2004);
    ununtrium->setze_position(12, 7);
    elementliste.insert(ununtrium->atomzahl(), ununtrium);
    ununtrium->fuege_elektronen_hinzu(1, 2);
    ununtrium->fuege_elektronen_hinzu(2, 8);
    ununtrium->fuege_elektronen_hinzu(3, 18);
    ununtrium->fuege_elektronen_hinzu(4, 32);
    ununtrium->fuege_elektronen_hinzu(5, 32);
    ununtrium->fuege_elektronen_hinzu(6, 18);
    ununtrium->fuege_elektronen_hinzu(7, 3);

    // ununquadium (gruppe 14, Metalle)
    Element* ununquadium = new Element(this);
    ununquadium->setObjectName("ununquadium");
    ununquadium->setze_element_namen(tr("Ununquadium"));
    ununquadium->setze_atomzahl(114);
    ununquadium->setze_symbol("Uuq");
    ununquadium->setze_masse("289 u"); //uncertain
    ununquadium->setze_exakte_masse("289.189515");
    ununquadium->setze_ionisation("820 kJ/mol");
    ununquadium->setze_elektronenaffinitaet("-1");
    ununquadium->setze_elektronen_negativitaet("-1");
    ununquadium->setze_kovalenter("-1");
    ununquadium->setze_van_der_waals_radius("-1");
    ununquadium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununquadium->setze_siedepunkt(QString::number(INT_MAX));
    ununquadium->setze_familie(tr("metals"));
    ununquadium->setze_gruppenfarbe(gruppenfarben.at(14));
    ununquadium->setze_entdeckungsjahr(1999);
    ununquadium->setze_position(13, 7);
    elementliste.insert(ununquadium->atomzahl(), ununquadium);
    ununquadium->fuege_elektronen_hinzu(1, 2);
    ununquadium->fuege_elektronen_hinzu(2, 8);
    ununquadium->fuege_elektronen_hinzu(3, 18);
    ununquadium->fuege_elektronen_hinzu(4, 32);
    ununquadium->fuege_elektronen_hinzu(5, 32);
    ununquadium->fuege_elektronen_hinzu(6, 18);
    ununquadium->fuege_elektronen_hinzu(7, 4);

    // ununpentium (gruppe 15, Metalle)
    Element* ununpentium = new Element(this);
    ununpentium->setObjectName("ununpentium");
    ununpentium->setze_element_namen(tr("Ununpentium"));
    ununpentium->setze_atomzahl(115);
    ununpentium->setze_symbol("Uup");
    ununpentium->setze_masse("291 u"); //uncertain
    ununpentium->setze_exakte_masse("291.196211");
    ununpentium->setze_ionisation("-1");
    ununpentium->setze_elektronenaffinitaet("-1");
    ununpentium->setze_elektronen_negativitaet("-1");
    ununpentium->setze_kovalenter("-1");
    ununpentium->setze_van_der_waals_radius("-1");
    ununpentium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununpentium->setze_siedepunkt(QString::number(INT_MAX));
    ununpentium->setze_familie(tr("metals"));
    ununpentium->setze_gruppenfarbe(gruppenfarben.at(15));
    ununpentium->setze_entdeckungsjahr(2004);
    ununpentium->setze_position(14, 7);
    elementliste.insert(ununpentium->atomzahl(), ununpentium);
    ununpentium->fuege_elektronen_hinzu(1, 2);
    ununpentium->fuege_elektronen_hinzu(2, 8);
    ununpentium->fuege_elektronen_hinzu(3, 18);
    ununpentium->fuege_elektronen_hinzu(4, 32);
    ununpentium->fuege_elektronen_hinzu(5, 32);
    ununpentium->fuege_elektronen_hinzu(6, 18);
    ununpentium->fuege_elektronen_hinzu(7, 5);

    // ununhexium (gruppe 16, Metalle)
    Element* ununhexium = new Element(this);
    ununhexium->setObjectName("ununhexium");
    ununhexium->setze_element_namen(tr("Ununhexium"));
    ununhexium->setze_atomzahl(116);
    ununhexium->setze_symbol("Uuh");
    ununhexium->setze_masse("293 u"); //uncertain
    ununhexium->setze_exakte_masse("293.203591");
    ununhexium->setze_ionisation("-1");
    ununhexium->setze_elektronenaffinitaet("-1");
    ununhexium->setze_elektronen_negativitaet("-1");
    ununhexium->setze_kovalenter("-1");
    ununhexium->setze_van_der_waals_radius("-1");
    ununhexium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununhexium->setze_siedepunkt(QString::number(INT_MAX));
    ununhexium->setze_familie(tr("metals"));
    ununhexium->setze_gruppenfarbe(gruppenfarben.at(16));
    ununhexium->setze_entdeckungsjahr(2000);
    ununhexium->setze_position(15, 7);
    elementliste.insert(ununhexium->atomzahl(), ununhexium);
    ununhexium->fuege_elektronen_hinzu(1, 2);
    ununhexium->fuege_elektronen_hinzu(2, 8);
    ununhexium->fuege_elektronen_hinzu(3, 18);
    ununhexium->fuege_elektronen_hinzu(4, 32);
    ununhexium->fuege_elektronen_hinzu(5, 32);
    ununhexium->fuege_elektronen_hinzu(6, 18);
    ununhexium->fuege_elektronen_hinzu(7, 6);

    // ununseptium (gruppe 17, Halogene)
    Element* ununseptium = new Element(this);
    ununseptium->setObjectName("ununseptium");
    ununseptium->setze_element_namen(tr("Ununseptium"));
    ununseptium->setze_atomzahl(117);
    ununseptium->setze_symbol("Uus");
    ununseptium->setze_masse("294 u"); //uncertain
    ununseptium->setze_exakte_masse("294.209474");
    ununseptium->setze_ionisation("-1");
    ununseptium->setze_elektronenaffinitaet("-1");
    ununseptium->setze_elektronen_negativitaet("-1");
    ununseptium->setze_kovalenter("-1");
    ununseptium->setze_van_der_waals_radius("-1");
    ununseptium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununseptium->setze_siedepunkt(QString::number(INT_MAX));
    ununseptium->setze_familie(tr("halogens"));
    ununseptium->setze_gruppenfarbe(gruppenfarben.at(17));
    ununseptium->setze_entdeckungsjahr(2010);
    ununseptium->setze_position(16, 7);
    elementliste.insert(ununseptium->atomzahl(), ununseptium);
    ununseptium->fuege_elektronen_hinzu(1, 2);
    ununseptium->fuege_elektronen_hinzu(2, 8);
    ununseptium->fuege_elektronen_hinzu(3, 18);
    ununseptium->fuege_elektronen_hinzu(4, 32);
    ununseptium->fuege_elektronen_hinzu(5, 32);
    ununseptium->fuege_elektronen_hinzu(6, 18);
    ununseptium->fuege_elektronen_hinzu(7, 7);


    // ununoctium (gruppe 18, Edelgase)
    Element* ununoctium = new Element(this);
    ununoctium->setObjectName("ununoctium");
    ununoctium->setze_element_namen(tr("Ununoctium"));
    ununoctium->setze_atomzahl(118);
    ununoctium->setze_symbol("Uuo");
    ununoctium->setze_masse("297 u");
    //www.pse118-online.de/isocard/isotopes%2011/118-Uuo-297.htm
    ununoctium->setze_exakte_masse("297.20");
    ununoctium->setze_ionisation("-1");
    ununoctium->setze_elektronenaffinitaet("-1");
    ununoctium->setze_elektronen_negativitaet("-1");
    ununoctium->setze_kovalenter("-1");
    ununoctium->setze_van_der_waals_radius("-1");
    ununoctium->setze_schmelzpunkt(QString::number(INT_MAX));
    ununoctium->setze_siedepunkt(QString::number(INT_MAX));
    ununoctium->setze_familie(tr("noble gases"));
    ununoctium->setze_gruppenfarbe(gruppenfarben.at(18));
    ununoctium->setze_entdeckungsjahr(2006);
    ununoctium->setze_position(17, 7);
    elementliste.insert(ununoctium->atomzahl(), ununoctium);
    ununoctium->fuege_elektronen_hinzu(1, 2);
    ununoctium->fuege_elektronen_hinzu(2, 8);
    ununoctium->fuege_elektronen_hinzu(3, 18);
    ununoctium->fuege_elektronen_hinzu(4, 32);
    ununoctium->fuege_elektronen_hinzu(5, 32);
    ununoctium->fuege_elektronen_hinzu(6, 18);
    ununoctium->fuege_elektronen_hinzu(7, 8);



    // daten, einstellungen und verbindungen, die alle elemente erhalten muessen
    {
        QList<int> schluessel(elementliste.keys());

        for (register int idx = 0; idx < schluessel.size(); idx++)
        {
            Element *tmp_element = elementliste.value(schluessel.at(idx));

            // den tooltip fuer das element zusammenstellen
            tmp_element->setToolTip(tmp_element->element_name() + ", " + QString::number(tmp_element->atomzahl()) + "\n" + tmp_element->familie());

            // die agregatzustandsfarben uebergeben
            tmp_element->registriere_agrgatzustandsfarben(agregatzustandsfarben);

            // den zvalue einstellen, damit die tabelle gleichmaessiger ist
            tmp_element->setZValue((idx+tmp_element->yposition())%2);

            // signal - slot verbindungen
            // das steuern der hintergrundfarbe der element ermoeglichen
            connect(this, SIGNAL(gruppenfarbe_geordert()), tmp_element, SLOT(zeige_gruppenfarbe()));
            connect(this, SIGNAL(agregatzustandfarbe_gefordert(double)), tmp_element, SLOT(zeige_agregatzustandfarbe(double)));
            connect(this, SIGNAL(temperatur_geordert(double)), tmp_element, SLOT(zeige_agregatzustandfarbe(double)));

            // das melden von aktivierungen ermoeglichen
            connect(tmp_element, SIGNAL(aktiviert(Element*)), this, SIGNAL(aktiviert(Element*)));

            // das melden von doppelklicks ermoeglichen
            connect(tmp_element, SIGNAL(doppelgeklickt(Element*)), this, SIGNAL(doppelgeklickt(Element*)));

            // die uebermittlung des jahres ermoeglichen
            connect(this, SIGNAL(jahr(int)), tmp_element, SLOT(setze_jahr(int)));

            // das durchleiten von suchen ermoeglichen
            connect(this, SIGNAL(suche(const QString&)), tmp_element, SLOT(suche(const QString&)));
        }
    }



    // alle gruppennummern in die liste einfuegen
    {
        QList<int> schluessel(gruppennummerliste.keys());

        for (register int idx = 0; idx < schluessel.size(); idx++)
        {
            // eine gruppennummer in die scene einfuegen
            addItem(gruppennummerliste.value(schluessel.at(idx)));

            // die position fuer die soeben in die scene eingefuegte gruppennummer setzen
            gruppennummerliste.value(schluessel.at(idx))->setPos(((gruppennummerliste.value(schluessel.at(idx))->nummer() - 1) * ELEMENT_GROESSE) + 4.5 * SCENE_RAND, 0);
        }
    }


    // alle periodennummern in die liste einfuegen
    {
        QList<int> schluessel(periodennummerliste.keys());

        for (register int idx = 0; idx < schluessel.size(); idx++)
        {
            // eine periodennummer in die scene einfuegen
            addItem(periodennummerliste.value(schluessel.at(idx)));

            // die position fuer die soeben in die scene eingefuegte periodennummer setzen
            periodennummerliste.value(schluessel.at(idx))->setPos(0, ((periodennummerliste.value(schluessel.at(idx))->nummer() - 1) * ELEMENT_GROESSE));
        }
    }

    // alle elemente in die scene einfuegen
    {
        QList<int> schluessel(elementliste.keys());

        for (register int idx = 0; idx < schluessel.size(); idx++)
        {
            // ein element in die scene einfuegen
            fuege_element_hinzu(elementliste.value(schluessel.at(idx)));

            // die position des element setzen
            if (elementliste.value(schluessel.at(idx))->yposition() < 8)
            {
                elementliste.value(schluessel.at(idx))->setPos((elementliste.value(schluessel.at(idx))->xposition() * ELEMENT_GROESSE) + 4.5 * SCENE_RAND, elementliste.value(schluessel.at(idx))->yposition() * ELEMENT_GROESSE);
            }

            else
            {
                elementliste.value(schluessel.at(idx))->setPos((elementliste.value(schluessel.at(idx))->xposition() * ELEMENT_GROESSE) + 4.5 * SCENE_RAND, (elementliste.value(schluessel.at(idx))->yposition() * ELEMENT_GROESSE) + SCENE_RAND);
            }
        }
    }

    // die legende positionieren und in die scene einfuegen
    legende->setPos(QPointF(scandium->pos().x() + SCENE_RAND, wasserstoff->pos().y()));

    addItem(legende);
}


Scene::~Scene()
{
}


void Scene::zeige_gruppenfarbe()
{
    emit gruppenfarbe_geordert();
}


void Scene::zeige_agregatzustandfarbe(double wert)
{
    emit agregatzustandfarbe_gefordert(wert);
}


void Scene::zeige_temperatur(double wert)
{
    emit temperatur_geordert(wert);
}


Element* Scene::get_element(int atomzahl) const
{
    Element* erg = 0;

    if (elementliste.contains(atomzahl) == true) erg = elementliste.value(atomzahl);

    return erg;
}


void Scene::legende_setze_seite(int seite)
{
    legende->setze_seite(seite);
}


void Scene::fuege_element_hinzu(Element* element)
{
    addItem(element);

    elemente_in_scene.append(element);

    emit vorhandene_elemente_geaendert(elemente_in_scene);
    emit vorhandene_elemente_geaendert(elemente_in_scene.size());
}


void Scene::entferne_element(Element* element)
{
    removeItem(element);

    elemente_in_scene.removeAll(element);

    emit vorhandene_elemente_geaendert(elemente_in_scene);
    emit vorhandene_elemente_geaendert(elemente_in_scene.size());
}


int Scene::elementzahl() const
{
    return elemente_in_scene.size();
}


const QMap<int, Element*>& Scene::get_elementliste() const
{
    return elementliste;
}


void Scene::setze_sichtbarkeit_legende(bool zustand)
{
    legende->setze_sichtbarkeit(zustand);
}


bool Scene::sichtbarkeit_legende() const
{
    return legende->ist_sichtbar();
}

