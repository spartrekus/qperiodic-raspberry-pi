/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#define VERSION "0.60"

#include <QMainWindow>
#include "ui_MainWindow.h"

class Scene;
class QSettings;
class Detail_dialog;
class QLabel;

class MainWindow : public QMainWindow, private Ui::MainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    virtual ~MainWindow();

    void einstellungen_laden();
    void einstellungen_speichern();

private slots:
    void about();
    void steuerung_werkzeug_box(int);
    void steuerung_temperatur_slider(int);
    void steuerung_temperatur_box(double);
    void zeige_elementzahl(int);
    void zeige_uebersicht();
    void zeige_zeitleiste();
    void zeige_agregatzustand();
    void zeige_suche();

signals:
    void jahr(int);
    void suche(const QString&);

private:
    Scene *scene;
    QSettings *einstellungen;
    Detail_dialog *details;
    QLabel *elementzahl_label;
};

#endif

