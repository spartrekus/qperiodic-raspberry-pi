#include "Legende.h"
#include "Scene.h"
#include "Proportionen.h"
#include <QPainter>
#include <QFont>
#include <QGraphicsSceneMouseEvent>

#define UEBERSICHT_POSITION 0
#define ZEITLEISTE_POSITION 1
#define AGREGATZUSTAND_POSITION 2
#define SUCHE_POSITION 3

using namespace std;

Legende::Legende(Scene *parent) : QObject(parent), QGraphicsItem(0), meinescene(parent), Aktuelle_seite(0)
{
}


Legende::~Legende()
{
}


QRectF Legende::boundingRect() const
{
    QRectF erg(0, 0, LEGENDE_BREITE, LEGENDE_HOEHE);

    return erg;
}


void Legende::paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    painter->setBrush(Qt::lightGray);

    // die aussenkante malen
    painter->drawRect(boundingRect().adjusted(1, 1, -1, -1));

    if (Aktuelle_seite == UEBERSICHT_POSITION || Aktuelle_seite == ZEITLEISTE_POSITION || Aktuelle_seite == SUCHE_POSITION)
    {
        // den font einstellen
        QFont font(painter->font());

#ifdef Q_OS_MAC

        font.setPointSizeF(LEGENDE_BREITE / 37);

#elif defined Q_OS_WIN

        font.setPointSizeF(LEGENDE_BREITE / 50);
        font.setBold(true);

#else

        font.setPointSizeF(LEGENDE_BREITE / 52);

#endif

        painter->setFont(font);

        double schritt = (double) LEGENDE_HOEHE / (double) 5;

        // 1. spalte
        // das feld der 1 gruppe malen
        painter->setBrush(gruppenfarben.at(1));
        painter->drawRect(QRectF(10 + schritt / 4.5, schritt - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt, schritt - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 1"));

        // das feld der 2 gruppe malen
        painter->setBrush(gruppenfarben.at(2));
        painter->drawRect(QRectF(10 + schritt / 4.5, (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt, (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 2"));

        // das feld der 3 gruppe malen
        painter->setBrush(gruppenfarben.at(3));
        painter->drawRect(QRectF(10 + schritt / 4.5, (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt, (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 3"));

        // das feld der 4 gruppe malen
        painter->setBrush(gruppenfarben.at(4));
        painter->drawRect(QRectF(10 + schritt / 4.5, (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt, (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 4"));

        // 2. spalte
        // das feld der 5 gruppe malen
        painter->setBrush(gruppenfarben.at(5));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5), schritt - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5), schritt - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 5"));

        // das feld der 6 gruppe malen
        painter->setBrush(gruppenfarben.at(6));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 6"));

        // das feld der 7 gruppe malen
        painter->setBrush(gruppenfarben.at(7));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 7"));

        // das feld der 8 gruppe malen
        painter->setBrush(gruppenfarben.at(8));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 8"));

        // 3. spalte
        // das feld der 9 gruppe malen
        painter->setBrush(gruppenfarben.at(9));
        painter->drawRect(QRectF(8 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 2), schritt - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(4 + schritt + (LEGENDE_BREITE / 5.5 * 2), schritt - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 9"));

        // das feld der 10 gruppe malen
        painter->setBrush(gruppenfarben.at(10));
        painter->drawRect(QRectF(8 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 2), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(4 + schritt + (LEGENDE_BREITE / 5.5 * 2), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 10"));

        // das feld der 11 gruppe malen
        painter->setBrush(gruppenfarben.at(11));
        painter->drawRect(QRectF(8 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 2), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(4 + schritt + (LEGENDE_BREITE / 5.5 * 2), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 11"));

        // das feld der 12 gruppe malen
        painter->setBrush(gruppenfarben.at(12));
        painter->drawRect(QRectF(8 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 2), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(4 + schritt + (LEGENDE_BREITE / 5.5 * 2), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 12"));

        // 4. spalte
        // das feld der 13 gruppe malen
        painter->setBrush(gruppenfarben.at(13));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 3), schritt - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5 * 3), schritt - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE , LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 13"));

        // das feld der 14 gruppe malen
        painter->setBrush(gruppenfarben.at(14));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 3), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5 * 3), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 14"));

        // das feld der 15 gruppe malen
        painter->setBrush(gruppenfarben.at(15));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 3), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5 * 3), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 15"));

        // das feld der 16 gruppe malen
        painter->setBrush(gruppenfarben.at(16));
        painter->drawRect(QRectF(10 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 3), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(6 + schritt + (LEGENDE_BREITE / 5.5 * 3), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 16"));

        // 5. spalte
        // das feld der 17 gruppe malen
        painter->setBrush(gruppenfarben.at(17));
        painter->drawRect(QRectF(12 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 4), schritt - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(8 + schritt + (LEGENDE_BREITE / 5.5 * 4), schritt - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 17"));

        // das feld der 18 gruppe malen
        painter->setBrush(gruppenfarben.at(18));
        painter->drawRect(QRectF(12 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 4), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(8 + schritt + (LEGENDE_BREITE / 5.5 * 4), (schritt * 2) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Group 18"));


        // das feld die Lanthanoiden malen
        painter->setBrush(gruppenfarben.at(19));
        painter->drawRect(QRectF(12 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 4), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(8 + schritt + (LEGENDE_BREITE / 5.5 * 4), (schritt * 3) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Lanthanides"));


        // das feld die Actinoiden malen
        painter->setBrush(gruppenfarben.at(20));
        painter->drawRect(QRectF(12 + (schritt / 4.5) + (LEGENDE_BREITE / 5.5 * 4), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, (double) LEGENDE_HOEHE / (double) 9, (double) LEGENDE_HOEHE / (double) 9));
        painter->drawText(QRectF(8 + schritt + (LEGENDE_BREITE / 5.5 * 4), (schritt * 4) - (double) LEGENDE_HOEHE / (double) 18, LEGENDE_BREITE, LEGENDE_HOEHE), Qt::AlignLeft, tr("Actinides"));
    }

    else if (Aktuelle_seite == AGREGATZUSTAND_POSITION)
    {
        // den font einstellen
        QFont font(painter->font());

#ifdef Q_OS_MAC

        font.setPointSizeF(LEGENDE_BREITE / 37);

#elif defined Q_OS_WIN

        font.setPointSizeF(LEGENDE_BREITE / 50);
        font.setBold(true);

#else

        font.setPointSizeF(LEGENDE_BREITE / 52);

#endif

        painter->setFont(font);

        double schritt = (double) LEGENDE_HOEHE / (double) 5;

        // fest
        painter->setBrush(agregatzustandsfarben.at(1));
        painter->drawRect(QRectF(LEGENDE_BREITE / 4, schritt - (LEGENDE_HOEHE / 18), LEGENDE_HOEHE / 9, LEGENDE_HOEHE / 9));
        painter->drawText(QRectF((LEGENDE_BREITE / 4) + (LEGENDE_HOEHE / 4.5), schritt - (LEGENDE_HOEHE / 18), LEGENDE_BREITE / 4, LEGENDE_HOEHE / 9), Qt::AlignLeft, tr("Solid"));

        // fluessig
        painter->setBrush(agregatzustandsfarben.at(2));
        painter->drawRect(QRectF(LEGENDE_BREITE / 4, (schritt * 2) - (LEGENDE_HOEHE / 18), LEGENDE_HOEHE / 9, LEGENDE_HOEHE / 9));
        painter->drawText(QRectF((LEGENDE_BREITE / 4) + (LEGENDE_HOEHE / 4.5), (schritt * 2) - (LEGENDE_HOEHE / 18), LEGENDE_BREITE / 4, LEGENDE_HOEHE / 9), Qt::AlignLeft, tr("Liquid"));

        // gasfoermig
        painter->setBrush(agregatzustandsfarben.at(3));
        painter->drawRect(QRectF(LEGENDE_BREITE / 4, (schritt * 3) - (LEGENDE_HOEHE / 18), LEGENDE_HOEHE / 9, LEGENDE_HOEHE / 9));
        painter->drawText(QRectF((LEGENDE_BREITE / 4) + (LEGENDE_HOEHE / 4.5), (schritt * 3) - (LEGENDE_HOEHE / 18), LEGENDE_BREITE / 4, LEGENDE_HOEHE / 9), Qt::AlignLeft, tr("Gas"));

        // unbekannt
        painter->setBrush(agregatzustandsfarben.at(0));
        painter->drawRect(QRectF(LEGENDE_BREITE / 4, (schritt * 4) - (LEGENDE_HOEHE / 18), LEGENDE_HOEHE / 9, LEGENDE_HOEHE / 9));
        painter->drawText(QRectF((LEGENDE_BREITE / 4) + (LEGENDE_HOEHE / 4.5), (schritt * 4) - (LEGENDE_HOEHE / 18), LEGENDE_BREITE / 4, LEGENDE_HOEHE / 9), Qt::AlignLeft, tr("Unknown"));
    }
}


void Legende::registriere_gruppenfarben(const QList<QColor>& element)
{
    gruppenfarben = element;
}


void Legende::setze_seite(int seite)
{
    Aktuelle_seite = seite;

    update();
}


void Legende::registriere_agrgatzustandsfarben(const QList<QColor>& farben)
{
    agregatzustandsfarben = farben;
}


void Legende::setze_sichtbarkeit(bool zustand)
{
    // wenn das element sichtbar sein soll
    if (zustand == true)
    {
        // nur, wenn scene 0 ist und dieses element sich nich nicht in der scene befindet.
        if (scene() == 0) meinescene->addItem(this);
    }

    // ansonsten
    else meinescene->removeItem(this);
}


bool Legende::ist_sichtbar() const
{
    return (scene() != 0);
}

