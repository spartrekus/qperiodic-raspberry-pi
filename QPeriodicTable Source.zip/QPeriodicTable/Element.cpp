#include "Element.h"
#include "Scene.h"
#include "Proportionen.h"
#include <QPainter>
#include <QFont>
#include <QGraphicsSceneMouseEvent>
#include <climits>

using namespace std;

Element::Element(Scene *parent) : QObject(parent), QGraphicsItem(0), meinescene(parent), Masse("0"), Exakte_masse("0"), Ionisation("0"), Elektronenafinitaet("0"), Elektronen_negativitaet("0"), Kovalenter("0"), Van_der_waals_radius("0"), Schmelzpunkt("0"), Siedepunkt("0"), Suchvorgang(""), Atomzahl(0), Xposition(0), Yposition(0), Entdeckungsjahr(0)
{
    setFlag(QGraphicsItem::ItemIsSelectable);
}


Element::~Element()
{
}


void Element::paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    // die hintergrundfarbe setzen
    painter->setBrush(QBrush(aktive_farbe));

    // den font setzen
    QFont font(painter->font());

#ifdef Q_OS_MAC

    if (Symbol.size() == 1) font.setPointSizeF((double) ELEMENT_GROESSE * 0.65);
    else if (Symbol.size() == 2) font.setPointSizeF((double) ELEMENT_GROESSE * 0.60);
    else font.setPointSizeF((double) ELEMENT_GROESSE * 0.5);

#elif defined Q_OS_WIN

    if (Symbol.size() == 1) font.setPointSizeF((double) ELEMENT_GROESSE * 0.55);
    else if (Symbol.size() == 2) font.setPointSizeF((double) ELEMENT_GROESSE * 0.50);
    else font.setPointSizeF((double) ELEMENT_GROESSE * 0.40);

#else

    if (Symbol.size() == 1) font.setPointSizeF((double) ELEMENT_GROESSE * 0.50);
    else if (Symbol.size() == 2) font.setPointSizeF((double) ELEMENT_GROESSE * 0.45);
    else font.setPointSizeF((double) ELEMENT_GROESSE * 0.36);

#endif

    painter->setFont(font);

    // den aussenring malen
    painter->drawRect(boundingRect().adjusted(+0.5, +0.5, -0.5, -0.5));

    // wenn nur der schmelzpunkt unbekannt ist und eine agregatzustandsfarbe aktive ist die linke haelfte grau einfaerben
    if (Schmelzpunkt.toInt() == INT_MAX && Siedepunkt.toInt() != INT_MAX && agregatzustandsfarben.contains(aktive_farbe) == true && aktive_farbe != agregatzustandsfarben.at(0))
    {
        painter->setBrush(agregatzustandsfarben.at(0));
        painter->setPen(agregatzustandsfarben.at(0));

        painter->drawRect(QRectF(0, 0, ELEMENT_GROESSE / 2, ELEMENT_GROESSE));

        painter->setBrush(Qt::NoBrush);

        // den stift setzen
        painter->setPen(Qt::black);

        painter->drawRect(boundingRect().adjusted(+0.5, +0.5, -0.5, -0.5));
    }

    // wenn nur der siedepunkt unbekannt ist und eine agregatzustandsfarbe aktive ist die rechte haelfte grau einfaerben
    else if (Schmelzpunkt.toInt() != INT_MAX && Siedepunkt.toInt() == INT_MAX && agregatzustandsfarben.contains(aktive_farbe) == true && aktive_farbe != agregatzustandsfarben.at(0))
    {
        painter->setBrush(agregatzustandsfarben.at(0));
        painter->setPen(agregatzustandsfarben.at(0));

        painter->drawRect(QRectF(ELEMENT_GROESSE / 2, 0, ELEMENT_GROESSE / 2, ELEMENT_GROESSE));

        painter->setBrush(Qt::NoBrush);

        // den stift setzen
        painter->setPen(Qt::black);

        painter->drawRect(boundingRect().adjusted(+0.5, +0.5, -0.5, -0.5));
    }

    // das zeichen malen
    painter->drawText(boundingRect(), Qt::AlignCenter, Symbol);
}


QRectF Element::boundingRect() const
{
    QRectF erg(0, 0, ELEMENT_GROESSE + 1, ELEMENT_GROESSE + 1);

    return erg;
}


void Element::setze_element_namen(const QString& wert)
{
    Element_name = wert;
}


const QString& Element::element_name() const
{
    return Element_name;
}


void Element::setze_atomzahl(int wert)
{
    Atomzahl = wert;
}


int Element::atomzahl() const
{
    return Atomzahl;
}


void Element::setze_symbol(const QString& wert)
{
    Symbol = wert;
}


const QString& Element::symbol() const
{
    return Symbol;
}


void Element::setze_masse(const QString& wert)
{
    Masse = wert;
}


const QString& Element::masse() const
{
    return Masse;
}


void Element::setze_exakte_masse(const QString& wert)
{
    Exakte_masse = wert;
}


const QString& Element::exakte_masse() const
{
    return Exakte_masse;
}


void Element::setze_ionisation(const QString& wert)
{
    Ionisation = wert;
}


const QString& Element::ionisation() const
{
    return Ionisation;
}


void Element::setze_elektronenaffinitaet(const QString& wert)
{
    Elektronenafinitaet = wert;
}


const QString& Element::elektronenaffinitaet() const
{
    return Elektronenafinitaet;
}


void Element::setze_elektronen_negativitaet(const QString& wert)
{
    Elektronen_negativitaet = wert;
}


const QString& Element::elektronen_negativitaet() const
{
    return Elektronen_negativitaet;
}


void Element::setze_kovalenter(const QString& wert)
{
    Kovalenter = wert;
}


const QString& Element::kovalenter() const
{
    return Kovalenter;
}


void Element::setze_van_der_waals_radius(const QString& wert)
{
    Van_der_waals_radius = wert;
}


const QString& Element::van_der_waals_radius() const
{
    return Van_der_waals_radius;
}


void Element::setze_schmelzpunkt(const QString& wert)
{
    Schmelzpunkt = wert;
}


const QString& Element::schmelzpunkt() const
{
    return Schmelzpunkt;
}


void Element::setze_siedepunkt(const QString& wert)
{
    Siedepunkt = wert;
}


const QString& Element::siedepunkt() const
{
    return Siedepunkt;
}


void Element::setze_familie(const QString& wert)
{
    Familie = wert;
}


const QString& Element::familie() const
{
    return Familie;
}


void Element::setze_gruppenfarbe(const QColor& wert)
{
    Gruppenfarbe = aktive_farbe = wert;
}


const QColor& Element::gruppenfarbe() const
{
    return Gruppenfarbe;
}


void Element::setze_position(int x, int y)
{
    Xposition = x;
    Yposition = y;
}


int Element::xposition() const
{
    return Xposition;
}


int Element::yposition() const
{
    return Yposition;
}


void Element::zeige_gruppenfarbe()
{
    aktive_farbe = Gruppenfarbe;

    update();
}


void Element::zeige_agregatzustandfarbe(double temperatur)
{
    // beide unbekannt
    if (Schmelzpunkt.toInt() == INT_MAX && Siedepunkt.toInt() == INT_MAX) aktive_farbe = agregatzustandsfarben.at(0);

    // fester zustand
    else if ((temperatur < Schmelzpunkt.toDouble() || Schmelzpunkt.toDouble() < 0) && temperatur < Siedepunkt.toDouble()) aktive_farbe = agregatzustandsfarben.at(1);

    // fluessiger zustand
    else if (temperatur < Siedepunkt.toDouble()) aktive_farbe = agregatzustandsfarben.at(2);

    // gasfoermiger zustand
    else aktive_farbe = aktive_farbe = agregatzustandsfarben.at(3);

    update();
}


void Element::setze_entdeckungsjahr(int wert)
{
    Entdeckungsjahr = wert;
}


int Element::entdeckungsjahr() const
{
    return Entdeckungsjahr;
}


void Element::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsItem::mousePressEvent(event);

    emit aktiviert(this);
}


void Element::setze_jahr(int wert)
{
    if (wert < Entdeckungsjahr && meinescene->items().contains(this) == true) meinescene->entferne_element(this);

    else if (wert >= Entdeckungsjahr && meinescene->items().contains(this) == false) meinescene->fuege_element_hinzu(this);
}


void Element::registriere_agrgatzustandsfarben(const QList<QColor>& farben)
{
    agregatzustandsfarben = farben;
}


void Element::suche(const QString& txt)
{
    bool ok = false;

    if (Element_name.contains(txt, Qt::CaseInsensitive) == true || txt.isEmpty() == true || Symbol.contains(txt, Qt::CaseInsensitive) == true)
    {
        if (meinescene->items().contains(this) == false) meinescene->fuege_element_hinzu(this);
    }

    else if (txt.toInt(&ok) > 0 && ok == true && txt.toInt() == Atomzahl)
    {
        if (meinescene->items().contains(this) == false) meinescene->fuege_element_hinzu(this);
    }

    else if (meinescene->items().contains(this) == true) meinescene->entferne_element(this);
}


void Element::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsItem::mouseDoubleClickEvent(event);

    emit doppelgeklickt(this);
}


void Element::fuege_elektronen_hinzu(int ring, int menge)
{
    if (ring > 0 && ring <= 7) Elektronenkonfiguration.insert(ring, menge);
}


int Element::elektronen_an_ring(int ring) const
{
    int erg = 0;

    if (Elektronenkonfiguration.contains(ring) == true) erg = Elektronenkonfiguration.value(ring);

    return erg;
}


int Element::elektronen() const
{
    int erg = 0;

    QList<int> ringe(Elektronenkonfiguration.keys());

    for (register int idx = 0; idx < ringe.size(); idx++) erg += Elektronenkonfiguration.value(ringe.at(idx));

    return erg;
}

