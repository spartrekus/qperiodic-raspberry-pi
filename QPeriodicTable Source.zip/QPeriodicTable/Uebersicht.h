/*

 Name: QPeriodicTable
 Autor: Andreas Konarski
 Lizenz: GPL v3 or later
 Plattformen: Alle Systeme, auf denen QT 4.5 verfuegbar ist. Kompatibel mit QT 5.0.0.
 
 Kontakt: programmieren@konarski-wuppertal.de
 home: www.konarski-wuppertal.de
 
 Falls ich mit diesem Programm die Rechte von irgend jemand verletzen sollte, bitte ich um einen Hinweis. Wenn dies Tatsaechlich der Fall ist, entferne ich es schnellstmoeglich von meiner Homepage.
 
 */

#ifndef UEBERSICHT_H
#define UEBERSICHT_H

#include <QWidget>
#include <QList>

class Element;

class Uebersicht : public QWidget
{
    Q_OBJECT

public:
    Uebersicht(QWidget *parent = 0);
    virtual ~Uebersicht();

public slots:
    void zeige(Element*);
    void vorhandene_elemente_geaendert(const QList<Element*>&);

signals:
    void doppelgeklickt(Element*);

private:
    Element *aktuelles_element;

    virtual void paintEvent(QPaintEvent*);
    virtual void mouseDoubleClickEvent(QMouseEvent*);
};

#endif

